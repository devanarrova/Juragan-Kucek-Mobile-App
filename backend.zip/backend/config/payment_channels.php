<?php

return [
    // Catatan: masih static config (cepat & aman).
    // Kalau nanti mau dinamis, pindahkan ke tabel DB + CRUD admin.

    'banks' => [
        [
            'code' => 'BCA',
            'name' => 'BCA',
            'account_number' => '1234567890',
            'account_name' => 'Juragan Kucek',
        ],
        [
            'code' => 'BRI',
            'name' => 'BRI',
            'account_number' => '9876543210',
            'account_name' => 'Juragan Kucek',
        ],
        [
            'code' => 'MANDIRI',
            'name' => 'Mandiri',
            'account_number' => '1400012345678',
            'account_name' => 'Juragan Kucek',
        ],
        [
            'code' => 'BNI',
            'name' => 'BNI',
            'account_number' => '0123456789',
            'account_name' => 'Juragan Kucek',
        ],
    ],

    'ewallets' => [
        [
            'code' => 'DANA',
            'name' => 'DANA',
            'account_number' => '081234567890',
            'account_name' => 'Juragan Kucek',
        ],
        [
            'code' => 'GOPAY',
            'name' => 'GoPay',
            'account_number' => '081298765432',
            'account_name' => 'Juragan Kucek',
        ],
        [
            'code' => 'OVO',
            'name' => 'OVO',
            'account_number' => '081200011122',
            'account_name' => 'Juragan Kucek',
        ],
    ],
];
