<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Models\Service;
use App\Http\Controllers\Api\CustomerAuthController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\PaymentController;
use App\Http\Controllers\Api\PaymentChannelController;
use App\Http\Controllers\Api\ChatController;
use App\Http\Controllers\Api\NotificationController;
use App\Http\Controllers\Api\CustomerProfileController;

// Public routes (tanpa login)
Route::post('/customer/register', [CustomerAuthController::class, 'register']);
Route::post('/customer/login', [CustomerAuthController::class, 'login']);

Route::get('/services', function () {
    return Service::query()
        ->where('is_active', true)
        ->orderBy('pricing_type')
        ->orderBy('name')
        ->get();
});

Route::get('/payment-channels', [PaymentChannelController::class, 'index']);

Route::get('/ping', function () {
    return response()->json(['message' => 'pong']);
});

// Protected routes (butuh token sanctum)
Route::middleware('auth:sanctum')->group(function () {

    // auth customer
    Route::post('/customer/logout', [CustomerAuthController::class, 'logout']);
    Route::get('/user', function (Request $request) {
        return $request->user();
    });

    // profil customer
    Route::get('/me', [CustomerProfileController::class, 'show']);
    Route::put('/me', [CustomerProfileController::class, 'update']);
    Route::post('/me/photo', [CustomerProfileController::class, 'uploadPhoto']);
    Route::delete('/me/photo', [CustomerProfileController::class, 'deletePhoto']);

    // orders
    Route::get('/orders', [OrderController::class, 'index']);
    Route::post('/orders', [OrderController::class, 'store']);
    Route::get('/orders/{order}', [OrderController::class, 'show']);

    // payment
   Route::get('/orders/{order}/payment', [\App\Http\Controllers\Api\PaymentController::class, 'show']);
    Route::post('/orders/{order}/payment', [\App\Http\Controllers\Api\PaymentController::class, 'store']);
    // chat per order
    Route::get('/orders/{order}/messages', [ChatController::class, 'index']);
    Route::post('/orders/{order}/messages', [ChatController::class, 'store']);
    Route::post('/orders/{order}/messages/read', [ChatController::class, 'markRead']);

    // notification summary
    Route::get('/notifications/summary', [NotificationController::class, 'summary']);
    Route::get('/notifications/orders', [NotificationController::class, 'orders']);
    Route::get('/notifications/events', [NotificationController::class, 'events']);
    Route::post('/notifications/events/read-all', [NotificationController::class, 'markEventsReadAll']);


        Route::post('/notifications/events/clear', [NotificationController::class, 'clearEvents']);
        Route::delete('/notifications/events/{payment}', [NotificationController::class, 'deleteEvent']);
});
