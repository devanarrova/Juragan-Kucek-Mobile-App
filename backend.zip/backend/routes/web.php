<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\OrderController;
use App\Http\Controllers\Admin\PaymentController as AdminPaymentController;
use App\Http\Controllers\Admin\ChatController as AdminChatController;
use App\Http\Controllers\Admin\ServiceController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\ReportController;
use App\Http\Controllers\Admin\ProfileController;


// Public
Route::get('/', function () {
    return view('welcome');
});

// Admin routes
Route::prefix('admin')->name('admin.')->group(function () {

    // Auth (guest)
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.post');

    // Protected admin
    Route::middleware('admin.auth')->group(function () {

        // /admin -> dashboard
        Route::get('/', fn () => redirect()->route('admin.dashboard'))->name('home');

        // Dashboard
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

        // Logout
        Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

        // ORDERS
        Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');
        // Quick lookup by order_code / hasil scan QR
        // NOTE: wajib didefinisikan sebelum /orders/{order} biar tidak ketangkep route model binding.
        Route::get('/orders/lookup', [OrderController::class, 'lookup'])->name('orders.lookup');
        Route::get('/orders/{order}', [OrderController::class, 'show'])->name('orders.show');
        Route::patch('/orders/{order}', [OrderController::class, 'update'])->name('orders.update');
        Route::delete('/orders/{order}', [OrderController::class, 'destroy'])->name('orders.destroy');

        // ✅ PRINT (nota operasional & kwitansi lunas)
Route::get('/orders/{order}/print-nota', [OrderController::class, 'printNota'])
    ->name('orders.print.nota');

Route::get('/orders/{order}/print-kwitansi', [OrderController::class, 'printKwitansi'])
    ->name('orders.print.kwitansi');

        // Chat per order
        Route::get('/orders/{order}/messages', [AdminChatController::class, 'index'])->name('orders.messages');
        Route::post('/orders/{order}/messages', [AdminChatController::class, 'store'])->name('orders.messages.store');

        // Payment actions (approve/reject)
        Route::post('/orders/{order}/payment/approve', [AdminPaymentController::class, 'approve'])->name('orders.payment.approve');
        Route::post('/orders/{order}/payment/reject', [AdminPaymentController::class, 'reject'])->name('orders.payment.reject');

        // VERIFY
        Route::get('/verify', [AdminPaymentController::class, 'index'])->name('verify.index');

        // SERVICES
        Route::get('/services', [ServiceController::class, 'index'])->name('services.index');
        Route::post('/services', [ServiceController::class, 'store'])->name('services.store');
        Route::patch('/services/{service}', [ServiceController::class, 'update'])->name('services.update');
        Route::patch('/services/{service}/toggle', [ServiceController::class, 'toggle'])->name('services.toggle');
        Route::delete('/services/{service}', [ServiceController::class, 'destroy'])->name('services.destroy');

        // USERS
        Route::get('/users', [UserController::class, 'index'])->name('users.index');
        Route::post('/users/customers', [UserController::class, 'storeCustomer'])->name('users.customers.store');
        Route::patch('/users/customers/{customer}', [UserController::class, 'updateCustomer'])->name('users.customers.update');
        Route::patch('/users/customers/{customer}/toggle', [UserController::class, 'toggleCustomer'])->name('users.customers.toggle');

        Route::delete('/users/customers/{customer}', [UserController::class, 'destroyCustomer'])
            ->middleware('admin.super')
            ->name('users.customers.destroy');

        Route::middleware('admin.super')->group(function () {
            Route::post('/users/admins', [UserController::class, 'storeAdmin'])->name('users.admins.store');
            Route::patch('/users/admins/{admin}', [UserController::class, 'updateAdmin'])->name('users.admins.update');
            Route::patch('/users/admins/{admin}/toggle', [UserController::class, 'toggleAdmin'])->name('users.admins.toggle');
            Route::delete('/users/admins/{admin}', [UserController::class, 'destroyAdmin'])->name('users.admins.destroy');
        });

        // REPORT
        Route::get('/report', [ReportController::class, 'index'])->name('report.index');
        Route::get('/report/export', [ReportController::class, 'export'])->name('report.export');

        Route::get('/profile', [ProfileController::class, 'edit'])->name('profile');
Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
Route::patch('/profile/password', [ProfileController::class, 'updatePassword'])->name('profile.password');

    });
});
