<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class ProfileController extends Controller
{
    public function edit()
    {
        $admin = Auth::guard('admin')->user();
        return view('admin.pages.profile', compact('admin'));
    }

    public function update(Request $request)
    {
        $admin = Auth::guard('admin')->user();

        $data = $request->validateWithBag('profile', [
            'name' => ['required','string','max:100'],
            'username' => ['required','string','max:50', Rule::unique('admins','username')->ignore($admin->id)],
            'profile_photo' => ['nullable','image','mimes:jpg,jpeg,png,webp','max:2048'],
        ]);

        // Upload foto baru
        if ($request->hasFile('profile_photo')) {
            // hapus foto lama kalau ada
            if ($admin->profile_photo) {
                Storage::disk('public')->delete($admin->profile_photo);
            }

            $path = $request->file('profile_photo')->store(
                "admins/{$admin->id}",
                'public'
            );

            $admin->profile_photo = $path;
        }

        $admin->name = $data['name'];
        $admin->username = $data['username'];
        $admin->save();

        // refresh user di session guard biar topbar langsung update
        Auth::guard('admin')->setUser($admin->fresh());

        return back()->with('ok_profile', 'Profil berhasil diperbarui.');
    }

    public function updatePassword(Request $request)
    {
        $admin = Auth::guard('admin')->user();

        $data = $request->validateWithBag('password', [
            'old_password' => ['required','string'],
            'password' => ['required','string','min:6','confirmed'],
        ]);

        if (!Hash::check($data['old_password'], $admin->password)) {
            return back()->withErrors(['old_password' => 'Password lama salah.'], 'password');
        }

        $admin->password = Hash::make($data['password']);
        $admin->save();

        // keamanan: refresh session token
        $request->session()->regenerate();

        return back()->with('ok_password', 'Password berhasil diubah.');
    }
}
