<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin;
use App\Models\Customer;
use App\Models\Message;
use App\Models\OrderStatusHistory;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $me = Auth::guard('admin')->user();
        $canManageAdmins = $me && $me->is_superadmin;

        $type = $request->get('type', 'customers');
        if (!in_array($type, ['customers', 'admins'], true)) $type = 'customers';
        if ($type === 'admins' && !$canManageAdmins) $type = 'customers';

        $customersCount = Customer::count();
        $adminsCount    = Admin::count();

        $search = $request->get('search');
        $active = $request->get('active'); // '', '1', '0'

        if ($type === 'customers') {
            $q = Customer::query()->withCount('orders')->orderByDesc('id');

            if ($search) {
                $q->where(fn($qq) => $qq
                    ->where('name', 'like', "%{$search}%")
                    ->orWhere('username', 'like', "%{$search}%")
                );
            }
            if ($active === '1') $q->where('is_active', true);
            if ($active === '0') $q->where('is_active', false);

            $rows = $q->paginate(10)->withQueryString();
        } else {
            $q = Admin::query()->orderByDesc('id');

            if ($search) {
                $q->where(fn($qq) => $qq
                    ->where('name', 'like', "%{$search}%")
                    ->orWhere('username', 'like', "%{$search}%")
                );
            }
            if ($active === '1') $q->where('is_active', true);
            if ($active === '0') $q->where('is_active', false);

            $rows = $q->paginate(10)->withQueryString();
        }

        return view('admin.pages.users.index', compact(
            'type','rows','customersCount','adminsCount','canManageAdmins'
        ));
    }

    public function storeCustomer(Request $request)
    {
        $data = $request->validate([
            'name' => ['required','string','max:100'],
            'username' => ['required','string','max:50','unique:customers,username'],
            'password' => ['required','string','min:6','confirmed'],
            'is_active' => ['nullable','boolean'],
        ]);

        Customer::create([
            'name' => $data['name'],
            'username' => $data['username'],
            'password' => Hash::make($data['password']),
            'is_active' => (bool)($data['is_active'] ?? true),
        ]);

        return back()->with('ok', 'Customer berhasil dibuat.');
    }

    public function updateCustomer(Request $request, Customer $customer)
    {
        $data = $request->validate([
            'name' => ['required','string','max:100'],
            'username' => ['required','string','max:50', Rule::unique('customers','username')->ignore($customer->id)],
            'password' => ['nullable','string','min:6','confirmed'],
        ]);

        $update = [
            'name' => $data['name'],
            'username' => $data['username'],
        ];

        if (!empty($data['password'])) {
            $update['password'] = Hash::make($data['password']);
            $customer->tokens()->delete();
        }

        $customer->update($update);

        return back()->with('ok', 'Customer berhasil diupdate.');
    }

    public function toggleCustomer(Customer $customer)
    {
        $customer->is_active = !$customer->is_active;
        $customer->save();

        if (!$customer->is_active) {
            $customer->tokens()->delete();
        }

        return back()->with('ok', 'Status customer berhasil diubah.');
    }

    // ✅ HAPUS CUSTOMER (PERMANEN) — SUPERADMIN ONLY
    public function destroyCustomer(Customer $customer)
    {
        abort_unless(Auth::guard('admin')->user()?->is_superadmin, 403);

        // Ini safety penting: kalau ada order, hard delete akan ngehapus histori bisnis (cascade).
        if ($customer->orders()->exists()) {
            return back()->withErrors([
                'delete' => 'Customer tidak bisa dihapus karena sudah punya order. Nonaktifkan saja agar histori tetap aman.',
            ]);
        }

        $customer->tokens()->delete();
        $name = $customer->name;
        $customer->delete(); // hard delete

        return back()->with('ok', "Customer '{$name}' berhasil dihapus permanen.");
    }

    // ===================== ADMIN (SUPERADMIN ONLY) =====================

    public function storeAdmin(Request $request)
    {
        abort_unless(Auth::guard('admin')->user()?->is_superadmin, 403);

        $data = $request->validate([
            'name' => ['required','string','max:100'],
            'username' => ['required','string','max:50','unique:admins,username'],
            'password' => ['required','string','min:6','confirmed'],
            'is_active' => ['nullable','boolean'],
            'is_superadmin' => ['nullable','boolean'],
        ]);

        Admin::create([
            'name' => $data['name'],
            'username' => $data['username'],
            'password' => Hash::make($data['password']),
            'is_active' => (bool)($data['is_active'] ?? true),
            'is_superadmin' => (bool)($data['is_superadmin'] ?? false),
        ]);

        return back()->with('ok', 'Admin berhasil dibuat.');
    }

    public function updateAdmin(Request $request, Admin $admin)
    {
        abort_unless(Auth::guard('admin')->user()?->is_superadmin, 403);

        $data = $request->validate([
            'name' => ['required','string','max:100'],
            'username' => ['required','string','max:50', Rule::unique('admins','username')->ignore($admin->id)],
            'password' => ['nullable','string','min:6','confirmed'],
            'is_superadmin' => ['nullable','boolean'],
        ]);

        $update = [
            'name' => $data['name'],
            'username' => $data['username'],
            'is_superadmin' => (bool)($data['is_superadmin'] ?? $admin->is_superadmin),
        ];

        if (!empty($data['password'])) {
            $update['password'] = Hash::make($data['password']);
        }

        $admin->update($update);

        return back()->with('ok', 'Admin berhasil diupdate.');
    }

    public function toggleAdmin(Admin $admin)
    {
        abort_unless(Auth::guard('admin')->user()?->is_superadmin, 403);

        $me = Auth::guard('admin')->id();
        if ($admin->id === $me) {
            return back()->withErrors(['toggle' => 'Kamu tidak boleh menonaktifkan akunmu sendiri.']);
        }

        $admin->is_active = !$admin->is_active;
        $admin->save();

        return back()->with('ok', 'Status admin berhasil diubah.');
    }

    // ✅ HAPUS ADMIN (PERMANEN) — SUPERADMIN ONLY
    public function destroyAdmin(Admin $admin)
    {
        abort_unless(Auth::guard('admin')->user()?->is_superadmin, 403);

        $me = Auth::guard('admin')->user();

        if ($admin->id === $me->id) {
            return back()->withErrors(['delete' => 'Kamu tidak boleh menghapus akunmu sendiri.']);
        }

        // Jangan sampai sistem kehilangan superadmin terakhir
        if ($admin->is_superadmin && Admin::where('is_superadmin', true)->count() <= 1) {
            return back()->withErrors(['delete' => 'Tidak bisa menghapus superadmin terakhir. Buat superadmin lain dulu.']);
        }

        DB::transaction(function () use ($admin) {
            // Rapihin jejak referensi non-FK biar gak ada id “ngambang”
            OrderStatusHistory::where('changed_by_role', 'admin')
                ->where('changed_by_id', $admin->id)
                ->update(['changed_by_id' => null]);

            Message::where('sender_role', 'admin')
                ->where('sender_id', $admin->id)
                ->update(['sender_id' => null]);

            Payment::where('archived_by_admin_id', $admin->id)
                ->update(['archived_by_admin_id' => null]);

            // verified_by_admin_id punya FK nullOnDelete, aman.
            $admin->delete(); // hard delete
        });

        return back()->with('ok', "Admin '{$admin->name}' berhasil dihapus permanen.");
    }
}
