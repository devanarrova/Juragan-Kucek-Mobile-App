<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;

class AuthController extends Controller
{
    public function showLogin()
    {
        return view('admin.auth.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'username' => ['required','string'],
            'password' => ['required','string'],
        ]);

        // Throttle key per username + IP
        $throttleKey = Str::lower($credentials['username']).'|'.$request->ip();

        if (RateLimiter::tooManyAttempts($throttleKey, 5)) {
            $seconds = RateLimiter::availableIn($throttleKey);

            return back()
                ->withErrors(['username' => "Terlalu banyak percobaan login. Coba lagi dalam {$seconds} detik."])
                ->withInput();
        }

        // Attempt login
        if (!Auth::guard('admin')->attempt($credentials)) {
            RateLimiter::hit($throttleKey, 60); // decay 60 detik
            return back()->withErrors(['username' => 'Username atau password salah'])->withInput();
        }

        // Login success → regen session
        $request->session()->regenerate();

        // Cek status aktif admin
        $admin = Auth::guard('admin')->user();
        if (property_exists($admin, 'is_active') && !$admin->is_active) {
            Auth::guard('admin')->logout();

            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return back()
                ->withErrors(['username' => 'Akun admin dinonaktifkan.'])
                ->withInput();
        }

        // Reset throttle saat sukses
        RateLimiter::clear($throttleKey);

       $displayName = $admin->name ?: $admin->username;

return redirect()
    ->route('admin.dashboard')
    ->with('toast', [
        'type' => 'success',
        'message' => "Selamat datang, {$displayName}",
    ]);

    }

    public function logout(Request $request)
    {
        Auth::guard('admin')->logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('admin.dashboard');

    }
}
