<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ServiceController extends Controller
{
    public function index(Request $request)
    {
        $q = Service::query()->orderByDesc('id');

        if ($request->filled('search')) {
            $s = $request->search;
            $q->where('name', 'like', "%{$s}%");
        }

        if ($request->filled('active')) {
            $q->where('is_active', (int) $request->active);
        }

        $services = $q->paginate(10)->withQueryString();

        return view('admin.pages.services.index', compact('services'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required','string','max:255'],
            'pricing_type' => ['required','in:per_kg,per_item'],
            'unit_label' => ['required','string','max:10'],
            'base_price' => ['required','numeric','min:0'],
            'is_active' => ['nullable','boolean'],
        ]);

        Service::create([
            'name' => $data['name'],
            'pricing_type' => $data['pricing_type'],
            'unit_label' => $data['unit_label'],
            'base_price' => $data['base_price'],
            'is_active' => (bool)($data['is_active'] ?? true),
        ]);

        return back()->with('ok', 'Layanan berhasil ditambahkan.');
    }



public function update(Request $request, Service $service)
{
    $validator = Validator::make($request->all(), [
        'name'         => ['required','string','max:255'],
        'pricing_type' => ['required','in:per_kg,per_item'],
        'unit_label'   => ['required','string','max:10'],
        'base_price'   => ['required','numeric','min:0'],
    ]);

    if ($validator->fails()) {
        return back()
            ->withErrors($validator)
            ->withInput()
            ->with('edit_id', $service->id); // ✅ ini kuncinya
    }

    $service->update([
        'name'         => $request->name,
        'pricing_type' => $request->pricing_type,
        'unit_label'   => $request->unit_label,
        'base_price'   => $request->base_price,
    ]);

    return back()->with('ok', 'Layanan berhasil diperbarui.');
}


    public function toggle(Service $service)
    {
        $service->update(['is_active' => !$service->is_active]);

        return back()->with('ok', 'Status layanan diperbarui.');
        
    }
    public function destroy(Service $service)
{
    // soft delete (aman walau pernah dipakai order)
    $service->delete();

    return back()->with('ok', 'Layanan berhasil dihapus.');
}

}
