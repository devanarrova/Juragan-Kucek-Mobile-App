<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderStatusHistory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    /**
     * Single source of truth alur status order (untuk admin).
     */
    private function statusFlow(): array
    {
        return [
            'MENUNGGU_KONFIRMASI' => ['DIPROSES', 'DIBATALKAN'],
            'DIPROSES' => ['SELESAI_MENUNGGU_PEMBAYARAN', 'DIBATALKAN'],

            // ⚠️ Status pembayaran/verifikasi ini BUKAN diubah dari form update order.
            // - MENUNGGU_VERIFIKASI_PEMBAYARAN: otomatis saat customer upload bukti pembayaran (API).
            // - LUNAS_SIAP_DIANTAR / PEMBAYARAN_DITOLAK: lewat tombol Approve/Reject di bagian Pembayaran.
            'SELESAI_MENUNGGU_PEMBAYARAN' => ['DIBATALKAN'],
            'MENUNGGU_VERIFIKASI_PEMBAYARAN' => [],
            'PEMBAYARAN_DITOLAK' => ['DIBATALKAN'],

            'LUNAS_SIAP_DIANTAR' => ['DIANTAR', 'DIBATALKAN'],
            'DIANTAR' => ['SELESAI'],
            'SELESAI' => [],
            'DIBATALKAN' => [],
        ];
    }

    /**
     * Dropdown filter status di index: urut sesuai alur bisnis (bukan alfabet).
     */
    private function allStatuses(): array
    {
        $flow = $this->statusFlow();

        $ordered = array_keys($flow);

        // jaga-jaga kalau nanti ada status baru yang cuma muncul di "next"
        foreach ($flow as $nextList) {
            foreach ($nextList as $st) {
                if (!in_array($st, $ordered, true)) {
                    $ordered[] = $st;
                }
            }
        }

        return $ordered;
    }

    public function index(Request $request)
    {
        $q = Order::with(['customer', 'service', 'payment'])
            ->withCount([
                // unread untuk admin = pesan dari customer yang belum dibaca (read_at masih null)
                'messages as unread_messages_count' => function ($qq) {
                    $qq->where('sender_role', 'customer')->whereNull('read_at');
                },
            ])
            ->latest();

        if ($request->filled('status')) {
            $q->where('status', $request->status);
        }

        if ($request->filled('search')) {
            $s = $request->search;
            $q->where(function ($qq) use ($s) {
                $qq->where('order_code', 'like', "%{$s}%")
                    ->orWhereHas('customer', function ($c) use ($s) {
                        $c->where('username', 'like', "%{$s}%");
                    });
            });
        }

        $orders = $q->paginate(10)->withQueryString();
        $statuses = $this->allStatuses();

        return view('admin.pages.orders.index', compact('orders', 'statuses'));
    }

    /**
     * P9 — Quick lookup by order_code / hasil scan QR.
     * GET /admin/orders/lookup?code=...
     */
    public function lookup(Request $request)
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:200'],
        ]);

        $raw  = (string) $data['code'];
        $code = $this->extractOrderCode($raw);

        if (!$code) {
            return redirect()
                ->route('admin.orders.index')
                ->with('err', 'Order code tidak valid. Pastikan formatnya benar.');
        }

        $order = Order::query()->where('order_code', $code)->first();

        if (!$order) {
            return redirect()
                ->route('admin.orders.index')
                ->with('err', "Order '{$code}' tidak ditemukan.");
        }

        return redirect()->route('admin.orders.show', $order);
    }

    /**
     * Terima input manual atau payload hasil scan QR.
     * Support contoh:
     * - JK-2026-000123
     * - JK_ORDER:JK-2026-000123
     * - JK_PAID:JK-2026-000123
     * - URL yang punya ?code=... atau path terakhir berisi order_code
     */
    private function extractOrderCode(string $raw): ?string
    {
        $raw = trim($raw);
        if ($raw === '') {
            return null;
        }

        // Kalau QR isinya URL (misal nanti kamu encode link), ambil param code/order_code atau segmen terakhir.
        if (filter_var($raw, FILTER_VALIDATE_URL)) {
            $parts = parse_url($raw);
            $qs = [];
            if (!empty($parts['query'])) {
                parse_str($parts['query'], $qs);
            }
            if (!empty($qs['code'])) {
                $raw = (string) $qs['code'];
            } elseif (!empty($qs['order_code'])) {
                $raw = (string) $qs['order_code'];
            } else {
                $path = (string) ($parts['path'] ?? '');
                $segs = array_values(array_filter(explode('/', $path)));
                if (!empty($segs)) {
                    $raw = (string) end($segs);
                }
            }
        }

        // JSON payload (kalau suatu saat kamu encode JSON)
        $t = trim($raw);
        if ($t !== '' && (str_starts_with($t, '{') || str_starts_with($t, '['))) {
            $j = json_decode($t, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                if (is_array($j)) {
                    $candidate = $j['order_code'] ?? $j['code'] ?? null;
                    if (is_string($candidate) && trim($candidate) !== '') {
                        $raw = $candidate;
                    }
                }
            }
        }

        // Prefix format: JK_ORDER:CODE / JK_PAID:CODE / ORDER:CODE / PAID=CODE
        if (preg_match('/(?:JK[_-]?(?:ORDER|PAID)|ORDER|PAID)\s*[:=]\s*([A-Za-z0-9\-]+)/', $raw, $m)) {
            $raw = $m[1];
        }

        // Kalau string panjang (misal hasil scan ada noise), ambil pola yang paling masuk akal.
        if (preg_match('/(JK-\d{4}-\d{6})/i', $raw, $m)) {
            $raw = $m[1];
        }

        $raw = strtoupper(trim($raw));
        // Sanitasi: biarin A-Z 0-9 dan '-'
        $raw = preg_replace('/[^A-Z0-9-]/', '', $raw);

        return $raw !== '' ? $raw : null;
    }

    public function show(Order $order)
    {
        $order->load(['customer', 'service', 'payment', 'statusHistories']);

        $flow = $this->statusFlow();
        $allowedNext = $flow[$order->status] ?? [];
        $allowedStatuses = array_values(array_unique(array_merge([$order->status], $allowedNext)));

        return view('admin.pages.orders.show', [
            'order' => $order,
            'allowedStatuses' => $allowedStatuses,
        ]);
    }

    public function update(Request $request, Order $order)
    {
        $data = $request->validate([
            'status' => ['required', 'string'],
            'final_qty' => ['nullable', 'numeric', 'min:0'],
            // optional (kalau nanti kamu mau tambah textarea catatan di UI)
            'note' => ['nullable', 'string', 'max:2000'],
        ]);

        $flow = $this->statusFlow();

        $current = (string) $order->status;
        $target  = (string) $data['status'];

        // ⛔ P9.1 Guard: status tertentu tidak boleh diubah manual dari form update
        if ($target !== $current) {
            // otomatis saat customer upload bukti pembayaran
            if ($target === 'MENUNGGU_VERIFIKASI_PEMBAYARAN') {
                return back()->withErrors([
                    'status' => 'Status Menunggu Verifikasi Pembayaran akan berubah otomatis ketika customer mengirim bukti pembayaran.',
                ])->withInput();
            }

            // hanya lewat tombol Approve/Reject (bukan dropdown)
            if (in_array($target, ['LUNAS_SIAP_DIANTAR', 'PEMBAYARAN_DITOLAK'], true)) {
                return back()->withErrors([
                    'status' => 'Perubahan status pembayaran hanya boleh melalui tombol Approve/Reject di bagian Pembayaran.',
                ])->withInput();
            }
        }

        // Validasi transisi (boleh status sama untuk update final_qty di status tertentu)
        if ($target !== $current) {
            $allowed = $flow[$current] ?? [];
            if (!in_array($target, $allowed, true)) {
                return back()->withErrors([
                    'status' => "Transisi status tidak valid: {$current} → {$target}",
                ])->withInput();
            }
        }

        // Hindari bug $update undefined
        $update = ['status' => $target];

        // Hitung final_qty + total_price hanya untuk status ini
        if ($target === 'SELESAI_MENUNGGU_PEMBAYARAN') {
            if (!isset($data['final_qty']) || $data['final_qty'] === null) {
                return back()->withErrors([
                    'final_qty' => 'Final Qty wajib diisi pada status Selesai, Menunggu Pembayaran.',
                ])->withInput();
            }

            $order->loadMissing('service');

            $unitPrice = (float) ($order->service->base_price ?? 0);
            if ($unitPrice <= 0) {
                return back()->withErrors([
                    'final_qty' => 'Harga layanan (base_price) belum diset, tidak bisa hitung total.',
                ])->withInput();
            }

            $finalQty    = (float) $data['final_qty'];
            $totalPrice  = (int) round($finalQty * $unitPrice);

            $update['final_qty']   = $finalQty;
            $update['total_price'] = $totalPrice;
        }

        $adminId = Auth::guard('admin')->id();
        $note    = $data['note'] ?? null;

        DB::transaction(function () use ($order, $update, $current, $target, $adminId, $note) {
            $order->update($update);

            // Catat history hanya saat status berubah
            if ($target !== $current) {
                OrderStatusHistory::create([
                    'order_id' => $order->id,
                    'old_status' => $current,
                    'new_status' => $target,
                    'changed_by_role' => 'admin',
                    'changed_by_id' => $adminId,
                    'note' => $note,
                ]);
            }
        });

        return redirect()
            ->route('admin.orders.show', $order)
            ->with('ok', 'Order berhasil diupdate');
    }

    public function destroy(Order $order)
    {
        $order->loadMissing('payment');

        $canDelete = ($order->status === 'MENUNGGU_KONFIRMASI') && ($order->payment === null);
        if (!$canDelete) {
            return back()->withErrors([
                'delete' => 'Pesanan hanya bisa dihapus jika status masih MENUNGGU_KONFIRMASI dan belum ada pembayaran.',
            ]);
        }

        $orderCode = $order->order_code;
        $order->delete();

        return redirect()
            ->route('admin.orders.index')
            ->with('ok', "Pesanan {$orderCode} berhasil dihapus.");
    }

    public function printNota(Order $order)
{
    $order->load(['customer', 'service', 'payment']);

    // Nota operasional hanya untuk order baru/menunggu konfirmasi
    if ($order->status !== 'MENUNGGU_KONFIRMASI') {
        return back()->withErrors([
            'print' => 'Nota operasional hanya bisa dicetak saat status MENUNGGU_KONFIRMASI.',
        ]);
    }

    return view('admin.pages.orders.print_nota', [
        'order' => $order,
        'printedAt' => now(),
    ]);
}

public function printKwitansi(Order $order)
{
    $order->load(['customer', 'service', 'payment.verifiedByAdmin']);

    // Kwitansi lunas hanya saat order DIANTAR/SELESAI
    if (!in_array($order->status, ['DIANTAR', 'SELESAI'], true)) {
        return back()->withErrors([
            'print' => 'Kwitansi lunas hanya bisa dicetak saat status DIANTAR atau SELESAI.',
        ]);
    }

    // Wajib ada pembayaran APPROVED
    $payment = $order->payment;
    if (!$payment || $payment->status !== 'APPROVED') {
        return back()->withErrors([
            'print' => 'Kwitansi lunas hanya bisa dicetak jika pembayaran sudah APPROVED.',
        ]);
    }

    return view('admin.pages.orders.print_kwitansi', [
        'order' => $order,
        'payment' => $payment,
        'printedAt' => now(),
    ]);
}

}
