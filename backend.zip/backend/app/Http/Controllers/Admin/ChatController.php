<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ChatController extends Controller
{
    public function index(Order $order)
    {
        $conv = Conversation::firstOrCreate(
            ['order_id' => $order->id],
            ['customer_id' => $order->customer_id]
        );

        // Admin membuka chat => semua pesan dari customer dianggap terbaca.
        $conv->messages()
            ->where('sender_role', 'customer')
            ->whereNull('read_at')
            ->update(['read_at' => now()]);

        return response()->json($conv->messages()->orderBy('id')->get());
    }

    public function store(Request $request, Order $order)
    {
        if ($order->status === 'SELESAI') {
            return back()->withErrors([
                'chat' => 'Chat ditutup karena pesanan sudah SELESAI.',
            ]);
        }

        $data = $request->validate([
            'body' => ['required','string','max:2000'],
        ]);

        $conv = Conversation::firstOrCreate(
            ['order_id' => $order->id],
            ['customer_id' => $order->customer_id]
        );

        Message::create([
            'conversation_id' => $conv->id,
            'sender_role' => 'admin',
            'sender_id' => Auth::guard('admin')->id(),
            'body' => $data['body'],
        ]);

        return back()->with('ok', 'Pesan terkirim');
    }
}
