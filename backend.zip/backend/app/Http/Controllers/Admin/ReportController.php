<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Models\Service;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        // Periode untuk TOTAL laporan (mengikuti filter start-end)
        $start = $request->input('start') ?: now()->startOfMonth()->toDateString();
        $end   = $request->input('end')   ?: now()->toDateString();

        $startDt = Carbon::parse($start)->startOfDay();
        $endDt   = Carbon::parse($end)->endOfDay();

        // Input aman (hindari $request->method)
        $method    = $request->input('method');
        $serviceId = $request->input('service_id');
        $search    = $request->input('search');

        // Helper: apply filter non-date agar bisa dipakai ulang untuk chart 30 hari
        $applyNonDateFilters = function ($q) use ($method, $serviceId, $search) {
            if (!empty($method)) {
                $q->where('payments.method', $method);
            }

            if (!empty($serviceId)) {
                $sid = (int) $serviceId;
                $q->whereHas('order', fn ($oq) => $oq->where('service_id', $sid));
            }

            if (!empty($search)) {
                $s = trim($search);
                $q->whereHas('order', function ($oq) use ($s) {
                    $oq->where('order_code', 'like', "%{$s}%")
                       ->orWhereHas('customer', function ($cq) use ($s) {
                           $cq->where('username', 'like', "%{$s}%")
                              ->orWhere('name', 'like', "%{$s}%");
                       });
                });
            }

            return $q;
        };

        // ===== BASE (periode start-end) =====
        $base = Payment::query()
            ->where('payments.status', 'APPROVED')
            ->whereNotNull('payments.verified_at')
            ->whereBetween('payments.verified_at', [$startDt, $endDt]);

        $applyNonDateFilters($base);

        // Agregasi join orders (fallback total_price)
        $agg = (clone $base)
            ->leftJoin('orders', 'orders.id', '=', 'payments.order_id');

        // TOTAL PENDAPATAN: sesuai periode terpilih (start -> end)
        $totalRevenue = (clone $agg)->sum(DB::raw('COALESCE(payments.amount, orders.total_price, 0)'));
        $txCount      = (clone $base)->count();

        // Breakdown metode
        $byMethod = (clone $agg)
            ->select(
                'payments.method',
                DB::raw('COUNT(*) as tx_count'),
                DB::raw('SUM(COALESCE(payments.amount, orders.total_price, 0)) as total')
            )
            ->groupBy('payments.method')
            ->orderByDesc('total')
            ->get();

        // Top layanan (10 teratas)
        $byService = (clone $agg)
            ->leftJoin('services', 'services.id', '=', 'orders.service_id')
            ->selectRaw("
                orders.service_id as service_id,
                COALESCE(services.name,'(Layanan dihapus)') as service_name,
                COUNT(*) as tx_count,
                SUM(COALESCE(payments.amount, orders.total_price, 0)) as total
            ")
            ->groupBy('orders.service_id')
            ->groupBy(DB::raw("COALESCE(services.name,'(Layanan dihapus)')"))
            ->orderByDesc('total')
            ->limit(10)
            ->get();

        // Detail transaksi (paginated)
        $payments = (clone $base)
            ->with(['order.customer', 'order.service', 'verifiedByAdmin'])
            ->orderByDesc('payments.verified_at')
            ->paginate(15)
            ->withQueryString();

        // Dropdown layanan
        $services = Service::orderBy('name')->get(['id', 'name']);

        // Dropdown metode
        $methods = Payment::query()
            ->where('payments.status', 'APPROVED')
            ->whereNotNull('payments.method')
            ->distinct()
            ->orderBy('payments.method')
            ->pluck('payments.method');

        // ===== CHART: TREN 30 HARI (berakhir di end) =====
        $trendEndDt = Carbon::parse($end)->endOfDay();
        $trendStartDt = (clone $trendEndDt)->subDays(29)->startOfDay();

        $trendBase = Payment::query()
            ->where('payments.status', 'APPROVED')
            ->whereNotNull('payments.verified_at')
            ->whereBetween('payments.verified_at', [$trendStartDt, $trendEndDt]);

        $applyNonDateFilters($trendBase);

        $trendAgg = (clone $trendBase)
            ->leftJoin('orders', 'orders.id', '=', 'payments.order_id');

        $trendRows = (clone $trendAgg)
            ->select(
                DB::raw('DATE(payments.verified_at) as day'),
                DB::raw('SUM(COALESCE(payments.amount, orders.total_price, 0)) as total')
            )
            ->groupBy(DB::raw('DATE(payments.verified_at)'))
            ->orderBy('day')
            ->get();

        $trendMap = $trendRows->keyBy('day');

        $trendLabels = [];
        $trendTotals = [];

        for ($i = 0; $i < 30; $i++) {
            $day = (clone $trendStartDt)->addDays($i);
            $key = $day->toDateString();

            $trendLabels[] = $day->format('d M'); // contoh: 20 Des
            $trendTotals[] = (float) (($trendMap[$key]->total ?? 0));
        }

        $trendRangeText = $trendStartDt->toDateString().' s/d '.$trendEndDt->toDateString();

        return view('admin.pages.report.index', compact(
            'payments',
            'services',
            'methods',
            'start',
            'end',
            'totalRevenue',
            'txCount',
            'byMethod',
            'byService',
            'trendLabels',
            'trendTotals',
            'trendRangeText'
        ));
    }

    public function export(Request $request)
    {
        $start = $request->input('start') ?: now()->startOfMonth()->toDateString();
        $end   = $request->input('end')   ?: now()->toDateString();

        $startDt = Carbon::parse($start)->startOfDay();
        $endDt   = Carbon::parse($end)->endOfDay();

        $method    = $request->input('method');
        $serviceId = $request->input('service_id');
        $search    = $request->input('search');

        $q = Payment::query()
            ->where('payments.status', 'APPROVED')
            ->whereNotNull('payments.verified_at')
            ->whereBetween('payments.verified_at', [$startDt, $endDt]);

        if (!empty($method)) {
            $q->where('payments.method', $method);
        }

        if (!empty($serviceId)) {
            $sid = (int) $serviceId;
            $q->whereHas('order', fn ($oq) => $oq->where('service_id', $sid));
        }

        if (!empty($search)) {
            $s = trim($search);
            $q->whereHas('order', function ($oq) use ($s) {
                $oq->where('order_code', 'like', "%{$s}%")
                   ->orWhereHas('customer', function ($cq) use ($s) {
                       $cq->where('username', 'like', "%{$s}%")
                          ->orWhere('name', 'like', "%{$s}%");
                   });
            });
        }

        $fileName = "laporan_pendapatan_{$start}_sd_{$end}.csv";

        return response()->streamDownload(function () use ($q) {
            $out = fopen('php://output', 'w');

            fputcsv($out, [
                'Tanggal Verifikasi',
                'Order Code',
                'Customer',
                'Service',
                'Metode',
                'Nominal',
                'Diverifikasi Oleh',
            ]);

            $q->with(['order.customer', 'order.service', 'verifiedByAdmin'])
              ->orderBy('payments.verified_at')
              ->chunk(500, function ($rows) use ($out) {
                  foreach ($rows as $p) {
                      $amount = $p->amount ?? optional($p->order)->total_price ?? 0;

                      fputcsv($out, [
                          optional($p->verified_at)->format('Y-m-d H:i:s'),
                          optional($p->order)->order_code,
                          optional(optional($p->order)->customer)->name,
                          optional(optional($p->order)->service)->name,
                          $p->method,
                          (string) $amount,
                          optional($p->verifiedByAdmin)->name,
                      ]);
                  }
              });

            fclose($out);
        }, $fileName, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }
}
