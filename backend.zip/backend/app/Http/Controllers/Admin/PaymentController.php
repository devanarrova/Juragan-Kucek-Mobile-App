<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Payment;
use App\Support\TextFilter;
use Illuminate\Http\Request;
use App\Models\OrderStatusHistory;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
class PaymentController extends Controller
{
   public function index(Request $request)
{
    $archived = $request->boolean('archived'); // ?archived=1

    $q = Payment::with(['order.customer', 'order.service'])
        ->latest();

    // ✅ mode aktif vs arsip
    if ($archived) {
        $q->whereNotNull('archived_at');
    } else {
        $q->whereNull('archived_at');
    }

    // filter status pembayaran (optional)
    if ($request->filled('status')) {
        $q->where('status', $request->status);
    } else {
        // ✅ default status by mode (biar tabel relevan)
        if ($archived) {
            $q->where('status', 'APPROVED');
        } else {
            $q->whereIn('status', ['PENDING', 'REJECTED']);
        }
    }

    // search order_code / username / name
    if ($request->filled('search')) {
        $s = $request->search;

        $q->whereHas('order', function ($oq) use ($s) {
            $oq->where('order_code', 'like', "%{$s}%")
                ->orWhereHas('customer', function ($cq) use ($s) {
                    $cq->where('username', 'like', "%{$s}%")
                       ->orWhere('name', 'like', "%{$s}%");
                });
        });
    }

    $payments = $q->paginate(10)->withQueryString();

    // ✅ dropdown status menyesuaikan mode (biar ga misleading)
    $statuses = $archived
        ? ['APPROVED']
        : ['PENDING', 'REJECTED'];

    return view('admin.pages.verify.index', compact('payments', 'statuses', 'archived'));
}


 public function approve(Request $request, Order $order)
{
    $data = $request->validate([
        'admin_note' => ['nullable', 'string', 'max:2000'],
    ]);

    $note = isset($data['admin_note']) ? TextFilter::sanitize($data['admin_note']) : null;
    $note = $note !== null ? trim($note) : null;
    if ($note === '') $note = null;

    $payment = $order->payment;
    if (!$payment) return back()->withErrors(['payment' => 'Pembayaran tidak ditemukan.']);

    if ($payment->status !== 'PENDING') {
        return back()->with('ok', 'Pembayaran sudah diproses sebelumnya.');
    }

    $adminId = Auth::guard('admin')->id();

    DB::transaction(function () use ($payment, $order, $note, $adminId) {
        $payment->update([
            'status' => 'APPROVED',
            'admin_note' => $note,
            'verified_by_admin_id' => $adminId,
            'verified_at' => now(),
            // buat notifikasi customer: unread sampai customer buka tab event
            'customer_read_at' => null,
            'archived_at' => now(),
            'archived_by_admin_id' => $adminId,
        ]);

        $old = (string) $order->status;
        $order->update(['status' => 'LUNAS_SIAP_DIANTAR']);

        OrderStatusHistory::create([
            'order_id' => $order->id,
            'old_status' => $old,
            'new_status' => 'LUNAS_SIAP_DIANTAR',
            'changed_by_role' => 'admin',
            'changed_by_id' => $adminId,
            'note' => $note ? ('Approve pembayaran: ' . $note) : 'Approve pembayaran',
        ]);
    });

    return back()->with('ok', 'Pembayaran disetujui dan diarsipkan dari menu verifikasi.');
}

public function reject(Request $request, Order $order)
{
    $data = $request->validate([
        'admin_note' => ['required', 'string', 'min:3', 'max:2000'],
    ]);

    $note = TextFilter::sanitize($data['admin_note']);
    $note = trim($note);
    if ($note === '' || mb_strlen($note) < 3) {
        return back()->withErrors(['admin_note' => 'Catatan admin minimal 3 karakter.']);
    }

    $payment = $order->payment;
    if (!$payment) return back()->withErrors(['payment' => 'Pembayaran tidak ditemukan.']);

    if ($payment->status !== 'PENDING') {
        return back()->with('ok', 'Pembayaran sudah diproses sebelumnya.');
    }

    $adminId = Auth::guard('admin')->id();

    DB::transaction(function () use ($payment, $order, $note, $adminId) {
        $payment->update([
            'status' => 'REJECTED',
            'admin_note' => $note,
            'verified_by_admin_id' => $adminId,
            'verified_at' => now(),
            // buat notifikasi customer: unread sampai customer buka tab event
            'customer_read_at' => null,
            'archived_at' => null,
            'archived_by_admin_id' => null,
        ]);

        $old = (string) $order->status;
        $order->update(['status' => 'PEMBAYARAN_DITOLAK']);

        OrderStatusHistory::create([
            'order_id' => $order->id,
            'old_status' => $old,
            'new_status' => 'PEMBAYARAN_DITOLAK',
            'changed_by_role' => 'admin',
            'changed_by_id' => $adminId,
            'note' => 'Reject pembayaran: ' . $note,
        ]);
    });

    return back()->with('ok', 'Pembayaran ditolak. Alasan tersimpan dan tetap tampil di menu verifikasi.');
}

}
