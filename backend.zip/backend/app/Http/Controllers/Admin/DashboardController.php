<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Service;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $today = Carbon::today();

        // =====================
        // Counts (quick signals)
        // =====================
        $pendingPaymentsCount = Payment::query()
            ->where('payments.status', 'PENDING')
            ->whereNull('payments.archived_at')
            ->count();

        $ordersNeedConfirmCount = Order::query()
            ->where('orders.status', 'MENUNGGU_KONFIRMASI')
            ->count();

        $ordersInProgressCount = Order::query()
            ->whereIn('orders.status', ['DIPROSES', 'LUNAS_SIAP_DIANTAR', 'DIANTAR'])
            ->count();

        $ordersTodayCount = Order::query()
            ->whereDate('orders.created_at', $today)
            ->count();

        $customersActiveCount = Customer::query()->where('is_active', true)->count();
        $customersTotalCount  = Customer::query()->count();
        $servicesActiveCount  = Service::query()->where('is_active', true)->count();

        // =====================
        // Revenue
        // =====================
        $revenueToday = Payment::query()
            ->leftJoin('orders', 'orders.id', '=', 'payments.order_id')
            ->where('payments.status', 'APPROVED')
            ->whereNotNull('payments.verified_at')
            ->whereBetween('payments.verified_at', [$today->copy()->startOfDay(), $today->copy()->endOfDay()])
            ->sum(DB::raw('COALESCE(payments.amount, orders.total_price, 0)'));

        $monthStart = Carbon::now()->startOfMonth()->startOfDay();
        $monthEnd   = Carbon::now()->endOfMonth()->endOfDay();

        $revenueThisMonth = Payment::query()
            ->leftJoin('orders', 'orders.id', '=', 'payments.order_id')
            ->where('payments.status', 'APPROVED')
            ->whereNotNull('payments.verified_at')
            ->whereBetween('payments.verified_at', [$monthStart, $monthEnd])
            ->sum(DB::raw('COALESCE(payments.amount, orders.total_price, 0)'));

        // =====================
        // Trend 14 hari (approved revenue)
        // =====================
        $trendDays  = 14;
        $trendEnd   = Carbon::today()->endOfDay();
        $trendStart = Carbon::today()->subDays($trendDays - 1)->startOfDay();

        $trendRows = Payment::query()
            ->leftJoin('orders', 'orders.id', '=', 'payments.order_id')
            ->where('payments.status', 'APPROVED')
            ->whereNotNull('payments.verified_at')
            ->whereBetween('payments.verified_at', [$trendStart, $trendEnd])
            ->select(
                DB::raw('DATE(payments.verified_at) as d'),
                DB::raw('SUM(COALESCE(payments.amount, orders.total_price, 0)) as total')
            )
            ->groupBy(DB::raw('DATE(payments.verified_at)'))
            ->orderBy('d')
            ->get();

        $trendMap = $trendRows->keyBy('d');
        $trendLabels = [];
        $trendTotals = [];

        for ($i = 0; $i < $trendDays; $i++) {
            $d = $trendStart->copy()->addDays($i);
            $key = $d->toDateString();
            $trendLabels[] = $d->format('d M');
            $trendTotals[] = (float) optional($trendMap->get($key))->total ?? 0;
        }

        $trendRangeText = $trendStart->toDateString() . ' s/d ' . $trendEnd->toDateString();

        // =====================
        // Top layanan (30 hari) by revenue
        // =====================
        $topStart = Carbon::today()->subDays(29)->startOfDay();

        $topServices = Payment::query()
            ->leftJoin('orders', 'orders.id', '=', 'payments.order_id')
            ->leftJoin('services', 'services.id', '=', 'orders.service_id')
            ->where('payments.status', 'APPROVED')
            ->whereNotNull('payments.verified_at')
            ->whereBetween('payments.verified_at', [$topStart, $trendEnd])
            ->select(
                'orders.service_id as service_id',
                'services.name as service_name',
                DB::raw('COUNT(*) as tx_count'),
                DB::raw('SUM(COALESCE(payments.amount, orders.total_price, 0)) as total')
            )
            ->groupBy('orders.service_id', 'services.name')
            ->orderByDesc('total')
            ->limit(6)
            ->get();

        // =====================
        // Recent lists
        // =====================
        $recentOrders = Order::with(['customer', 'service', 'payment'])
            ->latest('orders.id')
            ->limit(8)
            ->get();

        $pendingPayments = Payment::with(['order.customer', 'order.service'])
            ->where('payments.status', 'PENDING')
            ->whereNull('payments.archived_at')
            ->latest('payments.id')
            ->limit(6)
            ->get();

        return view('admin.pages.dashboard', compact(
            'pendingPaymentsCount',
            'ordersNeedConfirmCount',
            'ordersInProgressCount',
            'ordersTodayCount',
            'customersActiveCount',
            'customersTotalCount',
            'servicesActiveCount',
            'revenueToday',
            'revenueThisMonth',
            'trendLabels',
            'trendTotals',
            'trendRangeText',
            'topServices',
            'recentOrders',
            'pendingPayments'
        ));
    }
}
