<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\Payment;
use App\Support\TextFilter;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class NotificationController extends Controller
{
    private function paymentTitle(string $status): string
    {
        return match ($status) {
            'APPROVED' => 'Pembayaran diterima',
            'REJECTED' => 'Pembayaran ditolak',
            default => 'Update pembayaran',
        };
    }

    private function paymentDefaultMessage(string $status): string
    {
        return match ($status) {
            'APPROVED' => 'Pembayaran kamu sudah diterima. Pesanan akan diproses sesuai antrian.',
            'REJECTED' => 'Pembayaran kamu ditolak. Silakan upload ulang bukti pembayaran yang lebih jelas.',
            default => 'Ada update pada pembayaran pesanan kamu.',
        };
    }

    // GET /api/notifications/summary?since=ISO8601
    public function summary(Request $request)
    {
        $customer = $request->user();

        // 1) Unread message dari admin (semua order milik customer)
        $conversationIds = Conversation::where('customer_id', $customer->id)->pluck('id');

        $unread_messages = Message::whereIn('conversation_id', $conversationIds)
            ->where('sender_role', 'admin')
            ->whereNull('read_at')
            ->count();

        // 2) Unread event pembayaran (APPROVED/REJECTED) untuk order milik customer
        $unread_events = Payment::query()
            ->whereIn('status', ['APPROVED', 'REJECTED'])
            ->whereNotNull('verified_at')
            ->whereNull('customer_read_at')
            ->whereNull('customer_hidden_at')
            ->whereHas('order', fn ($q) => $q->where('customer_id', $customer->id))
            ->count();

        // 3) Order updates sejak "since" (opsional)
        $updates = 0;
        $since = $request->query('since');
        if ($since) {
            try {
                $sinceDt = Carbon::parse($since);
                $updates = Payment::query()
                    ->whereHas('order', fn ($q) => $q->where('customer_id', $customer->id))
                    ->where('updated_at', '>', $sinceDt)
                    ->count();
            } catch (\Throwable $e) {
                $updates = 0;
            }
        }

        return response()->json([
            'unread_messages' => $unread_messages,
            'unread_events' => $unread_events,
            'order_updates_since' => $updates,
            'server_time' => now()->toIso8601String(),
        ]);
    }

    // GET /api/notifications/orders
    // (chat unread per order) - tetap sama: dipakai badge per order pada tab Riwayat.
    public function orders(Request $request)
    {
        $customer = $request->user();

        $orders = \App\Models\Order::where('customer_id', $customer->id)
            ->select('id', 'updated_at')
            ->orderByDesc('id')
            ->get();

        $orderIds = $orders->pluck('id');

        $conversations = Conversation::whereIn('order_id', $orderIds)
            ->get(['id', 'order_id']);

        $convByOrder = $conversations->keyBy('order_id');
        $convIds = $conversations->pluck('id');

        $unreadByConversation = Message::selectRaw('conversation_id, COUNT(*) as c')
            ->whereIn('conversation_id', $convIds)
            ->where('sender_role', 'admin')
            ->whereNull('read_at')
            ->groupBy('conversation_id')
            ->pluck('c', 'conversation_id');

        $result = $orders->map(function ($o) use ($convByOrder, $unreadByConversation) {
            $conv = $convByOrder->get($o->id);
            $unread = 0;
            if ($conv) {
                $unread = (int) ($unreadByConversation[$conv->id] ?? 0);
            }
            return [
                'order_id' => $o->id,
                'unread_messages' => $unread,
                'updated_at' => $o->updated_at?->toIso8601String(),
            ];
        });

        return response()->json([
            'data' => $result,
            'server_time' => now()->toIso8601String(),
        ]);
    }

    // GET /api/notifications/events
    // Event dibatasi ke keputusan pembayaran (APPROVED/REJECTED)
    public function events(Request $request)
    {
        $customer = $request->user();
        $limit = (int) $request->query('limit', 50);
        $limit = max(1, min(100, $limit));

        $items = Payment::query()
            ->whereIn('status', ['APPROVED', 'REJECTED'])
            ->whereNotNull('verified_at')
            ->whereNull('customer_hidden_at')
            ->whereHas('order', fn ($q) => $q->where('customer_id', $customer->id))
            ->orderByDesc('verified_at')
            ->orderByDesc('id')
            ->limit($limit)
            ->get()
            ->map(function (Payment $p) {
                $msg = trim((string) ($p->admin_note ?? ''));
                if ($msg === '') {
                    $msg = $this->paymentDefaultMessage((string) $p->status);
                }
                $msg = TextFilter::sanitize($msg);
                return [
                    'id' => $p->id,
                    'type' => 'payment',
                    'order_id' => (int) $p->order_id,
                    'payment_id' => (int) $p->id,
                    'status' => (string) $p->status,
                    'title' => $this->paymentTitle((string) $p->status),
                    'message' => $msg,
                    'created_at' => $p->verified_at?->toIso8601String() ?? $p->updated_at?->toIso8601String(),
                    'read_at' => $p->customer_read_at?->toIso8601String(),
                ];
            });

        return response()->json([
            'data' => $items,
            'server_time' => now()->toIso8601String(),
        ]);
    }


    // DELETE /api/notifications/events/{payment}
    public function deleteEvent(Request $request, Payment $payment)
    {
        $customer = $request->user();

        if (!$payment->order || (int) $payment->order->customer_id !== (int) $customer->id) {
            return response()->json(['message' => 'Forbidden'], 403);
        }

        if (!in_array((string) $payment->status, ['APPROVED', 'REJECTED'], true) || !$payment->verified_at) {
            return response()->json(['message' => 'Event pembayaran tidak valid.'], 422);
        }

        $now = now();
        $payment->update([
            'customer_hidden_at' => $now,
            'customer_read_at' => $payment->customer_read_at ?? $now,
        ]);

        return response()->json([
            'ok' => true,
            'server_time' => $now->toIso8601String(),
        ]);
    }

    // POST /api/notifications/events/clear
    public function clearEvents(Request $request)
    {
        $customer = $request->user();
        $now = now();

        // Hide semua event pembayaran (approved/rejected) milik customer
        $base = Payment::query()
            ->whereIn('status', ['APPROVED', 'REJECTED'])
            ->whereNotNull('verified_at')
            ->whereNull('customer_hidden_at')
            ->whereHas('order', fn ($q) => $q->where('customer_id', $customer->id));

        $hidden = (clone $base)->update(['customer_hidden_at' => $now]);

        $markedRead = Payment::query()
            ->whereIn('status', ['APPROVED', 'REJECTED'])
            ->whereNotNull('verified_at')
            ->whereNull('customer_read_at')
            ->whereHas('order', fn ($q) => $q->where('customer_id', $customer->id))
            ->update(['customer_read_at' => $now]);

        return response()->json([
            'ok' => true,
            'hidden' => $hidden,
            'marked_read' => $markedRead,
            'server_time' => $now->toIso8601String(),
        ]);
    }

    // POST /api/notifications/events/read-all
    public function markEventsReadAll(Request $request)
    {
        $customer = $request->user();
        $now = now();

        $updated = Payment::query()
            ->whereIn('status', ['APPROVED', 'REJECTED'])
            ->whereNotNull('verified_at')
            ->whereNull('customer_read_at')
            ->whereNull('customer_hidden_at')
            ->whereHas('order', fn ($q) => $q->where('customer_id', $customer->id))
            ->update(['customer_read_at' => $now]);

        return response()->json([
            'ok' => true,
            'updated' => $updated,
            'server_time' => $now->toIso8601String(),
        ]);
    }
}
