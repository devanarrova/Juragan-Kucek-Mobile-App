<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\Order;
use Illuminate\Http\Request;

class ChatController extends Controller
{
    public function index(Request $request, Order $order)
    {
        $customer = $request->user();
        if ($order->customer_id !== $customer->id) {
            return response()->json(['message' => 'Forbidden'], 403);
        }

        $conv = Conversation::firstOrCreate(
            ['order_id' => $order->id],
            ['customer_id' => $order->customer_id]
        );

        $messages = $conv->messages()->orderBy('id')->get();
        return response()->json($messages);
    }

    public function store(Request $request, Order $order)
    {
        $customer = $request->user();
        if ($order->customer_id !== $customer->id) {
            return response()->json(['message' => 'Forbidden'], 403);
        }

        // Order selesai => chat ditutup.
        if ($order->status === 'SELESAI') {
            return response()->json([
                'message' => 'Chat ditutup karena pesanan sudah SELESAI.',
            ], 422);
        }

        $data = $request->validate([
            'body' => ['required','string','max:2000'],
        ]);

        $conv = Conversation::firstOrCreate(
            ['order_id' => $order->id],
            ['customer_id' => $order->customer_id]
        );

        $msg = Message::create([
            'conversation_id' => $conv->id,
            'sender_role' => 'customer',
            'sender_id' => $customer->id,
            'body' => $data['body'],
        ]);

        return response()->json($msg, 201);
    }

    public function markRead(Request $request, Order $order)
{
    $customer = $request->user();

    if ($order->customer_id !== $customer->id) {
        return response()->json(['message' => 'Forbidden'], 403);
    }

    $conv = Conversation::firstOrCreate(
        ['order_id' => $order->id],
        ['customer_id' => $order->customer_id]
    );

    $conv->messages()
        ->where('sender_role', 'admin')
        ->whereNull('read_at')
        ->update(['read_at' => now()]);

    return response()->json(['message' => 'ok']);
}

}
