<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class CustomerProfileController extends Controller
{
    private function customerPayload(Request $request)
    {
        $customer = $request->user();

        $data = $customer->toArray();
        $data['profile_photo_url'] = $customer->profile_photo
            ? ($request->getSchemeAndHttpHost() . Storage::url($customer->profile_photo))
            : null;

        return $data;
    }

    /**
     * GET /api/me
     * Return profil customer yang sedang login.
     */
    public function show(Request $request)
    {
        return response()->json([
            'customer' => $this->customerPayload($request),
        ]);
    }

    /**
     * PUT /api/me
     * Update profil customer yang sedang login.
     */
    public function update(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'min:3', 'max:100'],
            'phone' => ['required', 'string', 'max:30'],
            'default_address' => ['required', 'string'],
        ]);

        $customer = $request->user();
        $customer->fill([
            'name' => $data['name'],
            'phone' => $data['phone'],
            'default_address' => $data['default_address'],
        ]);
        $customer->save();

        return response()->json([
            'message' => 'Profil berhasil diperbarui',
            'customer' => $this->customerPayload($request),
        ]);
    }

    /**
     * POST /api/me/photo
     * Upload / ganti foto profil customer yang sedang login.
     * form-data: photo (file)
     */
    public function uploadPhoto(Request $request)
    {
        $request->validate([
            'photo' => ['required', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
        ]);

        $customer = $request->user();

        // hapus foto lama (kalau ada)
        if (!empty($customer->profile_photo)) {
            Storage::disk('public')->delete($customer->profile_photo);
        }

        $path = $request->file('photo')->store('profile_photos', 'public');
        $customer->profile_photo = $path;
        $customer->save();

        return response()->json([
            'message' => 'Foto profil berhasil diperbarui',
            'customer' => $this->customerPayload($request),
        ]);
    }

    /**
     * DELETE /api/me/photo
     * Hapus foto profil customer.
     */
    public function deletePhoto(Request $request)
    {
        $customer = $request->user();

        if (!empty($customer->profile_photo)) {
            Storage::disk('public')->delete($customer->profile_photo);
        }

        $customer->profile_photo = null;
        $customer->save();

        return response()->json([
            'message' => 'Foto profil berhasil dihapus',
            'customer' => $this->customerPayload($request),
        ]);
    }
}
