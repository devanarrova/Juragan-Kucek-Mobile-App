<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class CustomerAuthController extends Controller
{
    public function register(Request $request)
    {
        $data = $request->validate([
            'name' => ['required','string','max:100'],
            'username' => ['required','string','max:50','unique:customers,username'],
            'password' => ['required','string','min:6'],
        ]);

        $customer = Customer::create([
            'name' => $data['name'],
            'username' => $data['username'],
            'password' => Hash::make($data['password']),
        ]);

        $token = $customer->createToken('customer-token')->plainTextToken;

        return response()->json(['token' => $token, 'customer' => $customer], 201);
    }

    public function login(Request $request)
    {
        $data = $request->validate([
            'username' => ['required','string'],
            'password' => ['required','string'],
        ]);

        $customer = Customer::where('username', $data['username'])->first();
if (!$customer || !Hash::check($data['password'], $customer->password)) {
    return response()->json(['message' => 'Username atau password salah'], 401);
}

if (!$customer->is_active) {
    return response()->json(['message' => 'Akun dinonaktifkan. Hubungi admin.'], 403);
}


        $token = $customer->createToken('customer-token')->plainTextToken;

        return response()->json(['token' => $token, 'customer' => $customer]);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['message' => 'Logout berhasil']);
    }
}
