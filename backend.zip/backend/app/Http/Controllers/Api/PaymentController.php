<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Payment;
use App\Models\OrderStatusHistory;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class PaymentController extends Controller
{
    public function store(Request $request, Order $order)
    {
        $customer = $request->user();

        // Pastikan order milik customer yang login
        if ((int) $order->customer_id !== (int) $customer->id) {
            return response()->json(['message' => 'Tidak boleh akses order ini'], 403);
        }

        // Validasi input dulu (biar error 422 jelas & konsisten)
        $data = $request->validate(
            [
                'method' => ['required', 'string', Rule::in(['BANK_TRANSFER', 'E_WALLET'])],
                'channel_code' => ['required', 'string', 'max:30'],
                // amount sengaja tetap diterima (untuk kompatibilitas), tapi SERVER yang jadi sumber kebenaran
                'amount' => ['nullable', 'numeric', 'min:0'],
                'customer_note' => ['nullable', 'string'],
                'proof' => ['required', 'image', 'max:5120'], // max 5MB
            ],
            [
                'method.required' => 'Metode pembayaran wajib dipilih.',
                'method.in' => 'Metode pembayaran tidak valid.',
                'channel_code.required' => 'Channel pembayaran wajib dipilih.',
                'channel_code.max' => 'Channel pembayaran tidak valid.',
                'amount.numeric' => 'Nominal pembayaran tidak valid.',
                'proof.required' => 'Bukti pembayaran wajib diunggah.',
                'proof.image' => 'Bukti pembayaran harus berupa gambar.',
                'proof.max' => 'Ukuran bukti pembayaran maksimal 5MB.',
            ]
        );

        // Ambil channel detail dari config
        $channels = $data['method'] === 'BANK_TRANSFER'
            ? (array) config('payment_channels.banks', [])
            : (array) config('payment_channels.ewallets', []);

        $channel = collect($channels)->firstWhere('code', $data['channel_code']);
        if (!$channel) {
            return response()->json(
                [
                    'message' => 'Channel pembayaran tidak valid',
                    'errors' => ['channel_code' => ['Channel tidak ditemukan untuk metode ini.']],
                ],
                422
            );
        }

        // =====================
        // Anti-duplikasi (P0):
        // - Jika sudah PENDING: blok (jangan replace bukti seenaknya)
        // - Jika sudah APPROVED: blok
        // - Jika REJECTED: boleh re-upload (replace bukti)
        // - Handle race condition (double submit) dengan lock + cleanup file
        // =====================

        $newPath = null;
        $oldPath = null;

        try {
            $payment = DB::transaction(function () use ($request, $order, $customer, $data, $channel, &$newPath, &$oldPath) {
                // Lock order supaya status/total_price konsisten dalam transaksi
                $lockedOrder = Order::whereKey($order->id)->lockForUpdate()->firstOrFail();

                // Safety: pastikan owner tetap sama
                if ((int) $lockedOrder->customer_id !== (int) $customer->id) {
                    throw ValidationException::withMessages([
                        'order' => ['Tidak boleh akses order ini'],
                    ]);
                }

                // hanya boleh bayar jika admin sudah set total_price
                if ($lockedOrder->total_price === null) {
                    throw ValidationException::withMessages([
                        'total_price' => ['Total harga belum ditentukan admin.'],
                    ]);
                }

                // status yang boleh bayar
                $allowed = ['SELESAI_MENUNGGU_PEMBAYARAN', 'PEMBAYARAN_DITOLAK'];
                if (!in_array($lockedOrder->status, $allowed, true)) {
                    throw ValidationException::withMessages([
                        'status' => ['Order belum masuk tahap pembayaran.'],
                    ]);
                }

                // Lock row payment (kalau ada) untuk cegah double submit bersamaan
                $existing = Payment::where('order_id', $lockedOrder->id)->lockForUpdate()->first();

                if ($existing) {
                    if ($existing->status === 'APPROVED') {
                        throw ValidationException::withMessages([
                            'payment' => ['Pembayaran sudah disetujui. Tidak bisa upload ulang.'],
                        ]);
                    }

                    if ($existing->status === 'PENDING') {
                        throw ValidationException::withMessages([
                            'payment' => ['Pembayaran sudah dikirim dan sedang diverifikasi. Mohon tunggu.'],
                        ]);
                    }

                    // REJECTED: boleh replace bukti
                    if ($existing->status === 'REJECTED') {
                        $oldPath = $existing->proof_path;
                    }
                }

                // Upload file setelah lolos semua pengecekan (biar gak numpuk file sampah)
                $newPath = $request->file('proof')->store('payments', 'public');

                $payment = Payment::updateOrCreate(
                    ['order_id' => $lockedOrder->id],
                    [
                        'method' => $data['method'],
                        'channel_code' => $channel['code'] ?? null,
                        'channel_name' => $channel['name'] ?? null,
                        'destination_account' => $channel['account_number'] ?? null,
                        'destination_holder' => $channel['account_name'] ?? null,

                        // SERVER source of truth
                        'amount' => $lockedOrder->total_price,

                        'customer_note' => $data['customer_note'] ?? null,
                        'proof_path' => $newPath,
                        'status' => 'PENDING',

                        'admin_note' => null,
                        'verified_by_admin_id' => null,
                        'verified_at' => null,
                        'archived_at' => null,
                        'archived_by_admin_id' => null,
                    ]
                );

                // update status order (otomatis saat customer upload bukti)
                $oldStatus = (string) $lockedOrder->status;
                $lockedOrder->update(['status' => 'MENUNGGU_VERIFIKASI_PEMBAYARAN']);

                // catat timeline agar admin melihat perubahan ini berasal dari customer
                OrderStatusHistory::create([
                    'order_id' => $lockedOrder->id,
                    'old_status' => $oldStatus,
                    'new_status' => 'MENUNGGU_VERIFIKASI_PEMBAYARAN',
                    'changed_by_role' => 'customer',
                    'changed_by_id' => $customer->id,
                    'note' => 'Customer mengirim bukti pembayaran (status: PENDING).',
                    // customer sudah tahu dia upload, jadi tandai read
                    'customer_read_at' => now(),
                ]);

                return $payment;
            }, 3);

            // Hapus bukti lama setelah transaksi sukses (REJECTED -> reupload)
            if ($oldPath) {
                Storage::disk('public')->delete($oldPath);
            }

            return response()->json($payment, 201);
        } catch (ValidationException $e) {
            // cleanup file baru kalau sempat ter-upload
            if ($newPath) {
                Storage::disk('public')->delete($newPath);
            }
            throw $e;
        } catch (QueryException $e) {
            // cleanup file baru kalau sempat ter-upload
            if ($newPath) {
                Storage::disk('public')->delete($newPath);
            }

            // Race condition insert karena unique(order_id)
            $msg = $e->getMessage();
            if ($e->getCode() === '23000' || str_contains($msg, 'payments_order_id_unique')) {
                return response()->json(
                    ['message' => 'Pembayaran sudah ada dan sedang diproses. Mohon tunggu verifikasi admin.'],
                    409
                );
            }

            throw $e;
        }
    }

    public function show(Request $request, Order $order)
    {
        $customer = $request->user();

        if ((int) $order->customer_id !== (int) $customer->id) {
            return response()->json(['message' => 'Tidak boleh akses order ini'], 403);
        }

        $order->load('payment');

        return response()->json([
            'payment' => $order->payment,
            'reject_reason' => ($order->payment && $order->payment->status === 'REJECTED')
                ? $order->payment->admin_note
                : null,
        ]);
    }
}
