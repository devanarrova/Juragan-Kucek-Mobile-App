<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        $customer = $request->user();

       
    $orders = Order::with(['service','payment'])
    ->where('customer_id', $customer->id)
    ->orderByDesc('id')
    ->get()
    ->map(function ($o) {
        $o->setAttribute(
            'reject_reason',
            ($o->payment && $o->payment->status === 'REJECTED')
                ? $o->payment->admin_note
                : null
        );
        return $o;
    });

return response()->json($orders);

            

        
    }

    public function store(Request $request)
    {
        $customer = $request->user();

        $data = $request->validate(
            [
                'service_id' => ['required', 'exists:services,id'],
                'estimated_qty' => ['required', 'numeric', 'min:0.1'],
                'pickup_date' => ['required', 'date'],
                'pickup_address' => ['required', 'string'],
                'notes' => ['nullable', 'string'],
            ],
            [
                'service_id.required' => 'Layanan wajib dipilih.',
                'service_id.exists' => 'Layanan tidak ditemukan.',
                'estimated_qty.required' => 'Estimasi qty wajib diisi.',
                'estimated_qty.numeric' => 'Estimasi qty harus berupa angka.',
                'estimated_qty.min' => 'Estimasi qty minimal 0.1.',
                'pickup_date.required' => 'Tanggal pickup wajib diisi.',
                'pickup_date.date' => 'Tanggal pickup tidak valid.',
                'pickup_address.required' => 'Alamat pickup wajib diisi.',
                'pickup_address.string' => 'Alamat pickup tidak valid.',
            ]
        );

        $service = Service::findOrFail($data['service_id']);
        if (!$service->is_active) {
            return response()->json(['message' => 'Layanan tidak aktif'], 422);
        }

        // =====================
        // Anti order dobel (P0):
        // - kalau user double-tap / jaringan retry, server jangan bikin 2 order yang sama.
        // - heuristik: cari order identik yang dibuat dalam 60 detik terakhir.
        // =====================

        $order = DB::transaction(function () use ($customer, $service, $data) {
            $existing = Order::where('customer_id', $customer->id)
                ->where('service_id', $service->id)
                ->where('pickup_date', $data['pickup_date'])
                ->where('pickup_address', $data['pickup_address'])
                ->where('estimated_qty', $data['estimated_qty'])
                ->whereIn('status', ['MENUNGGU_KONFIRMASI', 'DIPROSES'])
                ->where('created_at', '>=', now()->subSeconds(60))
                ->latest('id')
                ->first();

            if ($existing) {
                return $existing;
            }

            $orderCode = 'JK' . now()->format('ymd') . strtoupper(Str::random(4));

            return Order::create([
                'order_code' => $orderCode,
                'customer_id' => $customer->id,
                'service_id' => $service->id,
                'estimated_qty' => $data['estimated_qty'],
                'pickup_date' => $data['pickup_date'],
                'pickup_address' => $data['pickup_address'],
                'notes' => $data['notes'] ?? null,
                'status' => 'MENUNGGU_KONFIRMASI',
            ]);
        });

        // Kalau yang dikembalikan order existing, tetap balikin payload order seperti biasa.
        // Status code 200 supaya jelas ini bukan create baru (tapi mobile tetap akan treat success).
        $statusCode = $order->wasRecentlyCreated ? 201 : 200;
        return response()->json($order->load('service'), $statusCode);
    }

   public function show(Request $request, Order $order)
{
    $customer = $request->user();

    if (!$customer) {
        return response()->json(['message' => 'Unauthenticated'], 401);
    }

    if ((int) $order->customer_id !== (int) $customer->id) {
        return response()->json(['message' => 'Tidak boleh akses order ini'], 403);
    }

    $order->load([
        'service',
        'payment',
        'statusHistories' => function ($q) {
            $q->orderBy('id', 'asc'); // timeline urut dari awal ke akhir
        },
    ]);
    
    $order->setAttribute(
    'reject_reason',
    ($order->payment && $order->payment->status === 'REJECTED')
        ? $order->payment->admin_note
        : null
);


    return response()->json($order);
}

}
