<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PaymentChannelController extends Controller
{
    public function index(Request $request)
    {
        // return daftar bank + e-wallet untuk ditampilkan di aplikasi
        return response()->json([
            'banks' => config('payment_channels.banks', []),
            'ewallets' => config('payment_channels.ewallets', []),
        ]);
    }
}
