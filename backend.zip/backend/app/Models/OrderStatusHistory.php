<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderStatusHistory extends Model
{
    protected $fillable = [
        'order_id',
        'old_status',
        'new_status',
        'changed_by_role',
        'changed_by_id',
        'note',
        'customer_read_at',
    ];

    public function order()
    {
        return $this->belongsTo(Order::class);
    }
}
