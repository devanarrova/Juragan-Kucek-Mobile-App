<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = [
        'order_code',
        'customer_id',
        'service_id',
        'estimated_qty',
        'pickup_date',
        'pickup_address',
        'notes',
        'final_qty',
        'total_price',
        'status',
    ];

    public function customer()
{
    return $this->belongsTo(\App\Models\Customer::class);
}

public function service()
{
    return $this->belongsTo(\App\Models\Service::class)->withTrashed();
}


public function payment()
{
    return $this->hasOne(\App\Models\Payment::class);
}

public function conversation()
{
    return $this->hasOne(\App\Models\Conversation::class);
}

/**
 * Semua pesan chat per pesanan (lewat tabel conversations).
 * Dipakai untuk hitung unread badge di admin.
 */
public function messages()
{
    return $this->hasManyThrough(
        \App\Models\Message::class,
        \App\Models\Conversation::class,
        'order_id',        // FK di conversations
        'conversation_id', // FK di messages
        'id',              // PK orders
        'id'               // PK conversations
    );
}

public function statusHistories()
{
    return $this->hasMany(\App\Models\OrderStatusHistory::class)->orderBy('id');
}

}
