<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    protected $fillable = [
        'order_id',
        'method', // BANK_TRANSFER / E_WALLET
        'channel_code',
        'channel_name',
        'destination_account',
        'destination_holder',
        'amount',
        'proof_path',
        'status',
        'customer_note',
        'admin_note',
        'verified_by_admin_id',
        'verified_at',
        'customer_read_at',
        'customer_hidden_at',
        'archived_at',
        'archived_by_admin_id',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'verified_at' => 'datetime',
        'customer_read_at' => 'datetime',
        'customer_hidden_at' => 'datetime',
        'archived_at' => 'datetime',
    ];

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function verifiedByAdmin()
    {
        return $this->belongsTo(Admin::class, 'verified_by_admin_id');
    }
}
