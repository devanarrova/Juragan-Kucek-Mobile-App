<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Admin extends Authenticatable
{
    protected $fillable = ['name', 'username', 'password', 'is_active', 'is_superadmin', 'profile_photo'];
    protected $hidden = ['password'];

    protected $casts = [
        'is_active' => 'boolean',
        'is_superadmin' => 'boolean',
    ];
}
