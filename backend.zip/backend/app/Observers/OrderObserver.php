<?php

namespace App\Observers;

use App\Models\Order;
use App\Models\OrderStatusHistory;
use Illuminate\Support\Facades\Auth;

class OrderObserver
{
    public function created(Order $order): void
    {
        // catat status awal saat order dibuat
        $role = 'system';
        $id = null;

        if (Auth::guard('admin')->check()) {
            $role = 'admin';
            $id = Auth::guard('admin')->id();
        } elseif (Auth::check()) {
            $role = 'customer';
            $id = Auth::id();
        }

        OrderStatusHistory::create([
            'order_id' => $order->id,
            'old_status' => null,
            'new_status' => $order->status,
            'changed_by_role' => $role,
            'changed_by_id' => $id,
            'note' => null,
        ]);
    }

    public function updated(Order $order): void
    {
        // hanya catat kalau status benar-benar berubah
        if (!$order->wasChanged('status')) return;

        $old = $order->getOriginal('status');
        $new = $order->status;

        $role = 'system';
        $id = null;

        if (Auth::guard('admin')->check()) {
            $role = 'admin';
            $id = Auth::guard('admin')->id();
        } elseif (Auth::check()) {
            $role = 'customer';
            $id = Auth::id();
        }

        OrderStatusHistory::create([
            'order_id' => $order->id,
            'old_status' => $old,
            'new_status' => $new,
            'changed_by_role' => $role,
            'changed_by_id' => $id,
            'note' => null,
        ]);
    }
}
