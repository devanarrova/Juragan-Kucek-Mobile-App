<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use App\Models\Payment;
use App\Models\Order;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

  public function boot(): void
{
    View::composer(['admin.layouts.*', 'components.admin.*'], function ($view) {

        $pendingPaymentsCount = Payment::query()
            ->where('payments.status', 'PENDING')
            ->whereNull('payments.archived_at')
            ->count();

        $ordersNeedConfirmCount = Order::query()
            ->where('orders.status', 'MENUNGGU_KONFIRMASI')
            ->count();

        $view->with(compact('pendingPaymentsCount', 'ordersNeedConfirmCount'));
    });
}
}
