<?php

namespace App\Support;

class TextFilter
{
    /**
     * Filter ringan untuk kebutuhan demo / produksi.
     * Tujuan: mencegah kata-kata sensitif muncul di UI (notif pembayaran) karena data dummy.
     *
     * NOTE: Ini bukan sistem moderasi konten lengkap.
     */
    public static function sanitize(?string $text): string
    {
        $t = trim((string) $text);
        if ($t === '') return '';

        // Daftar kata yang ingin disamarkan (case-insensitive).
        // Keep it minimal: fokus ke kasus demo yang sudah kejadian.
        $bad = [
            'hitler',
            'nazi',
        ];

        $escaped = array_map(static fn ($w) => preg_quote($w, '/'), $bad);
        $pattern = '/\\b(' . implode('|', $escaped) . ')\\b/i';

        return preg_replace($pattern, '***', $t) ?? $t;
    }
}
