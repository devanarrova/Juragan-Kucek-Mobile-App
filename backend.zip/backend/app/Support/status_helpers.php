<?php
use Carbon\Carbon;

if (! function_exists('status_label')) {
    function status_label(?string $status): string
    {
        if (!$status) return '-';

        $map = [
            'MENUNGGU_KONFIRMASI' => 'Menunggu Konfirmasi',
            'DIPROSES' => 'Diproses',
            'SELESAI_MENUNGGU_PEMBAYARAN' => 'Selesai, Menunggu Pembayaran',
            'MENUNGGU_VERIFIKASI_PEMBAYARAN' => 'Menunggu Verifikasi Pembayaran',
            'PEMBAYARAN_DITOLAK' => 'Pembayaran Ditolak',
            'LUNAS_SIAP_DIANTAR' => 'Lunas, Siap Diantar',
            'DIANTAR' => 'Diantar',
            'SELESAI' => 'Selesai',
            'DIBATALKAN' => 'Dibatalkan',
        ];

        return $map[$status] ?? ucwords(strtolower(str_replace('_', ' ', $status)));
    }
}

if (! function_exists('status_icon')) {
    function status_icon(?string $status): string
    {
        return match ($status) {
            'MENUNGGU_KONFIRMASI' => 'fa-regular fa-hourglass',
            'DIPROSES' => 'fa-solid fa-gears',
            'SELESAI_MENUNGGU_PEMBAYARAN' => 'fa-solid fa-receipt',
            'MENUNGGU_VERIFIKASI_PEMBAYARAN' => 'fa-solid fa-file-invoice-dollar',
            'PEMBAYARAN_DITOLAK' => 'fa-solid fa-circle-xmark',
            'LUNAS_SIAP_DIANTAR' => 'fa-solid fa-circle-check',
            'DIANTAR' => 'fa-solid fa-truck-fast',
            'SELESAI' => 'fa-solid fa-flag-checkered',
            'DIBATALKAN' => 'fa-solid fa-ban',
            default => 'fa-regular fa-circle',
        };
    }
}

if (! function_exists('status_badge_class')) {
    function status_badge_class(?string $status): string
    {
        return match ($status) {
            'MENUNGGU_KONFIRMASI' => 'bg-slate-100 text-slate-700',
            'DIPROSES' => 'bg-blue-100 text-blue-700',
            'SELESAI_MENUNGGU_PEMBAYARAN' => 'bg-amber-100 text-amber-800',
            'MENUNGGU_VERIFIKASI_PEMBAYARAN' => 'bg-violet-100 text-violet-700',
            'PEMBAYARAN_DITOLAK' => 'bg-red-100 text-red-700',
            'LUNAS_SIAP_DIANTAR' => 'bg-emerald-100 text-emerald-700',
            'DIANTAR' => 'bg-indigo-100 text-indigo-700',
            'SELESAI' => 'bg-emerald-100 text-emerald-700',
            'DIBATALKAN' => 'bg-slate-200 text-slate-700',
            default => 'bg-slate-100 text-slate-700',
        };
    }
    



if (! function_exists('rupiah')) {
    function rupiah($amount, int $decimals = 0): string
    {
        if ($amount === null || $amount === '') return '-';

        // pastikan numeric
        $num = is_numeric($amount) ? (float) $amount : 0;

        return 'Rp ' . number_format($num, $decimals, ',', '.');
    }
}

if (! function_exists('tgl_id')) {
    /**
     * Format tanggal Indonesia: "19 Des 2025"
     * Menerima: Carbon|DateTime|string (Y-m-d / Y-m-d H:i:s)
     */
    function tgl_id($date, string $format = 'd M Y'): string
    {
        if (!$date) return '-';

        try {
            $d = $date instanceof \DateTimeInterface ? Carbon::instance($date) : Carbon::parse($date);

            // pakai month mapping biar konsisten walau locale server tidak diset
            $months = [
                1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'Mei', 6 => 'Jun',
                7 => 'Jul', 8 => 'Agu', 9 => 'Sep', 10 => 'Okt', 11 => 'Nov', 12 => 'Des',
            ];

            // Kalau format default "d M Y", kita custom "M" pakai mapping
            if ($format === 'd M Y') {
                $m = $months[(int) $d->month] ?? $d->format('M');
                return $d->format('d') . ' ' . $m . ' ' . $d->format('Y');
            }

            // Kalau kamu minta format lain, fallback ke format Carbon biasa
            return $d->format($format);
        } catch (\Throwable $e) {
            return '-';
        }
    }
}

}
