<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
  'href' => '#',
  'active' => false,
  'icon' => null,
  'badge' => 0,
  'badgeTone' => 'indigo', // indigo | violet | amber (badge khusus, optional)
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
  'href' => '#',
  'active' => false,
  'icon' => null,
  'badge' => 0,
  'badgeTone' => 'indigo', // indigo | violet | amber (badge khusus, optional)
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
  $badge = (int) ($badge ?? 0);

  $base = 'flex items-center justify-between gap-3 px-4 py-3 rounded-xl transition group';

  // ACTIVE: hijau custom #1F717C
  $cls  = $active
    ? 'bg-[#1F717C]/10 text-[#1F717C] ring-1 ring-[#1F717C]/20'
    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900';

  $iconWrap = $active
    ? 'bg-[#1F717C] text-white shadow-sm'
    : 'bg-slate-100 text-slate-600 group-hover:bg-slate-200';

  // Badge tone (untuk prioritas), tetap beda warna biar prioritas kebaca
  $badgeClass = match($badgeTone) {
    'violet' => 'bg-violet-600 text-white',
    'amber'  => 'bg-amber-500 text-white',
    // default: kalau mau ikut warna active, pakai hijau
    default  => 'bg-[#1F717C] text-white',
  };
?>

<a href="<?php echo e($href); ?>" class="<?php echo e($base); ?> <?php echo e($cls); ?>">
  <div class="flex items-center gap-3 min-w-0">
    <?php if($icon): ?>
      <span class="w-9 h-9 rounded-lg inline-flex items-center justify-center <?php echo e($iconWrap); ?> transition">
        <i class="<?php echo e($icon); ?>"></i>
      </span>
    <?php endif; ?>

    <span class="font-semibold truncate">
      <?php echo e($slot); ?>

    </span>
  </div>

  <?php if($badge > 0): ?>
    <span class="min-w-[26px] h-6 px-2 rounded-full text-xs font-extrabold inline-flex items-center justify-center <?php echo e($badgeClass); ?>"
          title="Butuh perhatian">
      <?php echo e($badge); ?>

    </span>
  <?php endif; ?>
</a>
<?php /**PATH C:\xampp\htdocs\Juragan_Kucek_Project\backend\resources\views/components/admin/nav-item.blade.php ENDPATH**/ ?>