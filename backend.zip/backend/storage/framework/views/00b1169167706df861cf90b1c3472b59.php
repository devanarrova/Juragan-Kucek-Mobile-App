<?php $__env->startSection('title','Jenis Layanan'); ?>
<?php $__env->startSection('page_title','Jenis Layanan'); ?>

<?php $__env->startSection('content'); ?>
<?php
  $hasSearch = request()->filled('search');
  $hasActive = request()->filled('active');

  $pricingLabel = fn($v) => match($v) {
    'per_kg'   => 'Per Kg',
    'per_item' => 'Per Item',
    default    => $v ?? '-',
  };

  // Auto-open create modal kalau ada old input (create) dan tidak sedang edit
  $openCreateOnLoad = $errors->any()
    && !session('edit_id')
    && (old('name') || old('pricing_type') || old('unit_label') || old('base_price'));
?>

<div class="space-y-4">

  
  <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-3">
    <div>
      <h2 class="text-2xl font-bold text-slate-900">Jenis Layanan</h2>
      <p class="text-sm text-slate-500 mt-1">Kelola layanan, harga, dan status aktif.</p>
    </div>

    <div class="flex items-center gap-2">
      <span class="inline-flex items-center gap-2 px-3 py-2 rounded-2xl bg-white border border-slate-200 text-sm text-slate-600 shadow-sm">
        <i class="fa-solid fa-tags text-slate-500"></i>
        Total: <b class="text-slate-800"><?php echo e($services->total()); ?></b>
      </span>

      <button type="button"
              onclick="openCreateService()"
              class="px-4 py-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.99] transition inline-flex items-center gap-2 shadow-sm">
        <i class="fa-solid fa-plus"></i>
        Tambah
      </button>
    </div>
  </div>

  
  <?php if(session('ok')): ?>
    <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-2xl p-4 flex items-start gap-3 shadow-sm">
      <i class="fa-solid fa-circle-check mt-0.5"></i>
      <div class="font-semibold"><?php echo e(session('ok')); ?></div>
    </div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
    <div class="bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4 shadow-sm">
      <div class="font-bold flex items-center gap-2">
        <i class="fa-solid fa-triangle-exclamation"></i>
        Ada input yang salah
      </div>
      <ul class="list-disc pl-5 mt-2 text-sm space-y-1">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($e); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
      <div class="text-xs text-red-600 mt-2">Modal akan dibuka otomatis agar kamu bisa memperbaiki input.</div>
    </div>
  <?php endif; ?>

  
  <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
    <form class="grid grid-cols-1 md:grid-cols-12 gap-3">
      <div class="md:col-span-6 relative">
        <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
        <input
          name="search"
          value="<?php echo e(request('search')); ?>"
          placeholder="Cari nama layanan..."
          class="w-full rounded-xl border border-slate-200 pl-10 pr-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200"
        />
      </div>

      <div class="md:col-span-4 relative">
        <i class="fa-solid fa-toggle-on absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
        <select
          name="active"
          class="w-full rounded-xl border border-slate-200 pl-10 pr-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200"
        >
          <option value="">Semua</option>
          <option value="1" <?php if(request('active')==='1'): echo 'selected'; endif; ?>>Aktif</option>
          <option value="0" <?php if(request('active')==='0'): echo 'selected'; endif; ?>>Nonaktif</option>
        </select>
      </div>

      <div class="md:col-span-2 flex gap-2">
        <button class="flex-1 px-4 py-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.99] transition inline-flex items-center justify-center gap-2 shadow-sm">
          <i class="fa-solid fa-filter"></i> Terapkan
        </button>
        <a href="<?php echo e(route('admin.services.index')); ?>"
           class="px-4 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 active:scale-[0.99] transition inline-flex items-center justify-center"
           title="Reset">
          <i class="fa-solid fa-rotate-left text-slate-500"></i>
        </a>
      </div>
    </form>

    
    <?php if($hasSearch || $hasActive): ?>
      <div class="mt-3 flex flex-wrap items-center gap-2">
        <span class="text-xs text-slate-500">Filter aktif:</span>

        <?php if($hasSearch): ?>
          <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-slate-50 text-slate-700">
            <i class="fa-solid fa-magnifying-glass text-slate-500"></i>
            Search: "<?php echo e(request('search')); ?>"
            <a class="ml-1 text-slate-500 hover:text-slate-700"
               href="<?php echo e(route('admin.services.index', array_filter(['active'=>request('active')]))); ?>"
               title="Hapus search">
              <i class="fa-solid fa-xmark"></i>
            </a>
          </span>
        <?php endif; ?>

        <?php if($hasActive): ?>
          <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-slate-50 text-slate-700">
            <i class="fa-solid fa-toggle-on text-slate-500"></i>
            Status: <?php echo e(request('active')==='1' ? 'Aktif' : 'Nonaktif'); ?>

            <a class="ml-1 text-slate-500 hover:text-slate-700"
               href="<?php echo e(route('admin.services.index', array_filter(['search'=>request('search')]))); ?>"
               title="Hapus status">
              <i class="fa-solid fa-xmark"></i>
            </a>
          </span>
        <?php endif; ?>

        <a href="<?php echo e(route('admin.services.index')); ?>"
           class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 active:scale-[0.99] transition">
          <i class="fa-solid fa-trash-can"></i>
          Reset semua
        </a>
      </div>
    <?php endif; ?>
  </div>

  
  <div class="hidden md:block bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="bg-slate-50 text-slate-600 sticky top-0">
          <tr>
            <th class="text-left px-4 py-3">Layanan</th>
            <th class="text-left px-4 py-3">Tipe</th>
            <th class="text-left px-4 py-3">Unit</th>
            <th class="text-left px-4 py-3">Harga Dasar</th>
            <th class="text-left px-4 py-3">Status</th>
            <th class="text-right px-4 py-3">Aksi</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
          <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="hover:bg-slate-50 transition">
              <td class="px-4 py-3">
                <div class="font-semibold text-slate-900"><?php echo e($s->name); ?></div>
                <div class="text-xs text-slate-500">ID: <?php echo e($s->id); ?></div>
              </td>

              <td class="px-4 py-3 text-slate-700">
                <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-slate-50">
                  <i class="fa-solid fa-tag text-slate-500"></i>
                  <?php echo e($pricingLabel($s->pricing_type)); ?>

                </span>
              </td>

              <td class="px-4 py-3 text-slate-700">
                <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-white">
                  <i class="fa-solid fa-ruler text-slate-500"></i>
                  <?php echo e($s->unit_label); ?>

                </span>
              </td>

              <td class="px-4 py-3 font-extrabold text-slate-900">
                <?php echo e(rupiah($s->base_price)); ?>

              </td>

              <td class="px-4 py-3">
                <?php if($s->is_active): ?>
                  <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-emerald-200 bg-emerald-50 text-emerald-700">
                    <i class="fa-solid fa-circle-check"></i> Aktif
                  </span>
                <?php else: ?>
                  <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-slate-100 text-slate-700">
                    <i class="fa-solid fa-circle-minus"></i> Nonaktif
                  </span>
                <?php endif; ?>
              </td>

              <td class="px-4 py-3">
                <div class="flex items-center justify-end gap-2">

                  
                  <button type="button"
                          class="btn-edit-service inline-flex items-center justify-center w-10 h-10 rounded-xl border border-slate-200 hover:bg-slate-50 active:scale-[0.99] transition"
                          title="Edit"
                          data-id="<?php echo e($s->id); ?>"
                          data-name="<?php echo e($s->name); ?>"
                          data-pricing-type="<?php echo e($s->pricing_type); ?>"
                          data-unit-label="<?php echo e($s->unit_label); ?>"
                          data-base-price="<?php echo e((string) $s->base_price); ?>">
                    <i class="fa-solid fa-pen text-slate-600"></i>
                  </button>

                  
                  <form method="POST" action="<?php echo e(route('admin.services.toggle', $s)); ?>"
                        onsubmit="return confirm('Ubah status layanan: <?php echo e($s->name); ?>?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button type="submit"
                            class="inline-flex items-center gap-2 px-4 h-10 rounded-xl border <?php echo e($s->is_active ? 'border-red-200 bg-red-50 text-red-600 hover:bg-red-100' : 'border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100'); ?> active:scale-[0.99] transition text-xs font-bold">
                      <i class="fa-solid <?php echo e($s->is_active ? 'fa-ban' : 'fa-circle-check'); ?>"></i>
                      <?php echo e($s->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?>

                    </button>
                  </form>

                  
                  <form method="POST"
                        action="<?php echo e(route('admin.services.destroy', $s)); ?>"
                        onsubmit="return confirm('Hapus layanan: <?php echo e($s->name); ?>?\\nAksi ini menghapus dari daftar (soft delete).');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit"
                            class="inline-flex items-center justify-center w-10 h-10 rounded-xl border border-red-200 bg-red-50 text-red-600 hover:bg-red-100 active:scale-[0.99] transition"
                            title="Hapus">
                      <i class="fa-solid fa-trash-can"></i>
                    </button>
                  </form>

                </div>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="6" class="px-4 py-10">
                <div class="bg-white rounded-2xl border border-slate-200 p-10 text-center text-slate-500 shadow-sm">
                  <i class="fa-regular fa-folder-open text-3xl"></i>
                  <div class="mt-2 font-semibold text-slate-700">Belum ada layanan</div>
                  <div class="text-sm mt-1">Klik tombol <b>Tambah</b> untuk membuat layanan pertama.</div>
                </div>
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  
  <div class="grid grid-cols-1 gap-3 md:hidden">
    <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
        <div class="flex items-start justify-between gap-3">
          <div class="min-w-0">
            <div class="font-bold text-slate-900 truncate"><?php echo e($s->name); ?></div>
            <div class="text-xs text-slate-500 mt-1"><?php echo e($pricingLabel($s->pricing_type)); ?> • <?php echo e($s->unit_label); ?></div>
            <div class="mt-2 font-extrabold text-slate-900"><?php echo e(rupiah($s->base_price)); ?></div>

            <div class="mt-2">
              <?php if($s->is_active): ?>
                <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-emerald-200 bg-emerald-50 text-emerald-700">
                  <i class="fa-solid fa-circle-check"></i> Aktif
                </span>
              <?php else: ?>
                <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-slate-100 text-slate-700">
                  <i class="fa-solid fa-circle-minus"></i> Nonaktif
                </span>
              <?php endif; ?>
            </div>
          </div>

          <div class="flex flex-col items-end gap-2">

            
            <button type="button"
                    class="btn-edit-service inline-flex items-center justify-center w-10 h-10 rounded-xl border border-slate-200 hover:bg-slate-50 active:scale-[0.99] transition"
                    title="Edit"
                    data-id="<?php echo e($s->id); ?>"
                    data-name="<?php echo e($s->name); ?>"
                    data-pricing-type="<?php echo e($s->pricing_type); ?>"
                    data-unit-label="<?php echo e($s->unit_label); ?>"
                    data-base-price="<?php echo e((string) $s->base_price); ?>">
              <i class="fa-solid fa-pen text-slate-600"></i>
            </button>

            
            <form method="POST" action="<?php echo e(route('admin.services.toggle', $s)); ?>"
                  onsubmit="return confirm('Ubah status layanan: <?php echo e($s->name); ?>?');">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PATCH'); ?>
              <button type="submit"
                      class="inline-flex items-center justify-center w-10 h-10 rounded-xl border <?php echo e($s->is_active ? 'border-red-200 bg-red-50 text-red-600 hover:bg-red-100' : 'border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100'); ?> active:scale-[0.99] transition"
                      title="<?php echo e($s->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?>">
                <i class="fa-solid <?php echo e($s->is_active ? 'fa-ban' : 'fa-circle-check'); ?>"></i>
              </button>
            </form>

            
            <form method="POST"
                  action="<?php echo e(route('admin.services.destroy', $s)); ?>"
                  onsubmit="return confirm('Hapus layanan: <?php echo e($s->name); ?>?\\nAksi ini menghapus dari daftar (soft delete).');">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit"
                      class="inline-flex items-center justify-center w-10 h-10 rounded-xl border border-red-200 bg-red-50 text-red-600 hover:bg-red-100 active:scale-[0.99] transition"
                      title="Hapus">
                <i class="fa-solid fa-trash-can"></i>
              </button>
            </form>

          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div class="bg-white rounded-2xl border border-slate-200 p-10 text-center text-slate-500 shadow-sm">
        <i class="fa-regular fa-folder-open text-3xl"></i>
        <div class="mt-2 font-semibold text-slate-700">Belum ada layanan</div>
        <div class="text-sm mt-1">Klik tombol <b>Tambah</b> untuk membuat layanan pertama.</div>
      </div>
    <?php endif; ?>
  </div>

  <div class="pt-2">
    <?php echo e($services->links()); ?>

  </div>

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('modals'); ?>


<div id="createServiceModal" class="hidden" aria-hidden="true">
  <div class="fixed inset-0 z-[99999] flex items-center justify-center p-4">
    <div data-modal-overlay
         class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm opacity-0 transition-opacity duration-150"></div>

    <div data-modal-panel
         class="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden opacity-0 translate-y-2 scale-[0.98] transition duration-150"
         role="dialog" aria-modal="true" aria-labelledby="createTitle">
      <div class="px-6 py-4 border-b border-slate-200 bg-white flex items-center justify-between">
        <div>
          <div class="text-xs text-slate-500">Tambah</div>
          <div id="createTitle" class="text-lg font-bold text-slate-900 flex items-center gap-2">
            <i class="fa-solid fa-tags text-slate-600"></i>
            Layanan Baru
          </div>
        </div>
        <button type="button"
                data-modal-close
                class="w-10 h-10 rounded-xl border border-slate-200 hover:bg-slate-50 active:scale-[0.99] transition inline-flex items-center justify-center text-slate-500"
                title="Tutup">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>

      <form method="POST" action="<?php echo e(route('admin.services.store')); ?>" class="p-6 bg-slate-50 space-y-4 js-loading-form">
        <?php echo csrf_field(); ?>

        <div class="grid grid-cols-1 gap-3">
          <div>
            <label class="text-xs font-bold text-slate-600">Nama Layanan</label>
            <input id="c_name" name="name" required value="<?php echo e(old('name')); ?>"
                   class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200"
                   placeholder="Cuci Kering, Setrika, ...">
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label class="text-xs font-bold text-slate-600">Tipe Harga</label>
              <select name="pricing_type" required
                      class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
                <option value="per_kg" <?php if(old('pricing_type','per_kg')==='per_kg'): echo 'selected'; endif; ?>>Per Kg</option>
                <option value="per_item" <?php if(old('pricing_type')==='per_item'): echo 'selected'; endif; ?>>Per Item</option>
              </select>
            </div>

            <div>
              <label class="text-xs font-bold text-slate-600">Unit Label</label>
              <input name="unit_label" required maxlength="10" value="<?php echo e(old('unit_label')); ?>"
                     class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200"
                     placeholder="kg / pcs">
            </div>
          </div>

          <div>
            <label class="text-xs font-bold text-slate-600">Harga Dasar</label>
            <input id="c_base_price" name="base_price" type="number" min="0" step="0.01" required value="<?php echo e(old('base_price')); ?>"
                   class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200"
                   placeholder="Contoh: 7000">
            <div class="text-[11px] text-slate-500 mt-1">
              Preview: <span id="c_price_preview" class="font-bold text-slate-700">-</span>
            </div>
          </div>

          <div class="flex items-center gap-2">
            <input type="hidden" name="is_active" value="0">
            <input id="c_is_active" type="checkbox" name="is_active" value="1" <?php if(old('is_active',1)==1): echo 'checked'; endif; ?>
                   class="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-200">
            <label for="c_is_active" class="text-sm text-slate-700">Aktifkan layanan</label>
          </div>
        </div>

        <div class="flex items-center justify-end gap-2 pt-2">
          <button type="button"
                  data-modal-close
                  class="px-4 py-2 rounded-xl border border-slate-200 hover:bg-white active:scale-[0.99] transition">
            Batal
          </button>
          <button type="submit"
                  data-submit-label="Simpan"
                  class="px-4 py-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.99] transition inline-flex items-center gap-2 shadow-sm">
            <i class="fa-solid fa-floppy-disk"></i>
            Simpan
          </button>
        </div>
      </form>
    </div>
  </div>
</div>


<div id="editServiceModal" class="hidden" aria-hidden="true">
  <div class="fixed inset-0 z-[99999] flex items-center justify-center p-4">
    <div data-modal-overlay
         class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm opacity-0 transition-opacity duration-150"></div>

    <div data-modal-panel
         class="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden opacity-0 translate-y-2 scale-[0.98] transition duration-150"
         role="dialog" aria-modal="true" aria-labelledby="editTitle">
      <div class="px-6 py-4 border-b border-slate-200 bg-white flex items-center justify-between">
        <div>
          <div class="text-xs text-slate-500">Edit</div>
          <div class="text-lg font-bold text-slate-900 flex items-center gap-2">
            <i class="fa-solid fa-pen text-slate-600"></i>
            <span id="e_title">Layanan</span>
          </div>
        </div>
        <button type="button"
                data-modal-close
                class="w-10 h-10 rounded-xl border border-slate-200 hover:bg-slate-50 active:scale-[0.99] transition inline-flex items-center justify-center text-slate-500"
                title="Tutup">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>

      <form id="editServiceForm" method="POST" action="#" class="p-6 bg-slate-50 space-y-4 js-loading-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <div>
          <label class="text-xs font-bold text-slate-600">Nama Layanan</label>
          <input id="e_name" name="name" required
                 class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label class="text-xs font-bold text-slate-600">Tipe Harga</label>
            <select id="e_pricing_type" name="pricing_type" required
                    class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
              <option value="per_kg">Per Kg</option>
              <option value="per_item">Per Item</option>
            </select>
          </div>

          <div>
            <label class="text-xs font-bold text-slate-600">Unit Label</label>
            <input id="e_unit_label" name="unit_label" required maxlength="10"
                   class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
          </div>
        </div>

        <div>
          <label class="text-xs font-bold text-slate-600">Harga Dasar</label>
          <input id="e_base_price" name="base_price" type="number" min="0" step="0.01" required
                 class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
          <div class="text-[11px] text-slate-500 mt-1">
            Preview: <span id="e_price_preview" class="font-bold text-slate-700">-</span>
          </div>
        </div>

        <div class="flex items-center justify-end gap-2 pt-2">
          <button type="button"
                  data-modal-close
                  class="px-4 py-2 rounded-xl border border-slate-200 hover:bg-white active:scale-[0.99] transition">
            Batal
          </button>
          <button type="submit"
                  data-submit-label="Simpan Perubahan"
                  class="px-4 py-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.99] transition inline-flex items-center gap-2 shadow-sm">
            <i class="fa-solid fa-floppy-disk"></i>
            Simpan Perubahan
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
  const createModal = document.getElementById('createServiceModal');
  const editModal   = document.getElementById('editServiceModal');

  const updateUrlTemplate = <?php echo json_encode(route('admin.services.update', ['service' => '__ID__']), 512) ?>;

  let lastFocusedEl = null;

  function formatRupiah(n) {
    const x = Number(n);
    if (!Number.isFinite(x)) return '-';
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(x);
  }

  function lockScroll(lock) {
    document.documentElement.style.overflow = lock ? 'hidden' : '';
  }

  function showModal(modal, focusSelector) {
    if (!modal) return;

    lastFocusedEl = document.activeElement;
    modal.classList.remove('hidden');
    modal.setAttribute('aria-hidden', 'false');

    const overlay = modal.querySelector('[data-modal-overlay]');
    const panel   = modal.querySelector('[data-modal-panel]');

    // animate in
    requestAnimationFrame(() => {
      overlay?.classList.remove('opacity-0');
      overlay?.classلاحظList?.add?.('opacity-100');
      panel?.classList.remove('opacity-0','translate-y-2','scale-[0.98]');
      panel?.classList.add('opacity-100','translate-y-0','scale-100');
    });

    lockScroll(true);

    setTimeout(() => {
      const el = focusSelector ? modal.querySelector(focusSelector) : null;
      el?.focus?.();
    }, 50);
  }

  function hideModal(modal) {
    if (!modal || modal.classList.contains('hidden')) return;

    const overlay = modal.querySelector('[data-modal-overlay]');
    const panel   = modal.querySelector('[data-modal-panel]');

    overlay?.classList.add('opacity-0');
    panel?.classList.remove('opacity-100','translate-y-0','scale-100');
    panel?.classList.add('opacity-0','translate-y-2','scale-[0.98]');

    setTimeout(() => {
      modal.classList.add('hidden');
      modal.setAttribute('aria-hidden', 'true');
      lockScroll(false);
      if (lastFocusedEl && lastFocusedEl.focus) lastFocusedEl.focus();
    }, 160);
  }

  // Global open/close functions (dipakai onclick tombol)
  window.openCreateService = () => showModal(createModal, '#c_name');
  window.closeCreateService = () => hideModal(createModal);
  window.closeEditService = () => hideModal(editModal);

  function openEditServiceFromBtn(btn) {
    const payload = {
      id: btn.dataset.id,
      name: btn.dataset.name,
      pricing_type: btn.dataset.pricingType,
      unit_label: btn.dataset.unitLabel,
      base_price: btn.dataset.basePrice,
    };

    const form = document.getElementById('editServiceForm');
    document.getElementById('e_title').textContent = payload.name || 'Layanan';
    document.getElementById('e_name').value = payload.name ?? '';
    document.getElementById('e_pricing_type').value = payload.pricing_type ?? 'per_kg';
    document.getElementById('e_unit_label').value = payload.unit_label ?? '';
    document.getElementById('e_base_price').value = payload.base_price ?? '';
    document.getElementById('e_price_preview').textContent = formatRupiah(payload.base_price);

    form.action = updateUrlTemplate.replace('__ID__', payload.id);

    showModal(editModal, '#e_name');
  }

  // Delegation: edit button click
  document.addEventListener('click', (e) => {
    const btnEdit = e.target.closest('.btn-edit-service');
    if (btnEdit) {
      e.preventDefault();
      openEditServiceFromBtn(btnEdit);
      return;
    }

    // close buttons
    const closeBtn = e.target.closest('[data-modal-close]');
    if (closeBtn) {
      const modal = closeBtn.closest('[id$="Modal"]');
      hideModal(modal);
      return;
    }

    // click backdrop to close
    const modalRoot = e.target.closest('[id$="Modal"]');
    if (modalRoot && e.target.matches('[data-modal-overlay]')) {
      hideModal(modalRoot);
      return;
    }
  });

  // ESC close
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (createModal && !createModal.classList.contains('hidden')) hideModal(createModal);
    if (editModal && !editModal.classList.contains('hidden')) hideModal(editModal);
  });

  // Price preview (create)
  const cPrice = document.getElementById('c_base_price');
  const cPrev  = document.getElementById('c_price_preview');
  if (cPrice && cPrev) {
    const sync = () => cPrev.textContent = formatRupiah(cPrice.value);
    cPrice.addEventListener('input', sync);
    sync();
  }

  // Price preview (edit)
  const ePrice = document.getElementById('e_base_price');
  const ePrev  = document.getElementById('e_price_preview');
  if (ePrice && ePrev) {
    const sync = () => ePrev.textContent = formatRupiah(ePrice.value);
    ePrice.addEventListener('input', sync);
  }

  // Disable submit + show "Menyimpan..." (prevent spam)
  document.querySelectorAll('.js-loading-form').forEach(form => {
    form.addEventListener('submit', () => {
      const btn = form.querySelector('button[type="submit"][data-submit-label]');
      if (!btn) return;

      btn.disabled = true;
      btn.classList.add('opacity-70', 'cursor-not-allowed');

      const label = btn.getAttribute('data-submit-label') || 'Simpan';
      btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Menyimpan...`;
      btn.setAttribute('aria-busy', 'true');
    });
  });

  // Auto-open modal if there are errors
  <?php if($openCreateOnLoad): ?>
    window.openCreateService();
  <?php endif; ?>

  <?php if(session('edit_id')): ?>
    // Cari tombol edit dengan data-id itu, lalu buka modal edit
    const id = <?php echo json_encode((string) session('edit_id'), 15, 512) ?>;
    const btn = document.querySelector('.btn-edit-service[data-id="'+id+'"]');
    if (btn) openEditServiceFromBtn(btn);
  <?php endif; ?>
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Juragan_Kucek_Project\backend\resources\views/admin/pages/services/index.blade.php ENDPATH**/ ?>