<?php
  $pendingPaymentsCount   = (int) ($pendingPaymentsCount ?? 0);
  $ordersNeedConfirmCount = (int) ($ordersNeedConfirmCount ?? 0);
?>

<aside class="w-64 bg-white text-slate-600 flex-shrink-0 flex flex-col shadow-xl z-20 border-r border-slate-200 no-print">
  <div class="h-20 flex items-center justify-center border-b border-slate-100 bg-white px-6 gap-3">
  <img
    src="<?php echo e(asset('assets/img/logo-juragan-kucek.png')); ?>"
    alt="Juragan Kucek"
    class="w-13 h-12 rounded-xl object-contain border border-slate-200 shadow-sm bg-white"
  />
  <div class="leading-tight">
    <div class="font-extrabold text-[15px] text-slate-900 tracking-wide uppercase">Juragan Kucek</div>
    <div class="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Admin Panel</div>
  </div>
</div>


  <nav class="flex-1 overflow-y-auto py-6 space-y-1 px-3 no-scrollbar">
    <p class="px-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Utama</p>

    <?php if (isset($component)) { $__componentOriginal21428fa4d1f62e7840da3b117344a232 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21428fa4d1f62e7840da3b117344a232 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.nav-item','data' => ['href' => route('admin.dashboard'),'active' => request()->routeIs('admin.dashboard'),'icon' => 'fa-solid fa-chart-pie']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.dashboard')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.dashboard')),'icon' => 'fa-solid fa-chart-pie']); ?>
      Beranda
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21428fa4d1f62e7840da3b117344a232)): ?>
<?php $attributes = $__attributesOriginal21428fa4d1f62e7840da3b117344a232; ?>
<?php unset($__attributesOriginal21428fa4d1f62e7840da3b117344a232); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21428fa4d1f62e7840da3b117344a232)): ?>
<?php $component = $__componentOriginal21428fa4d1f62e7840da3b117344a232; ?>
<?php unset($__componentOriginal21428fa4d1f62e7840da3b117344a232); ?>
<?php endif; ?>

    <p class="px-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 mt-6">Manajemen</p>

    <?php if (isset($component)) { $__componentOriginal21428fa4d1f62e7840da3b117344a232 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21428fa4d1f62e7840da3b117344a232 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.nav-item','data' => ['href' => route('admin.users.index'),'active' => request()->routeIs('admin.users.*'),'icon' => 'fa-solid fa-users']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.users.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.users.*')),'icon' => 'fa-solid fa-users']); ?>
      Data Pengguna
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21428fa4d1f62e7840da3b117344a232)): ?>
<?php $attributes = $__attributesOriginal21428fa4d1f62e7840da3b117344a232; ?>
<?php unset($__attributesOriginal21428fa4d1f62e7840da3b117344a232); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21428fa4d1f62e7840da3b117344a232)): ?>
<?php $component = $__componentOriginal21428fa4d1f62e7840da3b117344a232; ?>
<?php unset($__componentOriginal21428fa4d1f62e7840da3b117344a232); ?>
<?php endif; ?>

    
    <?php if (isset($component)) { $__componentOriginal21428fa4d1f62e7840da3b117344a232 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21428fa4d1f62e7840da3b117344a232 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.nav-item','data' => ['href' => route('admin.orders.index'),'active' => request()->routeIs('admin.orders.*'),'icon' => 'fa-solid fa-file-invoice','badge' => $ordersNeedConfirmCount,'badgeTone' => 'amber']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.orders.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.orders.*')),'icon' => 'fa-solid fa-file-invoice','badge' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ordersNeedConfirmCount),'badgeTone' => 'amber']); ?>
      Data Pesanan
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21428fa4d1f62e7840da3b117344a232)): ?>
<?php $attributes = $__attributesOriginal21428fa4d1f62e7840da3b117344a232; ?>
<?php unset($__attributesOriginal21428fa4d1f62e7840da3b117344a232); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21428fa4d1f62e7840da3b117344a232)): ?>
<?php $component = $__componentOriginal21428fa4d1f62e7840da3b117344a232; ?>
<?php unset($__componentOriginal21428fa4d1f62e7840da3b117344a232); ?>
<?php endif; ?>

    
    <?php if (isset($component)) { $__componentOriginal21428fa4d1f62e7840da3b117344a232 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21428fa4d1f62e7840da3b117344a232 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.nav-item','data' => ['href' => route('admin.verify.index'),'active' => request()->routeIs('admin.verify.*'),'icon' => 'fa-solid fa-file-invoice-dollar','badge' => $pendingPaymentsCount,'badgeTone' => 'violet']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.verify.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.verify.*')),'icon' => 'fa-solid fa-file-invoice-dollar','badge' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pendingPaymentsCount),'badgeTone' => 'violet']); ?>
      Verifikasi Bayar
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21428fa4d1f62e7840da3b117344a232)): ?>
<?php $attributes = $__attributesOriginal21428fa4d1f62e7840da3b117344a232; ?>
<?php unset($__attributesOriginal21428fa4d1f62e7840da3b117344a232); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21428fa4d1f62e7840da3b117344a232)): ?>
<?php $component = $__componentOriginal21428fa4d1f62e7840da3b117344a232; ?>
<?php unset($__componentOriginal21428fa4d1f62e7840da3b117344a232); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal21428fa4d1f62e7840da3b117344a232 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21428fa4d1f62e7840da3b117344a232 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.nav-item','data' => ['href' => route('admin.services.index'),'active' => request()->routeIs('admin.services.*'),'icon' => 'fa-solid fa-tags']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.services.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.services.*')),'icon' => 'fa-solid fa-tags']); ?>
      Jenis Layanan
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21428fa4d1f62e7840da3b117344a232)): ?>
<?php $attributes = $__attributesOriginal21428fa4d1f62e7840da3b117344a232; ?>
<?php unset($__attributesOriginal21428fa4d1f62e7840da3b117344a232); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21428fa4d1f62e7840da3b117344a232)): ?>
<?php $component = $__componentOriginal21428fa4d1f62e7840da3b117344a232; ?>
<?php unset($__componentOriginal21428fa4d1f62e7840da3b117344a232); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal21428fa4d1f62e7840da3b117344a232 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21428fa4d1f62e7840da3b117344a232 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.nav-item','data' => ['href' => route('admin.report.index'),'active' => request()->routeIs('admin.report.*'),'icon' => 'fa-solid fa-chart-line']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.report.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.report.*')),'icon' => 'fa-solid fa-chart-line']); ?>
      Laporan
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21428fa4d1f62e7840da3b117344a232)): ?>
<?php $attributes = $__attributesOriginal21428fa4d1f62e7840da3b117344a232; ?>
<?php unset($__attributesOriginal21428fa4d1f62e7840da3b117344a232); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21428fa4d1f62e7840da3b117344a232)): ?>
<?php $component = $__componentOriginal21428fa4d1f62e7840da3b117344a232; ?>
<?php unset($__componentOriginal21428fa4d1f62e7840da3b117344a232); ?>
<?php endif; ?>
  </nav>

  <div class="p-4 border-t border-slate-100 bg-slate-50">
    <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
      <?php echo csrf_field(); ?>
      <button type="submit"
        class="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-red-50 text-red-600 hover:bg-red-100 border border-red-200 transition text-xs uppercase tracking-wide shadow-sm">
        <i class="fa-solid fa-right-from-bracket"></i> Logout
      </button>
    </form>
  </div>
</aside>
<?php /**PATH C:\xampp\htdocs\Juragan_Kucek_Project\backend\resources\views/components/admin/sidebar.blade.php ENDPATH**/ ?>