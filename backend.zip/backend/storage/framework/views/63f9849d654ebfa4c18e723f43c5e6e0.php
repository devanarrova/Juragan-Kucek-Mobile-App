<?php
  /**
   * Print-only QR block.
   *
   * Expected variables:
   * - $value   : string to be encoded
   * - $size    : int size in px (default 110)
   * - $caption : optional caption under QR
   */
  $value = $value ?? '';
  $size = (int)($size ?? 110);
  $caption = $caption ?? null;
  $hasQr = class_exists('SimpleSoftwareIO\\QrCode\\Facades\\QrCode');
?>

<div class="qrBox" style="text-align:center;">
  <?php if($hasQr): ?>
    <?php echo \SimpleSoftwareIO\QrCode\Facades\QrCode::format('svg')->size($size)->margin(1)->generate($value); ?>

  <?php else: ?>
    <div style="width:<?php echo e($size); ?>px; height:<?php echo e($size); ?>px; border:1px dashed #cbd5e1; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:10px; color:#64748b; text-align:center; padding:8px;">
      QR belum aktif<br>
      <span style="font-weight:800;">Install simple-qrcode</span>
    </div>
  <?php endif; ?>

  <?php if(!empty($caption)): ?>
    <div class="muted" style="margin-top:6px; font-weight:800; letter-spacing:.12em; text-transform:uppercase;">
      <?php echo e($caption); ?>

    </div>
  <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\Juragan_Kucek_Project\backend\resources\views/admin/components/print/qr.blade.php ENDPATH**/ ?>