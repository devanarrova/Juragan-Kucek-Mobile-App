<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo $__env->yieldContent('title', 'Admin'); ?> - Juragan Kucek -</title>

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

    html, body { height: 100%; }
    body { font-family: 'Inter', sans-serif; background-color: #f1f5f9; }

    .fade-in { animation: fadeIn 0.4s ease-out forwards; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

    .nav-item { transition: all 0.2s; border-left: 4px solid transparent; }
    .nav-item.active { background-color: #e0e7ff; color: #4338ca; border-left-color: #4338ca; }
    .nav-item:not(.active) { color: #64748b; }
    .nav-item:not(.active):hover { background-color: #f8fafc; color: #1e293b; }

    /* Saat modal open: lock scroll yang bener */
    body.modal-open { overflow: hidden !important; }
  </style>

  <?php echo $__env->yieldPushContent('head'); ?>
</head>

<body class="min-h-screen w-full text-slate-800">
  <div class="flex min-h-screen w-full">
    
    <?php if (isset($component)) { $__componentOriginalbebe114f3ccde4b38d7462a3136be045 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbebe114f3ccde4b38d7462a3136be045 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbebe114f3ccde4b38d7462a3136be045)): ?>
<?php $attributes = $__attributesOriginalbebe114f3ccde4b38d7462a3136be045; ?>
<?php unset($__attributesOriginalbebe114f3ccde4b38d7462a3136be045); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbebe114f3ccde4b38d7462a3136be045)): ?>
<?php $component = $__componentOriginalbebe114f3ccde4b38d7462a3136be045; ?>
<?php unset($__componentOriginalbebe114f3ccde4b38d7462a3136be045); ?>
<?php endif; ?>

    
    <div class="flex-1 min-w-0 bg-slate-50 flex flex-col">
      <?php if (isset($component)) { $__componentOriginal232f012cda936a4eb249de3234ccfddd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal232f012cda936a4eb249de3234ccfddd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.topbar','data' => ['title' => trim($__env->yieldContent('page_title', 'Admin'))]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(trim($__env->yieldContent('page_title', 'Admin')))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal232f012cda936a4eb249de3234ccfddd)): ?>
<?php $attributes = $__attributesOriginal232f012cda936a4eb249de3234ccfddd; ?>
<?php unset($__attributesOriginal232f012cda936a4eb249de3234ccfddd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal232f012cda936a4eb249de3234ccfddd)): ?>
<?php $component = $__componentOriginal232f012cda936a4eb249de3234ccfddd; ?>
<?php unset($__componentOriginal232f012cda936a4eb249de3234ccfddd); ?>
<?php endif; ?>

      
      <main class="flex-1 overflow-y-auto">
        <div class="p-8 fade-in">
          <?php echo $__env->yieldContent('content'); ?>
        </div>
      </main>
    </div>
  </div>

  
  <?php echo $__env->yieldPushContent('modals'); ?>
  <?php if(session('toast')): ?>
  <?php
    $t = session('toast');
    $type = $t['type'] ?? 'success';
    $msg  = $t['message'] ?? '';
    $tone = $type === 'success'
      ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
      : 'border-slate-200 bg-white text-slate-800';
  ?>

  <div id="jkToast"
       class="fixed top-5 right-5 z-[999999] w-[92vw] max-w-sm rounded-2xl border <?php echo e($tone); ?> shadow-xl overflow-hidden">
    <div class="p-4 flex items-start gap-3">
      <div class="w-10 h-10 rounded-2xl bg-white/70 border border-white/60 flex items-center justify-center shrink-0">
        <i class="fa-solid fa-circle-check text-emerald-600"></i>
      </div>
      <div class="min-w-0">
        <div class="font-extrabold leading-tight">Sukses</div>
        <div class="text-sm mt-0.5 break-words"><?php echo e($msg); ?></div>
      </div>
      <button type="button" id="jkToastClose"
              class="ml-auto w-9 h-9 rounded-xl hover:bg-black/5 inline-flex items-center justify-center text-slate-500">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>
    <div class="h-1 bg-emerald-500/80" id="jkToastBar"></div>
  </div>

  <script>
    (function () {
      const toast = document.getElementById('jkToast');
      const close = document.getElementById('jkToastClose');
      const bar   = document.getElementById('jkToastBar');
      if (!toast) return;

      // anim masuk
      toast.style.transform = 'translateY(-8px)';
      toast.style.opacity = '0';
      toast.style.transition = 'all .18s ease';
      requestAnimationFrame(() => {
        toast.style.transform = 'translateY(0)';
        toast.style.opacity = '1';
      });

      // progress bar 3 detik
      if (bar) {
        bar.style.width = '100%';
        bar.style.transition = 'width 3s linear';
        requestAnimationFrame(() => bar.style.width = '0%');
      }

      function hide() {
        toast.style.transform = 'translateY(-8px)';
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 180);
      }

      if (close) close.addEventListener('click', hide);
      setTimeout(hide, 3000);
    })();
  </script>
<?php endif; ?>

  <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Juragan_Kucek_Project\backend\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>