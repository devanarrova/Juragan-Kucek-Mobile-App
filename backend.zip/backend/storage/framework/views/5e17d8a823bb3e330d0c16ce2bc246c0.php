<?php $__env->startSection('title','Verifikasi Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
<?php
  $hasStatus = request()->filled('status');
  $hasSearch = request()->filled('search');

  $payBadge = function ($status) {
    return match($status) {
      'PENDING'  => 'bg-amber-50 text-amber-700 border-amber-200',
      'APPROVED' => 'bg-emerald-50 text-emerald-700 border-emerald-200',
      'REJECTED' => 'bg-red-50 text-red-700 border-red-200',
      default    => 'bg-slate-50 text-slate-600 border-slate-200'
    };
  };

  $payIcon = function ($status) {
    return match($status) {
      'PENDING'  => 'fa-regular fa-clock',
      'APPROVED' => 'fa-solid fa-circle-check',
      'REJECTED' => 'fa-solid fa-circle-xmark',
      default    => 'fa-regular fa-circle-question'
    };
  };
?>

<?php if(session('ok')): ?>
  <div class="mb-4 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-emerald-800 shadow-sm">
    <i class="fa-solid fa-circle-check"></i>
    <span class="ml-2"><?php echo e(session('ok')); ?></span>
  </div>
<?php endif; ?>

<?php if($errors->any()): ?>
  <div class="mb-4 rounded-2xl border border-red-200 bg-red-50 p-4 text-red-800 shadow-sm">
    <div class="font-semibold mb-2">
      <i class="fa-solid fa-triangle-exclamation"></i>
      <span class="ml-2">Terjadi kesalahan</span>
    </div>
    <ul class="list-disc pl-5 text-sm space-y-1">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($e); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<div class="space-y-4">

  
 <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-3">
  <div>
    <h2 class="text-2xl font-bold text-slate-900">
      <?php echo e($archived ? 'Riwayat Verifikasi' : 'Verifikasi Pembayaran'); ?>

    </h2>
    <p class="text-sm text-slate-500 mt-1">
      <?php echo e($archived
          ? 'Ini daftar pembayaran yang sudah disetujui (arsip).'
          : 'Klik Cek untuk melihat bukti transfer dan rincian pesanan.'); ?>

    </p>
  </div>

  <div class="flex items-center gap-2">
    <?php if(!$archived): ?>
      <a href="<?php echo e(route('admin.verify.index', array_merge(request()->query(), ['archived' => 1, 'status' => null]))); ?>"
         class="px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.99] transition inline-flex items-center gap-2 text-sm font-semibold text-slate-700">
        <i class="fa-solid fa-box-archive text-slate-500"></i>
        Lihat Arsip
      </a>
    <?php else: ?>
      <a href="<?php echo e(route('admin.verify.index', array_merge(request()->query(), ['archived' => 0, 'status' => null]))); ?>"
         class="px-4 py-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.99] transition inline-flex items-center gap-2 text-sm font-bold">
        <i class="fa-solid fa-arrow-left"></i>
        Kembali ke Aktif
      </a>
    <?php endif; ?>
  </div>
</div>


  
  <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
    <form class="grid grid-cols-1 md:grid-cols-12 gap-3">
      <input type="hidden" name="archived" value="<?php echo e($archived ? 1 : 0); ?>">

      <div class="md:col-span-6 relative">
        <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
        <input name="search" value="<?php echo e(request('search')); ?>"
               placeholder="Cari kode order / username / nama..."
               class="w-full rounded-xl border border-slate-200 pl-10 pr-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200" />
      </div>

      <div class="md:col-span-3 relative">
        <i class="fa-solid fa-filter absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
        <select name="status"
                class="w-full rounded-xl border border-slate-200 pl-10 pr-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
          <option value="">Semua Status</option>
          <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($st); ?>" <?php if(request('status')===$st): echo 'selected'; endif; ?>><?php echo e($st); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      <div class="md:col-span-3 flex gap-2">
        <button class="flex-1 px-4 py-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.99] transition inline-flex items-center justify-center gap-2">
          <i class="fa-solid fa-filter"></i> Terapkan
        </button>
        <a href="<?php echo e(route('admin.verify.index')); ?>"
           class="px-4 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 active:scale-[0.99] transition inline-flex items-center justify-center"
           title="Reset">
          <i class="fa-solid fa-rotate-left text-slate-500"></i>
        </a>
      </div>
    </form>

    
    <?php if($hasStatus || $hasSearch): ?>
      <div class="mt-3 flex flex-wrap items-center gap-2">
        <span class="text-xs text-slate-500">Filter aktif:</span>

        <?php if($hasStatus): ?>
          <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-slate-50 text-slate-700">
            <i class="fa-solid fa-tag text-slate-500"></i>
            Status: <?php echo e(request('status')); ?>

          </span>
        <?php endif; ?>

        <?php if($hasSearch): ?>
          <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-slate-50 text-slate-700">
            <i class="fa-solid fa-magnifying-glass text-slate-500"></i>
            Search: "<?php echo e(request('search')); ?>"
          </span>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </div>

  
  <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="bg-slate-50 text-slate-600">
          <tr>
            <th class="text-left px-4 py-3">Order</th>
            <th class="text-left px-4 py-3">Username</th>
            <th class="text-left px-4 py-3">Nama Customer</th>
            <th class="text-left px-4 py-3">Layanan</th>
            <th class="text-left px-4 py-3">Upload</th>
            <th class="text-left px-4 py-3">Metode</th>
            <th class="text-left px-4 py-3">Nominal</th>
            <th class="text-left px-4 py-3">Status</th>
            <th class="text-center px-4 py-3">Aksi</th>
          </tr>
        </thead>

        <tbody class="divide-y divide-slate-100">
          <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
              $o = $p->order;
              $customer = $o?->customer;

              $status = $p->status ?? '—';
              $badgeClass = $payBadge($p->status);
              $icon = $payIcon($p->status);

              $payload = [
                'order_id' => $o?->id,
                'order_code' => $o?->order_code,
                'pickup_date' => $o?->pickup_date ? tgl_id($o->pickup_date) : '-',
                'estimated_qty' => $o?->estimated_qty ?? '-',
                'final_qty' => $o?->final_qty ?? '-',
                'total_price' => $o?->total_price ? rupiah($o->total_price) : '-',
                'service' => $o?->service?->name ?? '-',

                'username' => $customer?->username ?? '-',
                'name' => $customer?->name ?? '-',

                'method' => $p->method ?? '-',
                'channel_code' => $p->channel_code ?? null,
                'channel_name' => $p->channel_name ?? null,
                'destination_account' => $p->destination_account ?? null,
                'destination_holder' => $p->destination_holder ?? null,

                'amount' => rupiah($p->amount),
                'status' => $p->status ?? '—',
                'customer_note' => $p->customer_note ? \App\Support\TextFilter::sanitize($p->customer_note) : '-',
                'admin_note' => $p->admin_note ? \App\Support\TextFilter::sanitize($p->admin_note) : '-',
                'uploaded_at' => $p->created_at ? tgl_id($p->created_at, 'd M Y H:i') : '-',

                'proof_url' => $p->proof_path ? asset('storage/'.$p->proof_path) : null,

                'approve_url' => $o ? route('admin.orders.payment.approve', $o) : null,
                'reject_url'  => $o ? route('admin.orders.payment.reject', $o) : null,
              ];
            ?>

            <tr class="hover:bg-slate-50 transition">
              <td class="px-4 py-3">
                <div class="font-semibold text-slate-900"><?php echo e($o->order_code ?? '-'); ?></div>
                <div class="text-xs text-slate-500">Order ID: <?php echo e($o->id ?? '-'); ?></div>
              </td>

              <td class="px-4 py-3 text-slate-700">
                <?php echo e($customer->username ?? '-'); ?>

              </td>

              <td class="px-4 py-3">
                <div class="font-semibold text-slate-900"><?php echo e($customer->name ?? '-'); ?></div>
              </td>

              <td class="px-4 py-3">
                <span class="inline-flex items-center px-2 py-1 rounded-lg text-[11px] font-bold border border-indigo-100 bg-indigo-50 text-indigo-700">
                  <?php echo e($o->service->name ?? '-'); ?>

                </span>
              </td>

              <td class="px-4 py-3 text-slate-600">
                <div class="text-xs"><?php echo e($p->created_at ? tgl_id($p->created_at, 'd M Y H:i') : '-'); ?></div>
              </td>

              <td class="px-4 py-3">
                <span class="inline-flex items-center px-2 py-1 rounded-lg text-[11px] font-bold border border-blue-200 bg-blue-50 text-blue-700 uppercase">
                  <?php echo e($p->method ?? '-'); ?>

                </span>
                <?php if($p->channel_code): ?>
                  <div class="mt-1 text-xs text-slate-500"><?php echo e($p->channel_code); ?> • <?php echo e($p->destination_account); ?></div>
                <?php endif; ?>
              </td>

              <td class="px-4 py-3 font-bold text-slate-900">
                <?php echo e(rupiah($p->amount)); ?>

              </td>

              <td class="px-4 py-3">
                <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border <?php echo e($badgeClass); ?>">
                  <i class="<?php echo e($icon); ?>"></i>
                  <?php echo e($status); ?>

                </span>
              </td>

              <td class="px-4 py-3 text-center">
                <button type="button"
                        class="btn-check-verify inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.99] transition text-xs font-bold shadow-sm"
                        data-payload='<?php echo json_encode($payload, 15, 512) ?>'>
                  <i class="fa-solid fa-eye"></i> Cek
                </button>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="9" class="px-4 py-10">
                <div class="bg-white rounded-2xl border border-slate-200 p-10 text-center text-slate-500 shadow-sm">
                  <i class="fa-regular fa-circle-check text-3xl text-emerald-600"></i>
                  <div class="mt-2 font-semibold text-slate-700">Semua aman!</div>
                  <div class="text-sm mt-1">Tidak ada pembayaran tertunda saat ini.</div>
                </div>
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="pt-2">
    <?php echo e($payments->links()); ?>

  </div>

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('modals'); ?>
<div id="verifyModal" class="hidden" aria-hidden="true">
  <div id="verifyOverlay"
       class="fixed top-0 left-0 w-screen h-screen z-[99999] bg-slate-900/70 backdrop-blur-md flex items-center justify-center p-4">
    <div class="w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">

      
      <div class="px-6 py-4 border-b border-slate-200 bg-white flex items-center justify-between">
        <div>
          <div class="text-xs text-slate-500">Verifikasi Pembayaran</div>
          <div class="text-lg font-bold text-slate-900 flex items-center gap-2">
            <i class="fa-solid fa-eye text-slate-600"></i>
            <span id="m_order_code">-</span>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <span id="m_status_badge"
                class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold border border-slate-200 bg-slate-50 text-slate-700">
            <i id="m_status_icon" class="fa-regular fa-circle-question"></i>
            <span id="m_pay_status">-</span>
          </span>

          <button type="button"
                  onclick="closeVerifyModal()"
                  class="w-10 h-10 rounded-xl border border-slate-200 hover:bg-slate-50 active:scale-[0.99] transition inline-flex items-center justify-center text-slate-500">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </div>
      </div>

      
      <div class="p-6 overflow-y-auto space-y-4 bg-slate-50">

        
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-4">
          <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div class="rounded-2xl border border-slate-200 bg-slate-50 p-3">
              <div class="text-xs text-slate-500">Customer</div>
              <div class="font-semibold text-slate-900 mt-1" id="m_customer">-</div>
              <div class="text-xs text-slate-500 mt-1" id="m_username">-</div>
            </div>

            <div class="rounded-2xl border border-slate-200 bg-slate-50 p-3">
              <div class="text-xs text-slate-500">Metode</div>
              <div class="font-semibold text-slate-900 mt-1 uppercase" id="m_method">-</div>
              <div class="text-xs text-slate-500 mt-1" id="m_channel">-</div>
              <div class="text-xs text-slate-500 mt-1">Waktu upload: <span id="m_uploaded_at">-</span></div>
            </div>

            <div class="rounded-2xl border border-indigo-200 bg-indigo-50 p-3">
              <div class="text-xs text-indigo-700">Nominal Transfer</div>
              <div class="text-2xl font-extrabold text-indigo-700 mt-1" id="m_amount">-</div>
              <div class="text-xs text-indigo-700/80 mt-1">Pastikan sesuai total</div>
            </div>
          </div>
        </div>

        
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-4">
          <div class="flex items-center gap-2 mb-3">
            <i class="fa-solid fa-receipt text-slate-600"></i>
            <h6 class="font-bold text-slate-900">Rincian Pesanan</h6>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
            <div class="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 p-3">
              <span class="text-slate-500">Layanan</span>
              <span class="font-semibold text-slate-900" id="m_service">-</span>
            </div>

            <div class="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 p-3">
              <span class="text-slate-500">Pickup</span>
              <span class="font-semibold text-slate-900" id="m_pickup">-</span>
            </div>

            <div class="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 p-3">
              <span class="text-slate-500">Estimasi Qty</span>
              <span class="font-semibold text-slate-900" id="m_est_qty">-</span>
            </div>

            <div class="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 p-3">
              <span class="text-slate-500">Final Qty</span>
              <span class="font-semibold text-slate-900" id="m_final_qty">-</span>
            </div>

            <div class="md:col-span-2 flex items-center justify-between rounded-xl border border-slate-200 bg-white p-3">
              <span class="text-slate-600 font-semibold">Total Harga</span>
              <span class="text-lg font-extrabold text-slate-900" id="m_total_price">-</span>
            </div>
          </div>
        </div>

        
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-4">
          <div class="flex items-center justify-between gap-2 mb-3">
            <div class="flex items-center gap-2">
              <i class="fa-regular fa-image text-slate-600"></i>
              <h6 class="font-bold text-slate-900">Bukti Pembayaran</h6>
            </div>

            <a id="m_proof_link"
               href="#"
               target="_blank"
               class="hidden inline-flex items-center gap-2 px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.99] transition text-sm font-semibold text-slate-700">
              <i class="fa-solid fa-up-right-from-square text-slate-500"></i>
              Buka
            </a>
          </div>

          <div class="rounded-2xl border border-slate-200 bg-slate-100 overflow-hidden min-h-[260px] max-h-[420px] flex items-center justify-center relative">
            <img id="m_proof_img" src="" class="w-full h-full object-contain hidden" alt="Bukti pembayaran">
            <div id="m_no_img" class="absolute inset-0 flex flex-col items-center justify-center text-slate-400 text-sm gap-2 p-6 text-center">
              <i class="fa-regular fa-image text-3xl"></i>
              <div id="m_no_img_text">Bukti pembayaran tidak tersedia / tidak bisa ditampilkan</div>
            </div>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3 text-sm">
            <div class="rounded-2xl border border-slate-200 bg-slate-50 p-3">
              <div class="text-xs text-slate-500 mb-1">Catatan Customer (saat upload)</div>
              <div class="text-slate-800" id="m_customer_note">-</div>
            </div>

            <div class="rounded-2xl border border-slate-200 bg-slate-50 p-3">
              <div class="text-xs text-slate-500 mb-1">Catatan Admin (hasil verifikasi/alasan)</div>
              <div class="text-slate-800" id="m_admin_note_prev">-</div>
            </div>
          </div>
        </div>

        
        <div id="nonPendingInfo" class="hidden bg-white rounded-2xl border border-slate-200 shadow-sm p-4 text-sm">
          <div class="font-semibold text-slate-900">Pembayaran sudah diproses.</div>
          <div class="text-slate-500 mt-1">Aksi Setuju/Tolak dimatikan agar admin tidak salah klik.</div>
        </div>
      </div>

      
      <div class="px-6 py-4 border-t border-slate-200 bg-white">
        <div id="pendingActions" class="grid grid-cols-1 md:grid-cols-3 gap-3">
          <button type="button"
                  onclick="closeVerifyModal()"
                  class="px-4 py-3 rounded-xl border border-slate-200 hover:bg-slate-50 active:scale-[0.99] transition font-bold text-sm inline-flex items-center justify-center gap-2">
            <i class="fa-solid fa-arrow-left text-slate-500"></i> Kembali
          </button>

          <form id="approveForm" method="POST" action="#">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="admin_note" id="approveNote" value="">
            <button type="submit"
                    class="w-full px-4 py-3 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.99] transition font-bold text-sm inline-flex items-center justify-center gap-2">
              <i class="fa-solid fa-check"></i> Setuju
            </button>
          </form>

          <form id="rejectForm" method="POST" action="#" onsubmit="return validateRejectNote();">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="admin_note" id="rejectNote">
            <button type="submit"
                    class="w-full px-4 py-3 rounded-xl border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 active:scale-[0.99] transition font-bold text-sm inline-flex items-center justify-center gap-2">
              <i class="fa-solid fa-xmark"></i> Tolak
            </button>
          </form>
        </div>

        <button type="button" id="onlyBackBtn"
                onclick="closeVerifyModal()"
                class="hidden w-full px-4 py-3 rounded-xl border border-slate-200 hover:bg-slate-50 active:scale-[0.99] transition font-bold text-sm inline-flex items-center justify-center gap-2">
          <i class="fa-solid fa-arrow-left text-slate-500"></i> Kembali
        </button>

        <div class="text-xs text-slate-500 mt-3">
          * Saat menolak, alasan wajib diisi (akan disimpan sebagai catatan admin).
        </div>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
  const modalRoot = document.getElementById('verifyModal');
  const overlayEl = document.getElementById('verifyOverlay');

  function setBodyScroll(lock) {
    document.body.classList.toggle('modal-open', lock);
  }

  function badgeFor(status) {
    switch (status) {
      case 'PENDING':
        return {cls: 'bg-amber-50 text-amber-700 border-amber-200', icon: 'fa-regular fa-clock'};
      case 'APPROVED':
        return {cls: 'bg-emerald-50 text-emerald-700 border-emerald-200', icon: 'fa-solid fa-circle-check'};
      case 'REJECTED':
        return {cls: 'bg-red-50 text-red-700 border-red-200', icon: 'fa-solid fa-circle-xmark'};
      default:
        return {cls: 'bg-slate-50 text-slate-700 border-slate-200', icon: 'fa-regular fa-circle-question'};
    }
  }

  function openVerifyModal(payload) {
    modalRoot.classList.remove('hidden');
    modalRoot.setAttribute('aria-hidden', 'false');
    setBodyScroll(true);

    // header
    document.getElementById('m_order_code').textContent = payload.order_code ?? '-';
    document.getElementById('m_pay_status').textContent = payload.status ?? '-';

    const badge = badgeFor(payload.status);
    const badgeEl = document.getElementById('m_status_badge');
    const iconEl  = document.getElementById('m_status_icon');
    badgeEl.className = `inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold border ${badge.cls}`;
    iconEl.className = badge.icon;

    // ringkasan
    document.getElementById('m_customer').textContent = payload.name ?? '-';
    document.getElementById('m_username').textContent = payload.username ? `@${payload.username}` : '-';
    document.getElementById('m_method').textContent = payload.method ?? '-';
    const ch = payload.channel_code ? `${payload.channel_name || payload.channel_code} • ${payload.destination_account || ''} a.n ${payload.destination_holder || ''}` : '-';
    document.getElementById('m_channel').textContent = ch;
    document.getElementById('m_uploaded_at').textContent = payload.uploaded_at ?? '-';
    document.getElementById('m_amount').textContent = payload.amount ?? '-';

    // rincian pesanan
    document.getElementById('m_service').textContent = payload.service ?? '-';
    document.getElementById('m_pickup').textContent = payload.pickup_date ?? '-';
    document.getElementById('m_est_qty').textContent = payload.estimated_qty ?? '-';
    document.getElementById('m_final_qty').textContent = payload.final_qty ?? '-';
    document.getElementById('m_total_price').textContent = payload.total_price ?? '-';

    // catatan
    document.getElementById('m_customer_note').textContent = payload.customer_note ?? '-';
    document.getElementById('m_admin_note_prev').textContent = payload.admin_note ?? '-';

    // toggle actions
    const isPending = payload.status === 'PENDING';
    document.getElementById('pendingActions').classList.toggle('hidden', !isPending);
    document.getElementById('onlyBackBtn').classList.toggle('hidden', isPending);
    document.getElementById('nonPendingInfo').classList.toggle('hidden', isPending);

    // form action
    document.getElementById('approveForm').action = payload.approve_url || '#';
    document.getElementById('rejectForm').action  = payload.reject_url  || '#';

    // bukti (robust)
    const img = document.getElementById('m_proof_img');
    const noImg = document.getElementById('m_no_img');
    const noImgText = document.getElementById('m_no_img_text');
    const link = document.getElementById('m_proof_link');

    img.onload = null;
    img.onerror = null;

    if (payload.proof_url) {
      link.href = payload.proof_url;
      link.classList.remove('hidden');

      img.src = payload.proof_url;
      img.classList.remove('hidden');
      noImg.classList.add('hidden');

      img.onerror = () => {
        img.src = '';
        img.classList.add('hidden');
        noImg.classList.remove('hidden');
        noImgText.textContent = 'Bukti tidak bisa ditampilkan (format bukan gambar / link invalid). Klik tombol "Buka".';
      };

      img.onload = () => {
        noImg.classList.add('hidden');
        img.classList.remove('hidden');
      };
    } else {
      img.src = '';
      img.classList.add('hidden');
      noImg.classList.remove('hidden');
      noImgText.textContent = 'Bukti pembayaran tidak tersedia.';
      link.href = '#';
      link.classList.add('hidden');
    }
  }

  function closeVerifyModal() {
    modalRoot.classList.add('hidden');
    modalRoot.setAttribute('aria-hidden', 'true');
    setBodyScroll(false);
  }

  function validateRejectNote() {
    const reason = prompt('Masukkan alasan penolakan (Wajib):', 'Nominal tidak sesuai / Foto buram');
    if (!reason || !reason.trim()) {
      alert('Alasan wajib diisi!');
      return false;
    }
    document.getElementById('rejectNote').value = reason.trim();
    return confirm('Yakin ingin menolak pembayaran ini?');
  }

  // expose untuk onclick
  window.closeVerifyModal = closeVerifyModal;
  window.validateRejectNote = validateRejectNote;

  // binding tombol Cek
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.btn-check-verify').forEach(btn => {
      btn.addEventListener('click', () => {
        try {
          const payload = JSON.parse(btn.dataset.payload || '{}');
          openVerifyModal(payload);
        } catch (e) {
          console.error('Payload modal invalid', e);
          alert('Data modal rusak. Cek console.');
        }
      });
    });
  });

  // ESC to close
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !modalRoot.classList.contains('hidden')) closeVerifyModal();
  });

  // click overlay to close (klik area gelap saja)
  overlayEl.addEventListener('click', (e) => {
    if (e.target === overlayEl) closeVerifyModal();
  });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Juragan_Kucek_Project\backend\resources\views/admin/pages/verify/index.blade.php ENDPATH**/ ?>