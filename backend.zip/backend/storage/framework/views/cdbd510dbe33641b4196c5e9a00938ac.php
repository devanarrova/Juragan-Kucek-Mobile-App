<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
  'title' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
  'title' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
  $admin = auth('admin')->user();

  $name = $admin?->name ?? $admin?->username ?? 'Administrator';
  $username = $admin?->username ?? '-';
  $role = ($admin && ($admin->is_superadmin ?? false)) ? 'Super Admin' : 'Admin';

  $pendingPaymentsCount   = (int)($pendingPaymentsCount ?? 0);
  $ordersNeedConfirmCount = (int)($ordersNeedConfirmCount ?? 0);

  $initials = collect(preg_split('/\s+/', trim($name)))
      ->filter()
      ->take(2)
      ->map(fn($p) => mb_strtoupper(mb_substr($p, 0, 1)))
      ->join('');

  $photoUrl = ($admin && $admin->profile_photo)
      ? asset('storage/'.$admin->profile_photo)
      : null;

  $pageTitle = $title ?? ($page_title ?? 'Admin');

  // ====== Active Menu Icon + Tone (bg/text/border) ======
  $menu = match (true) {
    request()->routeIs('admin.dashboard')   => ['fa-solid fa-chart-pie',          'bg-slate-900/5 border-slate-200 text-slate-900'],
    request()->routeIs('admin.users.*')     => ['fa-solid fa-users',              'bg-emerald-600/10 border-emerald-200 text-emerald-700'],
    request()->routeIs('admin.orders.*')    => ['fa-solid fa-file-invoice',       'bg-amber-500/10 border-amber-200 text-amber-700'],
    request()->routeIs('admin.verify.*')    => ['fa-solid fa-file-invoice-dollar','bg-violet-600/10 border-violet-200 text-violet-700'],
    request()->routeIs('admin.services.*')  => ['fa-solid fa-tags',               'bg-[#1F717C]/10 border-[#1F717C]/20 text-[#1F717C]'],
    request()->routeIs('admin.report.*')    => ['fa-solid fa-chart-line',         'bg-indigo-600/10 border-indigo-200 text-indigo-700'],
    request()->routeIs('admin.profile*')    => ['fa-solid fa-user-pen',           'bg-[#1F717C]/10 border-[#1F717C]/20 text-[#1F717C]'],
    default                                 => ['fa-solid fa-grid-2',             'bg-[#1F717C]/10 border-[#1F717C]/20 text-[#1F717C]'],
  };

  [$menuIcon, $menuTone] = $menu;

  $wib = now()->timezone(config('app.timezone', 'Asia/Jakarta'));
?>

<header class="h-20 bg-white border-b border-slate-200 flex items-center justify-between px-4 md:px-8 shadow-sm z-10 no-print">
  
  <div class="min-w-0">
    <div class="flex items-center gap-3 min-w-0">
      
      <div class="hidden sm:flex w-10 h-10 rounded-2xl border items-center justify-center shadow-sm <?php echo e($menuTone); ?>">
        <i class="<?php echo e($menuIcon); ?>"></i>
      </div>

      <div class="min-w-0">
        <h2 class="text-lg md:text-xl font-extrabold text-slate-900 truncate"><?php echo e($pageTitle); ?></h2>
        <div class="text-xs text-slate-500 mt-0.5 truncate">
          <?php echo e($wib->format('d M Y • H:i')); ?>

          <span class="text-slate-300 mx-1">•</span>
          <span class="font-extrabold text-slate-700"><?php echo e($role); ?></span>
        </div>
      </div>
    </div>
  </div>

  
  <div class="flex items-center gap-2 md:gap-3">

    
    <?php if($ordersNeedConfirmCount > 0): ?>
      <a href="<?php echo e(route('admin.orders.index', ['status' => 'MENUNGGU_KONFIRMASI'])); ?>"
         class="hidden md:inline-flex items-center gap-2 px-3 py-2 rounded-2xl border border-amber-200 bg-amber-50 text-amber-700 hover:bg-amber-100 active:scale-[0.99] transition text-xs font-extrabold">
        <i class="fa-regular fa-hourglass"></i>
        Konfirmasi
        <span class="min-w-[26px] h-6 px-2 rounded-full bg-amber-500 text-white inline-flex items-center justify-center text-xs font-extrabold">
          <?php echo e($ordersNeedConfirmCount); ?>

        </span>
      </a>
    <?php endif; ?>

    <?php if($pendingPaymentsCount > 0): ?>
      <a href="<?php echo e(route('admin.verify.index')); ?>"
         class="hidden md:inline-flex items-center gap-2 px-3 py-2 rounded-2xl border border-violet-200 bg-violet-50 text-violet-700 hover:bg-violet-100 active:scale-[0.99] transition text-xs font-extrabold">
        <i class="fa-solid fa-file-invoice-dollar"></i>
        Pending
        <span class="min-w-[26px] h-6 px-2 rounded-full bg-violet-600 text-white inline-flex items-center justify-center text-xs font-extrabold">
          <?php echo e($pendingPaymentsCount); ?>

        </span>
      </a>
    <?php endif; ?>

    
    <div class="relative" id="userMenuWrap">
      <button type="button" id="userMenuBtn"
              class="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.99] transition px-3 py-2 shadow-sm">
        <?php if($photoUrl): ?>
          <img src="<?php echo e($photoUrl); ?>" alt="Foto Profil"
               class="w-10 h-10 rounded-2xl object-cover border border-slate-200 bg-white">
        <?php else: ?>
          <div class="w-10 h-10 rounded-2xl bg-slate-900 text-white flex items-center justify-center font-extrabold">
            <?php echo e($initials ?: 'A'); ?>

          </div>
        <?php endif; ?>

        <div class="text-left hidden lg:block min-w-0">
          <div class="text-sm font-extrabold text-slate-900 truncate"><?php echo e($name); ?></div>
          <div class="text-[11px] text-slate-500 truncate"><?php echo e('@'.$username); ?></div>
        </div>

        <i class="fa-solid fa-chevron-down text-slate-400"></i>
      </button>

      <div id="userMenu"
           class="hidden absolute right-0 mt-2 w-72 bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
        <div class="p-4 bg-gradient-to-r from-slate-900 to-slate-700 text-white">
          <div class="text-xs text-white/70 font-extrabold uppercase tracking-wider">Akun</div>
          <div class="mt-1 font-extrabold truncate"><?php echo e($name); ?></div>
          <div class="text-xs text-white/70 truncate"><?php echo e('@'.$username); ?> • <?php echo e($role); ?></div>

          
          <div class="mt-3 flex flex-wrap gap-2">
            <?php if($ordersNeedConfirmCount > 0): ?>
              <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-white/10 border border-white/15">
                <i class="fa-regular fa-hourglass"></i> <?php echo e($ordersNeedConfirmCount); ?> konfirmasi
              </span>
            <?php endif; ?>
            <?php if($pendingPaymentsCount > 0): ?>
              <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-white/10 border border-white/15">
                <i class="fa-solid fa-file-invoice-dollar"></i> <?php echo e($pendingPaymentsCount); ?> pending
              </span>
            <?php endif; ?>
          </div>
        </div>

        <div class="p-2">
          <a href="<?php echo e(route('admin.profile')); ?>"
             class="flex items-center gap-3 px-3 py-2 rounded-2xl hover:bg-slate-50 transition text-sm font-extrabold text-slate-700">
            <span class="w-10 h-10 rounded-2xl bg-[#1F717C]/10 border border-[#1F717C]/15 text-[#1F717C] inline-flex items-center justify-center">
              <i class="fa-solid fa-user-pen"></i>
            </span>
            Profil Admin
            <i class="fa-solid fa-arrow-right ml-auto text-slate-300"></i>
          </a>

          <div class="my-2 h-px bg-slate-200"></div>

          <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit"
                    class="w-full flex items-center gap-3 px-3 py-2 rounded-2xl hover:bg-red-50 transition text-sm font-extrabold text-red-600">
              <span class="w-10 h-10 rounded-2xl bg-red-50 border border-red-100 text-red-700 inline-flex items-center justify-center">
                <i class="fa-solid fa-right-from-bracket"></i>
              </span>
              Logout
            </button>
          </form>
        </div>
      </div>
    </div>

  </div>
</header>

<?php $__env->startPush('scripts'); ?>
<script>
  (function () {
    const wrap = document.getElementById('userMenuWrap');
    const btn  = document.getElementById('userMenuBtn');
    const menu = document.getElementById('userMenu');
    if (!wrap || !btn || !menu) return;

    function openMenu(){ menu.classList.remove('hidden'); }
    function closeMenu(){ menu.classList.add('hidden'); }
    function toggleMenu(){ menu.classList.contains('hidden') ? openMenu() : closeMenu(); }

    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleMenu();
    });

    document.addEventListener('click', (e) => {
      if (!wrap.contains(e.target)) closeMenu();
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeMenu();
    });
  })();
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\Juragan_Kucek_Project\backend\resources\views/components/admin/topbar.blade.php ENDPATH**/ ?>