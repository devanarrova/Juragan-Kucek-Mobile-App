<?php $__env->startSection('title','Data Pengguna'); ?>
<?php $__env->startSection('page_title','Data Pengguna'); ?>

<?php $__env->startSection('content'); ?>
<?php
  $me = Auth::guard('admin')->user();
  $canManageAdmins = $canManageAdmins ?? ($me && (($me->is_superadmin ?? false) === true));

  // kalau bukan superadmin tapi akses ?type=admins, paksa balik ke customers
  $isForbiddenAdminTab = (($type ?? 'customers') === 'admins') && !$canManageAdmins;
  if ($isForbiddenAdminTab) {
    $type = 'customers';
  }

  $isCustomers = ($type ?? 'customers') === 'customers';
  $isAdmins    = ($type ?? 'customers') === 'admins';

  $hasSearch = request()->filled('search');
  $hasActive = request()->filled('active');

  $openCreateOnLoad = $errors->any()
    && !session('edit_id')
    && (old('name') || old('username'));

  $editKind = session('edit_kind'); // 'customer' | 'admin'
  $editId   = session('edit_id');   // id
?>

<div class="space-y-4">

  
  <div class="flex flex-col gap-3">
    <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-3">
      <div>
        <h2 class="text-2xl font-bold text-slate-900">Data Pengguna</h2>
        <p class="text-sm text-slate-500 mt-1">
          Kelola customer & admin (aktif/nonaktif, edit, reset password, delete khusus superadmin). Tambahan: detail pelanggan.
        </p>
      </div>

      <?php if($isCustomers || ($isAdmins && $canManageAdmins)): ?>
        <div class="flex items-center gap-2">
          <button type="button"
                  onclick="openCreateUser()"
                  class="px-4 py-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.99] transition inline-flex items-center gap-2 shadow-sm">
            <i class="fa-solid fa-plus"></i>
            Tambah <?php echo e($isCustomers ? 'Customer' : 'Admin'); ?>

          </button>
        </div>
      <?php endif; ?>
    </div>

    <?php if($isForbiddenAdminTab): ?>
      <div class="bg-amber-50 border border-amber-200 text-amber-800 rounded-2xl p-4 shadow-sm">
        <div class="font-bold flex items-center gap-2">
          <i class="fa-solid fa-shield-halved"></i>
          Akses dibatasi
        </div>
        <div class="text-sm mt-1">
          Hanya <b>Super Admin</b> yang boleh melihat & mengelola akun admin.
        </div>
      </div>
    <?php endif; ?>

    <div class="flex flex-wrap items-center gap-2">
      <a href="<?php echo e(route('admin.users.index', ['type'=>'customers'] + request()->except('page'))); ?>"
         class="px-4 py-2 rounded-xl border text-sm font-semibold transition
                <?php echo e($isCustomers ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'); ?>">
        <i class="fa-solid fa-users mr-2"></i>
        Customers
        <span class="ml-2 text-xs px-2 py-1 rounded-full <?php echo e($isCustomers ? 'bg-indigo-100' : 'bg-slate-100'); ?>">
          <?php echo e($customersCount ?? 0); ?>

        </span>
      </a>

      <?php if($canManageAdmins): ?>
        <a href="<?php echo e(route('admin.users.index', ['type'=>'admins'] + request()->except('page'))); ?>"
           class="px-4 py-2 rounded-xl border text-sm font-semibold transition
                  <?php echo e($isAdmins ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'); ?>">
          <i class="fa-solid fa-user-shield mr-2"></i>
          Admins
          <span class="ml-2 text-xs px-2 py-1 rounded-full <?php echo e($isAdmins ? 'bg-indigo-100' : 'bg-slate-100'); ?>">
            <?php echo e($adminsCount ?? 0); ?>

          </span>
        </a>
      <?php endif; ?>
    </div>
  </div>

  
  <?php if(session('ok')): ?>
    <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-2xl p-4 flex items-start gap-3 shadow-sm">
      <i class="fa-solid fa-circle-check mt-0.5"></i>
      <div class="font-semibold"><?php echo e(session('ok')); ?></div>
    </div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
    <div class="bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4 shadow-sm">
      <div class="font-bold flex items-center gap-2">
        <i class="fa-solid fa-triangle-exclamation"></i>
        Ada input yang salah
      </div>
      <ul class="list-disc pl-5 mt-2 text-sm space-y-1">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($e); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  
  <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
    <form class="grid grid-cols-1 md:grid-cols-12 gap-3">
      <input type="hidden" name="type" value="<?php echo e($type); ?>">

      <div class="md:col-span-7 relative">
        <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
        <input name="search"
               value="<?php echo e(request('search')); ?>"
               placeholder="Cari nama atau username..."
               class="w-full rounded-xl border border-slate-200 pl-10 pr-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200" />
      </div>

      <div class="md:col-span-3 relative">
        <i class="fa-solid fa-toggle-on absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
        <select name="active"
                class="w-full rounded-xl border border-slate-200 pl-10 pr-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
          <option value="">Semua</option>
          <option value="1" <?php if(request('active')==='1'): echo 'selected'; endif; ?>>Aktif</option>
          <option value="0" <?php if(request('active')==='0'): echo 'selected'; endif; ?>>Nonaktif</option>
        </select>
      </div>

      <div class="md:col-span-2 flex gap-2">
        <button class="flex-1 px-4 py-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 transition inline-flex items-center justify-center gap-2 shadow-sm">
          <i class="fa-solid fa-filter"></i> Terapkan
        </button>
        <a href="<?php echo e(route('admin.users.index', ['type'=>$type])); ?>"
           class="px-4 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 transition inline-flex items-center justify-center"
           title="Reset">
          <i class="fa-solid fa-rotate-left text-slate-500"></i>
        </a>
      </div>
    </form>

    <?php if($hasSearch || $hasActive): ?>
      <div class="mt-3 flex flex-wrap items-center gap-2">
        <span class="text-xs text-slate-500">Filter aktif:</span>

        <?php if($hasSearch): ?>
          <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-slate-50 text-slate-700">
            Search: "<?php echo e(request('search')); ?>"
          </span>
        <?php endif; ?>

        <?php if($hasActive): ?>
          <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-slate-50 text-slate-700">
            Status: <?php echo e(request('active')==='1' ? 'Aktif' : 'Nonaktif'); ?>

          </span>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </div>

  
  <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="bg-slate-50 text-slate-600">
          <tr>
            <th class="text-left px-4 py-3">Pengguna</th>
            <?php if($isCustomers): ?>
              <th class="text-left px-4 py-3 w-[110px]">Order</th>
            <?php endif; ?>
            <th class="text-left px-4 py-3 w-[140px]">Status</th>
            <th class="text-right px-4 py-3 w-[140px]">Aksi</th>
          </tr>
        </thead>

        <tbody class="divide-y divide-slate-100">
          <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
              $initials = collect(preg_split('/\s+/', trim($u->name ?? '')))
                ->filter()
                ->map(fn($w) => mb_substr($w,0,1))
                ->take(2)
                ->join('');

              // NOTE: sebelumnya foto cuma diset untuk customer.
              // Admin sebenarnya juga punya kolom profile_photo (di table admins),
              // jadi list admin harus ikut membaca field yang sama agar sinkron dengan topbar.
              $photoUrl = '';
              if (!empty($u->profile_photo)) {
                $photoUrl = \Illuminate\Support\Str::startsWith($u->profile_photo, ['http://','https://'])
                  ? $u->profile_photo
                  : asset('storage/'.$u->profile_photo);
              }

              $menuId = ($isCustomers ? 'c' : 'a') . '-' . $u->id;
              $isMe = ($me && $u->id == $me->id);
              $hasOrders = $isCustomers ? (($u->orders_count ?? 0) > 0) : false;

              $toggleMsg = $isCustomers
                ? "Ubah status customer: {$u->name}?"
                : "Ubah status admin: {$u->name}?";

              $deleteCustomerMsg = "Hapus customer: {$u->name}?\nAksi ini permanen dan hanya boleh jika belum punya order.";
              $deleteAdminMsg    = "Hapus admin: {$u->name}?\nAksi ini permanen.";
            ?>

            <tr class="hover:bg-slate-50 transition">
              
              <td class="px-4 py-3">
                <div class="flex items-center gap-3">
                  <div class="relative">
                    <div class="w-11 h-11 rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden flex items-center justify-center">
                      <?php if($photoUrl): ?>
                        <img src="<?php echo e($photoUrl); ?>" alt="Foto profil" class="w-full h-full object-cover">
                      <?php else: ?>
                        <?php if($initials): ?>
                          <div class="w-full h-full flex items-center justify-center bg-slate-100">
                            <span class="text-slate-700 font-extrabold"><?php echo e(mb_strtoupper($initials)); ?></span>
                          </div>
                        <?php else: ?>
                          <div class="w-full h-full flex items-center justify-center bg-slate-100">
                            <i class="fa-solid fa-user text-slate-500"></i>
                          </div>
                        <?php endif; ?>
                      <?php endif; ?>
                    </div>

                    
                    <span class="absolute -right-1 -bottom-1 w-4 h-4 rounded-full border-2 border-white <?php echo e($u->is_active ? 'bg-emerald-500' : 'bg-slate-400'); ?>"></span>
                  </div>

                  <div class="min-w-0">
                    <div class="flex items-center gap-2">
                      <div class="font-semibold text-slate-900 truncate"><?php echo e($u->name); ?></div>
                      <?php if($isAdmins && ($u->is_superadmin ?? false)): ?>
                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold border border-indigo-200 bg-indigo-50 text-indigo-700">
                          <i class="fa-solid fa-crown"></i> SUPER
                        </span>
                      <?php endif; ?>
                    </div>

                    <div class="mt-0.5 flex flex-wrap items-center gap-2">
                      <span class="inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-white text-slate-700">
                        <i class="fa-solid fa-at text-slate-500"></i>
                        <?php echo e($u->username); ?>

                      </span>
                      <span class="text-xs text-slate-500">ID: <?php echo e($u->id); ?></span>
                    </div>
                  </div>
                </div>
              </td>

              <?php if($isCustomers): ?>
                <td class="px-4 py-3 font-bold text-slate-900">
                  <?php echo e($u->orders_count ?? 0); ?>

                </td>
              <?php endif; ?>

              <td class="px-4 py-3">
                <?php if($u->is_active): ?>
                  <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-emerald-200 bg-emerald-50 text-emerald-700">
                    <i class="fa-solid fa-circle-check"></i> Aktif
                  </span>
                <?php else: ?>
                  <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-slate-100 text-slate-700">
                    <i class="fa-solid fa-circle-minus"></i> Nonaktif
                  </span>
                <?php endif; ?>
              </td>

              
              <td class="px-4 py-3">
                <div class="flex items-center justify-end gap-2">

                  
                  <button type="button"
                          class="btn-edit-user inline-flex items-center justify-center w-10 h-10 rounded-xl border border-slate-200 hover:bg-slate-50 transition"
                          title="Edit"
                          data-kind="<?php echo e($isCustomers ? 'customer' : 'admin'); ?>"
                          data-id="<?php echo e($u->id); ?>"
                          data-name="<?php echo e($u->name); ?>"
                          data-username="<?php echo e($u->username); ?>"
                          data-is-superadmin="<?php echo e(($isAdmins && ($u->is_superadmin ?? false)) ? '1' : '0'); ?>">
                    <i class="fa-solid fa-pen text-slate-600"></i>
                  </button>

                  
                  <div class="relative">
                    <button type="button"
                            class="btn-row-menu inline-flex items-center justify-center w-10 h-10 rounded-xl border border-slate-200 hover:bg-slate-50 transition"
                            aria-expanded="false"
                            aria-controls="row-menu-<?php echo e($menuId); ?>"
                            data-menu-id="row-menu-<?php echo e($menuId); ?>"
                            title="Aksi cepat">
                      <i class="fa-solid fa-ellipsis-vertical text-slate-600"></i>
                    </button>

                    <div id="row-menu-<?php echo e($menuId); ?>"
                         class="row-menu hidden absolute right-0 mt-2 w-56 rounded-2xl border border-slate-200 bg-white shadow-xl overflow-hidden z-[9999]">
                      <div class="py-2">

                        
                        <?php if($isCustomers): ?>
                          <button type="button"
                                  class="menu-action btn-view-customer w-full text-left px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-3"
                                  data-name="<?php echo e($u->name); ?>"
                                  data-username="<?php echo e($u->username); ?>"
                                  data-phone="<?php echo e($u->phone ?? ''); ?>"
                                  data-address="<?php echo e($u->default_address ?? ''); ?>"
                                  data-photo="<?php echo e($photoUrl); ?>"
                                  data-initials="<?php echo e($initials); ?>">
                            <i class="fa-solid fa-eye text-slate-500 w-4"></i>
                            Lihat detail pelanggan
                          </button>

                          <div class="my-2 h-px bg-slate-100"></div>
                        <?php endif; ?>

                        
                        <button type="button"
                                class="menu-action btn-edit-user w-full text-left px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-3"
                                data-kind="<?php echo e($isCustomers ? 'customer' : 'admin'); ?>"
                                data-id="<?php echo e($u->id); ?>"
                                data-name="<?php echo e($u->name); ?>"
                                data-username="<?php echo e($u->username); ?>"
                                data-is-superadmin="<?php echo e(($isAdmins && ($u->is_superadmin ?? false)) ? '1' : '0'); ?>">
                          <i class="fa-solid fa-pen text-slate-500 w-4"></i>
                          Edit
                        </button>

                        
                        <div class="px-2 pt-1">
                          <?php if($isAdmins && $isMe): ?>
                            <button type="button"
                                    class="w-full text-left px-3 py-2.5 rounded-xl text-sm text-slate-400 bg-slate-50 border border-slate-200 cursor-not-allowed flex items-center gap-3"
                                    disabled
                                    title="Tidak boleh ubah status akun sendiri.">
                              <i class="fa-solid fa-ban text-slate-400 w-4"></i>
                              Ubah status (terkunci)
                            </button>
                          <?php else: ?>
                            <form method="POST"
                                  action="<?php echo e($isCustomers ? route('admin.users.customers.toggle', $u) : route('admin.users.admins.toggle', $u)); ?>"
                                  onsubmit='return confirm(<?php echo json_encode($toggleMsg, 15, 512) ?>);'>
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('PATCH'); ?>
                              <button type="submit"
                                      class="menu-action w-full text-left px-3 py-2.5 rounded-xl text-sm border flex items-center gap-3
                                             <?php echo e($u->is_active ? 'border-red-200 bg-red-50 text-red-700 hover:bg-red-100' : 'border-emerald-200 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'); ?>">
                                <i class="fa-solid <?php echo e($u->is_active ? 'fa-ban' : 'fa-circle-check'); ?> w-4"></i>
                                <?php echo e($u->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?>

                              </button>
                            </form>
                          <?php endif; ?>
                        </div>

                        
                        <?php if($canManageAdmins): ?>
                          <div class="my-2 h-px bg-slate-100"></div>

                          <div class="px-2 pb-2">
                            <?php if($isCustomers): ?>
                              <?php if($hasOrders): ?>
                                <button type="button"
                                        class="w-full text-left px-3 py-2.5 rounded-xl text-sm text-slate-400 bg-slate-50 border border-slate-200 cursor-not-allowed flex items-center gap-3"
                                        disabled
                                        title="Tidak bisa dihapus karena customer sudah punya order. Nonaktifkan saja.">
                                  <i class="fa-solid fa-trash-can w-4"></i>
                                  Hapus permanen (terkunci)
                                </button>
                              <?php else: ?>
                                <form method="POST"
                                      action="<?php echo e(route('admin.users.customers.destroy', $u)); ?>"
                                      onsubmit='return confirm(<?php echo json_encode($deleteCustomerMsg, 15, 512) ?>);'>
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('DELETE'); ?>
                                  <button type="submit"
                                          class="menu-action w-full text-left px-3 py-2.5 rounded-xl text-sm border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 flex items-center gap-3">
                                    <i class="fa-solid fa-trash-can w-4"></i>
                                    Hapus permanen
                                  </button>
                                </form>
                              <?php endif; ?>
                            <?php else: ?>
                              <?php if($isMe): ?>
                                <button type="button"
                                        class="w-full text-left px-3 py-2.5 rounded-xl text-sm text-slate-400 bg-slate-50 border border-slate-200 cursor-not-allowed flex items-center gap-3"
                                        disabled
                                        title="Tidak boleh menghapus akun sendiri.">
                                  <i class="fa-solid fa-trash-can w-4"></i>
                                  Hapus admin (terkunci)
                                </button>
                              <?php else: ?>
                                <form method="POST"
                                      action="<?php echo e(route('admin.users.admins.destroy', $u)); ?>"
                                      onsubmit='return confirm(<?php echo json_encode($deleteAdminMsg, 15, 512) ?>);'>
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('DELETE'); ?>
                                  <button type="submit"
                                          class="menu-action w-full text-left px-3 py-2.5 rounded-xl text-sm border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 flex items-center gap-3">
                                    <i class="fa-solid fa-trash-can w-4"></i>
                                    Hapus admin
                                  </button>
                                </form>
                              <?php endif; ?>
                            <?php endif; ?>
                          </div>
                        <?php endif; ?>

                      </div>
                    </div>
                  </div>

                </div>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="<?php echo e($isCustomers ? 4 : 3); ?>" class="px-4 py-12">
                <div class="text-center text-slate-500">
                  <i class="fa-regular fa-folder-open text-3xl"></i>
                  <div class="mt-2 font-semibold text-slate-700">Belum ada data</div>
                  <div class="text-sm mt-1">Klik <b>Tambah</b> untuk membuat data baru.</div>
                </div>
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="pt-2">
    <?php echo e($rows->links()); ?>

  </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>

<div id="createUserModal" class="hidden" aria-hidden="true">
  <div class="fixed inset-0 z-[99999] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4"
       onclick="if(event.target===this) closeCreateUser()">
    <div class="w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
      <div class="px-6 py-4 border-b border-slate-200 bg-white flex items-center justify-between">
        <div>
          <div class="text-xs text-slate-500">Tambah</div>
          <div class="text-lg font-bold text-slate-900 flex items-center gap-2">
            <i class="fa-solid <?php echo e($isCustomers ? 'fa-users' : 'fa-user-shield'); ?> text-slate-600"></i>
            <?php echo e($isCustomers ? 'Customer Baru' : 'Admin Baru'); ?>

          </div>
        </div>
        <button type="button" onclick="closeCreateUser()"
                class="w-10 h-10 rounded-xl border border-slate-200 hover:bg-slate-50 transition inline-flex items-center justify-center text-slate-500"
                title="Tutup">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>

      <form method="POST"
            action="<?php echo e($isCustomers ? route('admin.users.customers.store') : route('admin.users.admins.store')); ?>"
            class="p-6 bg-slate-50 space-y-4">
        <?php echo csrf_field(); ?>

        <div>
          <label class="text-xs font-bold text-slate-600">Nama</label>
          <input id="c_name" name="name" required value="<?php echo e(old('name')); ?>"
                 class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
        </div>

        <div>
          <label class="text-xs font-bold text-slate-600">Username</label>
          <input name="username" required value="<?php echo e(old('username')); ?>"
                 class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label class="text-xs font-bold text-slate-600">Password</label>
            <input name="password" type="password" required
                   class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
          </div>
          <div>
            <label class="text-xs font-bold text-slate-600">Konfirmasi</label>
            <input name="password_confirmation" type="password" required
                   class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
          </div>
        </div>

        <div class="flex items-center gap-2">
          <input type="hidden" name="is_active" value="0">
          <input id="c_is_active" type="checkbox" name="is_active" value="1" checked
                 class="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-200">
          <label for="c_is_active" class="text-sm text-slate-700">Aktifkan akun</label>
        </div>

        <?php if($isAdmins && $canManageAdmins): ?>
          <div class="flex items-center gap-2">
            <input type="hidden" name="is_superadmin" value="0">
            <input id="c_is_superadmin" type="checkbox" name="is_superadmin" value="1"
                   class="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-200">
            <label for="c_is_superadmin" class="text-sm text-slate-700">Jadikan Super Admin</label>
          </div>
        <?php endif; ?>

        <div class="flex items-center justify-end gap-2 pt-2">
          <button type="button" onclick="closeCreateUser()"
                  class="px-4 py-2 rounded-xl border border-slate-200 hover:bg-white transition">
            Batal
          </button>
          <button type="submit"
                  class="px-4 py-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 transition inline-flex items-center gap-2">
            <i class="fa-solid fa-floppy-disk"></i>
            Simpan
          </button>
        </div>
      </form>
    </div>
  </div>
</div>


<div id="editUserModal" class="hidden" aria-hidden="true">
  <div class="fixed inset-0 z-[99999] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4"
       onclick="if(event.target===this) closeEditUser()">
    <div class="w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
      <div class="px-6 py-4 border-b border-slate-200 bg-white flex items-center justify-between">
        <div>
          <div class="text-xs text-slate-500">Edit</div>
          <div class="text-lg font-bold text-slate-900 flex items-center gap-2">
            <i class="fa-solid fa-pen text-slate-600"></i>
            <span id="e_title">Pengguna</span>
          </div>
        </div>
        <button type="button" onclick="closeEditUser()"
                class="w-10 h-10 rounded-xl border border-slate-200 hover:bg-slate-50 transition inline-flex items-center justify-center text-slate-500"
                title="Tutup">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>

      <form id="editUserForm" method="POST" action="#" class="p-6 bg-slate-50 space-y-4">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <input type="hidden" id="e_kind" value="customer">

        <div>
          <label class="text-xs font-bold text-slate-600">Nama</label>
          <input id="e_name" name="name" required
                 class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
        </div>

        <div>
          <label class="text-xs font-bold text-slate-600">Username</label>
          <input id="e_username" name="username" required
                 class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label class="text-xs font-bold text-slate-600">Password Baru (opsional)</label>
            <input id="e_password" name="password" type="password"
                   class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
          </div>
          <div>
            <label class="text-xs font-bold text-slate-600">Konfirmasi</label>
            <input id="e_password_confirmation" name="password_confirmation" type="password"
                   class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
          </div>
        </div>

        <?php if($canManageAdmins): ?>
          <div id="e_superadmin_wrap" class="hidden">
            <div class="flex items-center gap-2">
              <input type="hidden" name="is_superadmin" value="0">
              <input id="e_is_superadmin" type="checkbox" name="is_superadmin" value="1"
                     class="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-200">
              <label for="e_is_superadmin" class="text-sm text-slate-700">Super Admin</label>
            </div>
            <div class="text-[11px] text-slate-500 mt-1">
              Hati-hati: Super Admin punya akses kelola admin dan delete.
            </div>
          </div>
        <?php endif; ?>

        <div class="flex items-center justify-end gap-2 pt-2">
          <button type="button" onclick="closeEditUser()"
                  class="px-4 py-2 rounded-xl border border-slate-200 hover:bg-white transition">
            Batal
          </button>
          <button type="submit"
                  class="px-4 py-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 transition inline-flex items-center gap-2">
            <i class="fa-solid fa-floppy-disk"></i>
            Simpan Perubahan
          </button>
        </div>
      </form>
    </div>
  </div>
</div>


<div id="customerDetailModal" class="hidden" aria-hidden="true">
  <div class="fixed inset-0 z-[99999] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4"
       onclick="if(event.target===this) closeCustomerDetail()">
    <div class="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">

      <div class="px-6 py-4 border-b border-slate-200 bg-white flex items-center justify-between">
        <div class="flex items-center gap-3">
          <div class="w-11 h-11 rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center overflow-hidden">
            <img id="d_photo" class="w-full h-full object-cover hidden" alt="Foto profil">
            <div id="d_fallback" class="w-full h-full flex items-center justify-center">
              <span id="d_initials" class="text-slate-700 font-extrabold"></span>
              <i id="d_icon" class="fa-solid fa-user text-slate-500 hidden"></i>
            </div>
          </div>

          <div>
            <div class="text-xs text-slate-500">Detail Pelanggan</div>
            <div class="text-lg font-bold text-slate-900 leading-tight" id="d_name">-</div>
            <div class="mt-1 inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-slate-50 text-slate-700">
              <i class="fa-solid fa-at text-slate-500"></i>
              <span id="d_username">-</span>
            </div>
          </div>
        </div>

        <button type="button"
                onclick="closeCustomerDetail()"
                class="w-10 h-10 rounded-xl border border-slate-200 hover:bg-slate-50 transition inline-flex items-center justify-center text-slate-500"
                title="Tutup">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>

      <div class="p-6 bg-slate-50">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

          <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
            <div class="text-xs font-bold text-slate-600 flex items-center gap-2">
              <i class="fa-solid fa-phone text-slate-500"></i> No HP
            </div>
            <div class="mt-2 text-slate-900 font-semibold" id="d_phone">-</div>
            <div class="text-[11px] text-slate-500 mt-1">Nomor utama pelanggan.</div>
          </div>

          <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
            <div class="text-xs font-bold text-slate-600 flex items-center gap-2">
              <i class="fa-solid fa-location-dot text-slate-500"></i> Alamat Default
            </div>
            <div class="mt-2 text-slate-900 whitespace-pre-line" id="d_address">-</div>
            <div class="text-[11px] text-slate-500 mt-1">Bukan alamat jemput (alamat profil).</div>
          </div>

        </div>

        <div class="flex items-center justify-end gap-2 mt-5">
          <button type="button"
                  onclick="closeCustomerDetail()"
                  class="px-4 py-2 rounded-xl border border-slate-200 hover:bg-white transition">
            Tutup
          </button>
        </div>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
  const createModal = document.getElementById('createUserModal');
  const editModal   = document.getElementById('editUserModal');
  const detailModal = document.getElementById('customerDetailModal');

  const updateCustomerTemplate = <?php echo json_encode(route('admin.users.customers.update', ['customer' => '__ID__']), 512) ?>;
  const updateAdminTemplate    = <?php echo json_encode(route('admin.users.admins.update', ['admin' => '__ID__']), 512) ?>;

  function lockBody(lock){ document.body.classList.toggle('modal-open', !!lock); }

  // ===== Dropdown menu =====
  let openMenuEl = null;
  let openMenuBtn = null;

  function closeRowMenu() {
    if (!openMenuEl) return;
    openMenuEl.classList.add('hidden');
    if (openMenuBtn) openMenuBtn.setAttribute('aria-expanded', 'false');
    openMenuEl = null;
    openMenuBtn = null;
  }

  function toggleRowMenu(btn) {
    const id = btn.dataset.menuId;
    const menu = document.getElementById(id);
    if (!menu) return;

    // kalau klik menu yang sama
    if (openMenuEl === menu) {
      closeRowMenu();
      return;
    }

    closeRowMenu();
    menu.classList.remove('hidden');
    btn.setAttribute('aria-expanded', 'true');
    openMenuEl = menu;
    openMenuBtn = btn;
  }

  // ===== Create =====
  window.openCreateUser = function() {
    if (!createModal) return;
    createModal.classList.remove('hidden');
    lockBody(true);
    setTimeout(() => document.getElementById('c_name')?.focus(), 50);
  }
  window.closeCreateUser = function() {
    if (!createModal) return;
    createModal.classList.add('hidden');
    lockBody(false);
  }

  // ===== Edit =====
  function openEditUser(payload) {
    const form = document.getElementById('editUserForm');
    const wrap = document.getElementById('e_superadmin_wrap');
    const chk  = document.getElementById('e_is_superadmin');

    document.getElementById('e_kind').value = payload.kind;

    document.getElementById('e_title').textContent = payload.name || 'Pengguna';
    document.getElementById('e_name').value = payload.name ?? '';
    document.getElementById('e_username').value = payload.username ?? '';
    document.getElementById('e_password').value = '';
    document.getElementById('e_password_confirmation').value = '';

    if (payload.kind === 'admin') {
      form.action = updateAdminTemplate.replace('__ID__', payload.id);
      if (wrap) wrap.classList.remove('hidden');
      if (chk) chk.checked = (payload.is_superadmin === '1' || payload.is_superadmin === 1);
    } else {
      form.action = updateCustomerTemplate.replace('__ID__', payload.id);
      if (wrap) wrap.classList.add('hidden');
      if (chk) chk.checked = false;
    }

    editModal.classList.remove('hidden');
    lockBody(true);
    setTimeout(() => document.getElementById('e_name')?.focus(), 50);
  }

  window.closeEditUser = function() {
    if (!editModal) return;
    editModal.classList.add('hidden');
    lockBody(false);
  }

  // ===== Detail Customer =====
  window.openCustomerDetail = function(payload) {
    if (!detailModal) return;

    document.getElementById('d_name').textContent = payload.name || '-';
    document.getElementById('d_username').textContent = payload.username || '-';
    document.getElementById('d_phone').textContent = payload.phone || '-';
    document.getElementById('d_address').textContent = payload.address || '-';

    const img = document.getElementById('d_photo');
    const fallback = document.getElementById('d_fallback');
    const initialsEl = document.getElementById('d_initials');
    const iconEl = document.getElementById('d_icon');

    if (payload.photo) {
      img.src = payload.photo;
      img.classList.remove('hidden');
      fallback.classList.add('hidden');
    } else {
      img.classList.add('hidden');
      fallback.classList.remove('hidden');

      const initials = (payload.initials || '').trim();
      if (initials) {
        initialsEl.textContent = initials.toUpperCase();
        initialsEl.classList.remove('hidden');
        iconEl.classList.add('hidden');
      } else {
        initialsEl.textContent = '';
        initialsEl.classList.add('hidden');
        iconEl.classList.remove('hidden');
      }
    }

    detailModal.classList.remove('hidden');
    lockBody(true);
  }

  window.closeCustomerDetail = function() {
    if (!detailModal) return;
    detailModal.classList.add('hidden');
    lockBody(false);
  }

  // ===== Click handler (single) =====
  document.addEventListener('click', (e) => {
    const btnMenu = e.target.closest('.btn-row-menu');
    if (btnMenu) {
      toggleRowMenu(btnMenu);
      return;
    }

    // klik action di menu -> tutup menu dulu (biar rapi)
    if (e.target.closest('.menu-action')) {
      closeRowMenu();
    }

    const btnEdit = e.target.closest('.btn-edit-user');
    if (btnEdit) {
      closeRowMenu();
      openEditUser({
        kind: btnEdit.dataset.kind,
        id: btnEdit.dataset.id,
        name: btnEdit.dataset.name,
        username: btnEdit.dataset.username,
        is_superadmin: btnEdit.dataset.isSuperadmin
      });
      return;
    }

    const btnView = e.target.closest('.btn-view-customer');
    if (btnView) {
      closeRowMenu();
      openCustomerDetail({
        name: btnView.dataset.name,
        username: btnView.dataset.username,
        phone: btnView.dataset.phone,
        address: btnView.dataset.address,
        photo: btnView.dataset.photo,
        initials: btnView.dataset.initials
      });
      return;
    }

    // klik di luar menu -> tutup
    if (!e.target.closest('.row-menu')) {
      closeRowMenu();
    }
  });

  // ESC close (menu + modal)
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;

    closeRowMenu();

    if (createModal && !createModal.classList.contains('hidden')) closeCreateUser();
    if (editModal && !editModal.classList.contains('hidden')) closeEditUser();
    if (detailModal && !detailModal.classList.contains('hidden')) closeCustomerDetail();
  });

  // auto open create on validation errors
  <?php if($openCreateOnLoad): ?>
    openCreateUser();
  <?php endif; ?>

  // auto open edit on validation errors
  <?php if($editId && $editKind): ?>
    const btn = document.querySelector(`.btn-edit-user[data-kind="<?php echo e($editKind); ?>"][data-id="<?php echo e($editId); ?>"]`);
    if (btn) {
      btn.click();

      <?php if($errors->any()): ?>
        const oldName = <?php echo json_encode(old('name'), 15, 512) ?>;
        const oldUsername = <?php echo json_encode(old('username'), 15, 512) ?>;
        const oldIsSuper = <?php echo json_encode(old('is_superadmin'), 15, 512) ?>;

        if (oldName) document.getElementById('e_name').value = oldName;
        if (oldUsername) document.getElementById('e_username').value = oldUsername;

        const kind = document.getElementById('e_kind').value;
        if (kind === 'admin') {
          const chk = document.getElementById('e_is_superadmin');
          if (chk) chk.checked = (oldIsSuper == 1 || oldIsSuper === '1');
        }
      <?php endif; ?>
    }
  <?php endif; ?>
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Juragan_Kucek_Project\backend\resources\views/admin/pages/users/index.blade.php ENDPATH**/ ?>