

<?php $__env->startSection('title','Laporan Pendapatan'); ?>
<?php $__env->startSection('page_title','Laporan Pendapatan'); ?>

<?php $__env->startSection('content'); ?>
<?php
  $hasFilter = request()->filled('start') || request()->filled('end') || request()->filled('method') || request()->filled('service_id') || request()->filled('search');

  $chip = fn($text) => "inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-slate-50 text-slate-700";

  $methodBadge = function ($m) {
    $m = strtoupper((string)$m);
    return match($m) {
      'TRANSFER' => 'border-indigo-200 bg-indigo-50 text-indigo-700',
      'CASH'     => 'border-emerald-200 bg-emerald-50 text-emerald-700',
      'EWALLET', 'E-WALLET' => 'border-amber-200 bg-amber-50 text-amber-700',
      default    => 'border-slate-200 bg-slate-50 text-slate-700',
    };
  };
?>

<div class="space-y-6">

  
  <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
    <div>
      <h2 class="text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight">
        Laporan Pendapatan
      </h2>
      <p class="text-sm text-slate-500 mt-1">
        Pendapatan dihitung dari pembayaran <b class="text-slate-700">APPROVED</b> berdasarkan <b class="text-slate-700">verified_at</b> pada periode terpilih.
      </p>

      <div class="mt-3 flex flex-wrap items-center gap-2">
        <span class="<?php echo e($chip('')); ?>">
          <i class="fa-solid fa-calendar-days text-slate-500"></i>
          Periode: <b class="text-slate-900"><?php echo e($start); ?></b> s/d <b class="text-slate-900"><?php echo e($end); ?></b>
        </span>

        <?php if($trendRangeText ?? null): ?>
          <span class="<?php echo e($chip('')); ?>">
            <i class="fa-solid fa-chart-line text-slate-500"></i>
            Tren 30 hari: <b class="text-slate-900"><?php echo e($trendRangeText); ?></b>
          </span>
        <?php endif; ?>
      </div>
    </div>

    <div class="flex items-center gap-2">
      <a href="<?php echo e(route('admin.report.export', request()->query())); ?>"
         class="px-4 py-2 rounded-2xl border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.99] transition inline-flex items-center gap-2 shadow-sm">
        <span class="w-9 h-9 rounded-xl bg-slate-900 text-white inline-flex items-center justify-center">
          <i class="fa-solid fa-file-csv"></i>
        </span>
        <div class="leading-tight">
          <div class="text-sm font-extrabold text-slate-900">Export CSV</div>
          <div class="text-[11px] text-slate-500">Sesuai filter</div>
        </div>
      </a>
    </div>
  </div>

  
  <div class="bg-white rounded-3xl border border-slate-200 p-4 md:p-5 shadow-sm">
    <form class="grid grid-cols-1 md:grid-cols-12 gap-3">
      <div class="md:col-span-3">
        <label class="text-xs font-bold text-slate-600">Mulai</label>
        <div class="relative mt-1">
          <i class="fa-solid fa-calendar absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
          <input type="date" name="start" value="<?php echo e($start); ?>"
                 class="w-full rounded-2xl border border-slate-200 pl-10 pr-4 py-2.5 outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-200" />
        </div>
      </div>

      <div class="md:col-span-3">
        <label class="text-xs font-bold text-slate-600">Sampai</label>
        <div class="relative mt-1">
          <i class="fa-solid fa-calendar-check absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
          <input type="date" name="end" value="<?php echo e($end); ?>"
                 class="w-full rounded-2xl border border-slate-200 pl-10 pr-4 py-2.5 outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-200" />
        </div>
      </div>

      <div class="md:col-span-2">
        <label class="text-xs font-bold text-slate-600">Metode</label>
        <div class="relative mt-1">
          <i class="fa-solid fa-credit-card absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
          <select name="method"
                  class="w-full rounded-2xl border border-slate-200 pl-10 pr-10 py-2.5 outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-200">
            <option value="">Semua</option>
            <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($m); ?>" <?php if(request('method')===$m): echo 'selected'; endif; ?>><?php echo e($m); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>

      <div class="md:col-span-2">
        <label class="text-xs font-bold text-slate-600">Layanan</label>
        <div class="relative mt-1">
          <i class="fa-solid fa-tags absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
          <select name="service_id"
                  class="w-full rounded-2xl border border-slate-200 pl-10 pr-10 py-2.5 outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-200">
            <option value="">Semua</option>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($s->id); ?>" <?php if((string)request('service_id')===(string)$s->id): echo 'selected'; endif; ?>><?php echo e($s->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>

      <div class="md:col-span-2">
        <label class="text-xs font-bold text-slate-600">Cari</label>
        <div class="relative mt-1">
          <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
          <input name="search" value="<?php echo e(request('search')); ?>"
                 placeholder="Order / user / nama"
                 class="w-full rounded-2xl border border-slate-200 pl-10 pr-4 py-2.5 outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-200" />
        </div>
      </div>

      <div class="md:col-span-12 flex flex-col md:flex-row md:items-center md:justify-between gap-3 pt-1">
        
        <div class="flex flex-wrap items-center gap-2">
          <?php if($hasFilter): ?>
            <span class="text-xs text-slate-500">Filter aktif:</span>

            <?php if(request()->filled('method')): ?>
              <span class="<?php echo e($chip('')); ?>">
                <i class="fa-solid fa-credit-card text-slate-500"></i>
                <?php echo e(request('method')); ?>

              </span>
            <?php endif; ?>

            <?php if(request()->filled('service_id')): ?>
              <span class="<?php echo e($chip('')); ?>">
                <i class="fa-solid fa-tags text-slate-500"></i>
                Service ID: <?php echo e(request('service_id')); ?>

              </span>
            <?php endif; ?>

            <?php if(request()->filled('search')): ?>
              <span class="<?php echo e($chip('')); ?>">
                <i class="fa-solid fa-magnifying-glass text-slate-500"></i>
                "<?php echo e(request('search')); ?>"
              </span>
            <?php endif; ?>
          <?php else: ?>
            <span class="text-xs text-slate-500">Tip: pakai filter biar laporan lebih tajam.</span>
          <?php endif; ?>
        </div>

        <div class="flex items-center justify-end gap-2">
          <button
            class="px-5 py-2.5 rounded-2xl bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.99] transition inline-flex items-center gap-2 shadow-sm">
            <span class="w-9 h-9 rounded-xl bg-white/15 inline-flex items-center justify-center">
              <i class="fa-solid fa-filter"></i>
            </span>
            <span class="font-extrabold">Terapkan</span>
          </button>

          <a href="<?php echo e(route('admin.report.index')); ?>"
             class="px-5 py-2.5 rounded-2xl border border-slate-200 hover:bg-slate-50 active:scale-[0.99] transition inline-flex items-center gap-2">
            <span class="w-9 h-9 rounded-xl bg-slate-100 inline-flex items-center justify-center text-slate-700">
              <i class="fa-solid fa-rotate-left"></i>
            </span>
            <span class="font-bold text-slate-700">Reset</span>
          </a>
        </div>
      </div>
    </form>
  </div>

  
  <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    
    <div class="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm">
      <div class="flex items-start justify-between gap-3">
        <div>
          <div class="text-xs font-extrabold text-slate-600 tracking-wide uppercase">Total Pendapatan</div>
          <div class="mt-2 text-3xl font-extrabold text-slate-900"><?php echo e(rupiah($totalRevenue)); ?></div>
          <div class="mt-1 text-xs text-slate-500">APPROVED dalam periode</div>
        </div>
        <div class="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 inline-flex items-center justify-center text-indigo-700">
          <i class="fa-solid fa-sack-dollar text-xl"></i>
        </div>
      </div>
      <div class="mt-4 h-2 rounded-full bg-slate-100 overflow-hidden">
        <div class="h-2 bg-indigo-500" style="width: 100%"></div>
      </div>
    </div>

    
    <div class="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm">
      <div class="flex items-start justify-between gap-3">
        <div>
          <div class="text-xs font-extrabold text-slate-600 tracking-wide uppercase">Transaksi Lunas</div>
          <div class="mt-2 text-3xl font-extrabold text-slate-900"><?php echo e(number_format((int)$txCount)); ?></div>
          <div class="mt-1 text-xs text-slate-500">Jumlah pembayaran disetujui</div>
        </div>
        <div class="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-100 inline-flex items-center justify-center text-emerald-700">
          <i class="fa-solid fa-circle-check text-xl"></i>
        </div>
      </div>
      <div class="mt-4 h-2 rounded-full bg-slate-100 overflow-hidden">
        <div class="h-2 bg-emerald-500" style="width: 85%"></div>
      </div>
    </div>

    
    <div class="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm">
      <div class="flex items-start justify-between gap-3">
        <div class="min-w-0">
          <div class="text-xs font-extrabold text-slate-600 tracking-wide uppercase">Metode Teratas</div>
          <div class="mt-2 space-y-2">
            <?php $__empty_1 = true; $__currentLoopData = $byMethod->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="flex items-center justify-between gap-3">
                <span class="min-w-0 truncate inline-flex items-center gap-2 text-sm font-bold text-slate-800">
                  <span class="w-2.5 h-2.5 rounded-full bg-slate-400"></span>
                  <?php echo e($bm->method ?? '-'); ?>

                </span>
                <span class="text-sm font-extrabold text-slate-900"><?php echo e(rupiah($bm->total)); ?></span>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div class="text-sm text-slate-500">Tidak ada data.</div>
            <?php endif; ?>
          </div>
        </div>
        <div class="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-100 inline-flex items-center justify-center text-amber-700">
          <i class="fa-solid fa-receipt text-xl"></i>
        </div>
      </div>
      <div class="mt-4 h-2 rounded-full bg-slate-100 overflow-hidden">
        <div class="h-2 bg-amber-500" style="width: 70%"></div>
      </div>
    </div>
  </div>

  
  <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
    
    <div class="lg:col-span-7 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
      <div class="px-5 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
        <div>
          <div class="font-extrabold text-slate-900 flex items-center gap-2">
            <span class="w-8 h-8 rounded-2xl bg-indigo-600 text-white inline-flex items-center justify-center">
              <i class="fa-solid fa-chart-line"></i>
            </span>
            Grafik Tren 30 Hari
          </div>
          <div class="text-xs text-slate-500 mt-1">Rentang: <b class="text-slate-700"><?php echo e($trendRangeText); ?></b></div>
        </div>
      </div>

      <div class="p-5">
        <div class="w-full" style="height: 290px;">
          <canvas id="trendChart" class="w-full h-full"></canvas>
        </div>
        <div id="trendEmpty" class="hidden mt-3 text-sm text-slate-500">
          Tidak ada data untuk grafik pada rentang ini.
        </div>
        <div class="mt-2 text-[11px] text-slate-500">
          Catatan: pendapatan harian dari pembayaran APPROVED berdasarkan verified_at.
        </div>
      </div>
    </div>

    
    <div class="lg:col-span-5 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
      <div class="px-5 py-4 bg-slate-50 border-b border-slate-200">
        <div class="font-extrabold text-slate-900 flex items-center gap-2">
          <span class="w-8 h-8 rounded-2xl bg-slate-900 text-white inline-flex items-center justify-center">
            <i class="fa-solid fa-trophy"></i>
          </span>
          Top Layanan (Ringkas)
        </div>
        <div class="text-xs text-slate-500 mt-1">3 layanan paling menghasilkan</div>
      </div>

      <div class="p-5 space-y-3">
        <?php $__empty_1 = true; $__currentLoopData = $byService->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php
            $share = ($totalRevenue > 0) ? (($sv->total / $totalRevenue) * 100) : 0;
          ?>
          <div class="rounded-2xl border border-slate-200 p-4 hover:bg-slate-50 transition">
            <div class="flex items-start justify-between gap-3">
              <div class="min-w-0">
                <div class="flex items-center gap-2">
                  <span class="w-7 h-7 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-700 inline-flex items-center justify-center text-xs font-extrabold">
                    <?php echo e($idx + 1); ?>

                  </span>
                  <div class="font-extrabold text-slate-900 truncate"><?php echo e($sv->service_name); ?></div>
                </div>
                <div class="text-xs text-slate-500 mt-1"><?php echo e((int)$sv->tx_count); ?> trx • <?php echo e(number_format($share,1)); ?>%</div>
              </div>
              <div class="text-right">
                <div class="font-extrabold text-slate-900"><?php echo e(rupiah($sv->total)); ?></div>
                <div class="text-[11px] text-slate-500">Service ID: <?php echo e($sv->service_id ?? '-'); ?></div>
              </div>
            </div>
            <div class="mt-3 h-2 rounded-full bg-slate-100 overflow-hidden">
              <div class="h-2 bg-indigo-500" style="width: <?php echo e(min(100, $share)); ?>%"></div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <div class="text-sm text-slate-500">Tidak ada data pada filter ini.</div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  
  <div class="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
    <div class="px-5 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
      <div>
        <div class="font-extrabold text-slate-900 flex items-center gap-2">
          <span class="w-8 h-8 rounded-2xl bg-indigo-600 text-white inline-flex items-center justify-center">
            <i class="fa-solid fa-tags"></i>
          </span>
          Top Layanan
        </div>
        <div class="text-xs text-slate-500 mt-1">Rekap pendapatan per layanan pada periode terpilih</div>
      </div>
    </div>

    <div class="overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="bg-white text-slate-600">
          <tr class="border-b border-slate-100">
            <th class="text-left px-5 py-3">#</th>
            <th class="text-left px-5 py-3">Layanan</th>
            <th class="text-left px-5 py-3">Transaksi</th>
            <th class="text-left px-5 py-3">Share</th>
            <th class="text-right px-5 py-3">Total</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
          <?php $__empty_1 = true; $__currentLoopData = $byService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php $share = ($totalRevenue > 0) ? (($sv->total / $totalRevenue) * 100) : 0; ?>
            <tr class="odd:bg-white even:bg-slate-50/40 hover:bg-indigo-50/30 transition">
              <td class="px-5 py-4 font-extrabold text-slate-900"><?php echo e($i + 1); ?></td>
              <td class="px-5 py-4">
                <div class="font-extrabold text-slate-900"><?php echo e($sv->service_name); ?></div>
                <div class="text-xs text-slate-500">Service ID: <?php echo e($sv->service_id ?? '-'); ?></div>
              </td>
              <td class="px-5 py-4 font-bold text-slate-900"><?php echo e((int)$sv->tx_count); ?></td>
              <td class="px-5 py-4">
                <div class="flex items-center gap-3">
                  <div class="w-40 h-2.5 rounded-full bg-slate-100 overflow-hidden">
                    <div class="h-2.5 bg-indigo-500" style="width: <?php echo e(min(100, $share)); ?>%"></div>
                  </div>
                  <div class="text-sm font-extrabold text-slate-700 w-16"><?php echo e(number_format($share, 1)); ?>%</div>
                </div>
              </td>
              <td class="px-5 py-4 text-right font-extrabold text-slate-900"><?php echo e(rupiah($sv->total)); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="5" class="px-5 py-12 text-center text-slate-500">
                <div class="inline-flex flex-col items-center gap-2">
                  <i class="fa-regular fa-face-frown text-2xl"></i>
                  <div class="font-bold">Tidak ada data</div>
                  <div class="text-sm">Coba ubah periode / filter.</div>
                </div>
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  
  <div class="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
    <div class="px-5 py-4 bg-slate-50 border-b border-slate-200">
      <div class="font-extrabold text-slate-900 flex items-center gap-2">
        <span class="w-8 h-8 rounded-2xl bg-slate-900 text-white inline-flex items-center justify-center">
          <i class="fa-solid fa-list"></i>
        </span>
        Detail Transaksi
      </div>
      <div class="text-xs text-slate-500 mt-1">List pembayaran APPROVED (paginated)</div>
    </div>

    <div class="overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="bg-white text-slate-600">
          <tr class="border-b border-slate-100">
            <th class="text-left px-5 py-3">Waktu</th>
            <th class="text-left px-5 py-3">Order</th>
            <th class="text-left px-5 py-3">Customer</th>
            <th class="text-left px-5 py-3">Layanan</th>
            <th class="text-left px-5 py-3">Metode</th>
            <th class="text-right px-5 py-3">Nominal</th>
            <th class="text-left px-5 py-3">Verifier</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
          <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
              $amount = $p->amount ?? optional($p->order)->total_price ?? 0;
              $cust = optional(optional($p->order)->customer);
              $uname = $cust->username;
              $m = strtoupper((string)$p->method);
            ?>
            <tr class="odd:bg-white even:bg-slate-50/40 hover:bg-slate-50 transition">
              <td class="px-5 py-4 text-slate-700 whitespace-nowrap">
                <div class="font-bold"><?php echo e($p->verified_at ? tgl_id($p->verified_at) : '-'); ?></div>
                <div class="text-xs text-slate-500"><?php echo e($p->verified_at ? $p->verified_at->format('H:i') : ''); ?></div>
              </td>

              <td class="px-5 py-4 whitespace-nowrap">
                <div class="font-extrabold text-slate-900">
                  <?php echo e(optional($p->order)->order_code ?? '-'); ?>

                </div>
                <div class="text-xs text-slate-500">ID: <?php echo e($p->order_id ?? '-'); ?></div>
              </td>

              <td class="px-5 py-4">
                <div class="font-bold text-slate-900"><?php echo e($cust->name ?? '-'); ?></div>
                <div class="text-xs text-slate-500"><?php echo e($uname ? '@'.$uname : '-'); ?></div>
              </td>

              <td class="px-5 py-4 text-slate-700">
                <div class="font-bold text-slate-900"><?php echo e(optional(optional($p->order)->service)->name ?? '-'); ?></div>
              </td>

              <td class="px-5 py-4">
                <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold border <?php echo e($methodBadge($m)); ?>">
                  <i class="fa-solid fa-bolt text-[10px] opacity-70"></i>
                  <?php echo e($m ?: '-'); ?>

                </span>
              </td>

              <td class="px-5 py-4 text-right font-extrabold text-slate-900 whitespace-nowrap">
                <?php echo e(rupiah($amount)); ?>

              </td>

              <td class="px-5 py-4 text-slate-700">
                <?php if(optional($p->verifiedByAdmin)->name): ?>
                  <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold border border-slate-200 bg-white text-slate-700">
                    <i class="fa-solid fa-user-shield text-slate-500"></i>
                    <?php echo e($p->verifiedByAdmin->name); ?>

                  </span>
                <?php else: ?>
                  <span class="text-slate-400">-</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="7" class="px-5 py-12 text-center text-slate-500">
                <div class="inline-flex flex-col items-center gap-2">
                  <i class="fa-regular fa-folder-open text-3xl"></i>
                  <div class="font-bold text-slate-700">Tidak ada transaksi</div>
                  <div class="text-sm">Coba ubah periode / filter.</div>
                </div>
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <div class="p-5">
      <?php echo e($payments->links()); ?>

    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  (function () {
    const canvas = document.getElementById('trendChart');
    if (!canvas) return;

    const labels = <?php echo json_encode($trendLabels ?? [], 15, 512) ?>;
    const values = <?php echo json_encode($trendTotals ?? [], 15, 512) ?>;
    const emptyEl = document.getElementById('trendEmpty');

    function formatRp(n) {
      try { return new Intl.NumberFormat('id-ID').format(n || 0); }
      catch { return String(n || 0); }
    }

    function draw() {
      const parent = canvas.parentElement;
      const w = Math.max(360, parent.clientWidth || 900);
      const h = Math.max(240, parent.clientHeight || 290);
      const dpr = window.devicePixelRatio || 1;

      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';

      const ctx = canvas.getContext('2d');
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);

      const max = Math.max(...values, 0);
      const hasData = max > 0;

      if (!hasData) {
        if (emptyEl) emptyEl.classList.remove('hidden');
        ctx.fillStyle = '#64748b';
        ctx.font = '14px system-ui, -apple-system, Segoe UI, Roboto';
        ctx.fillText('Tidak ada data untuk grafik pada rentang ini.', 16, 40);
        return;
      }
      if (emptyEl) emptyEl.classList.add('hidden');

      const padL = 64, padR = 18, padT = 18, padB = 38;
      const plotW = w - padL - padR;
      const plotH = h - padT - padB;

      // Grid
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 1;
      for (let i = 0; i <= 4; i++) {
        const y = padT + (plotH * i / 4);
        ctx.beginPath();
        ctx.moveTo(padL, y);
        ctx.lineTo(w - padR, y);
        ctx.stroke();
      }

      // Y labels
      ctx.fillStyle = '#64748b';
      ctx.font = '12px system-ui, -apple-system, Segoe UI, Roboto';
      for (let i = 0; i <= 4; i++) {
        const v = Math.round(max * (1 - i / 4));
        const y = padT + (plotH * i / 4);
        ctx.fillText('Rp ' + formatRp(v), 10, y + 4);
      }

      const n = Math.max(values.length, 1);
      const stepX = plotW / Math.max(n - 1, 1);

      function xy(i, v) {
        const x = padL + (i * stepX);
        const y = padT + plotH - (v / max) * plotH;
        return [x, y];
      }

      // Area subtle
      ctx.beginPath();
      for (let i = 0; i < values.length; i++) {
        const [x, y] = xy(i, values[i] || 0);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.lineTo(padL + (values.length - 1) * stepX, padT + plotH);
      ctx.lineTo(padL, padT + plotH);
      ctx.closePath();
      ctx.fillStyle = 'rgba(79, 70, 229, 0.08)'; // indigo
      ctx.fill();

      // Line
      ctx.strokeStyle = '#4f46e5';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 0; i < values.length; i++) {
        const [x, y] = xy(i, values[i] || 0);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Points (sparse)
      ctx.fillStyle = '#4f46e5';
      for (let i = 0; i < values.length; i++) {
        if (i % 5 !== 0 && i !== values.length - 1) continue;
        const [x, y] = xy(i, values[i] || 0);
        ctx.beginPath();
        ctx.arc(x, y, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      // X labels
      ctx.fillStyle = '#64748b';
      ctx.font = '11px system-ui, -apple-system, Segoe UI, Roboto';
      for (let i = 0; i < labels.length; i++) {
        if (i % 5 !== 0 && i !== labels.length - 1) continue;
        const x = padL + (i * stepX);
        ctx.fillText(labels[i], x - 12, h - 14);
      }
    }

    draw();
    window.addEventListener('resize', () => draw());
  })();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Juragan_Kucek_Project\backend\resources\views/admin/pages/report/index.blade.php ENDPATH**/ ?>