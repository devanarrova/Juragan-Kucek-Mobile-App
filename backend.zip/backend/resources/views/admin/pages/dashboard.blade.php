@extends('admin.layouts.app')

@section('title', 'Beranda')
@section('page_title', 'Beranda')

@section('content')
@php
  $fmtDate = function ($dt) {
    if (!$dt) return '-';
    return function_exists('tgl_id') ? tgl_id($dt) : \Carbon\Carbon::parse($dt)->format('d M Y');
  };

  $fmtTime = function ($dt) {
    if (!$dt) return '';
    return \Carbon\Carbon::parse($dt)->format('H:i');
  };

  $money = fn($v) => function_exists('rupiah') ? rupiah($v) : 'Rp ' . number_format((float)$v, 0, ',', '.');

  $pendingPaymentsCount   = (int)($pendingPaymentsCount ?? 0);
  $ordersNeedConfirmCount = (int)($ordersNeedConfirmCount ?? 0);
  $ordersInProgressCount  = (int)($ordersInProgressCount ?? 0);
  $ordersTodayCount       = (int)($ordersTodayCount ?? 0);

  $customersActiveCount = (int)($customersActiveCount ?? 0);
  $customersTotalCount  = (int)($customersTotalCount ?? 0);
  $servicesActiveCount  = (int)($servicesActiveCount ?? 0);

  $revenueToday     = (float)($revenueToday ?? 0);
  $revenueThisMonth = (float)($revenueThisMonth ?? 0);

  $trendLabels = $trendLabels ?? [];
  $trendTotals = $trendTotals ?? [];
  $trendRangeText = $trendRangeText ?? '-';

  $statusMeta = function ($status) {
    $s = strtoupper((string)$status);
    return match($s) {
      'MENUNGGU_KONFIRMASI' => ['Menunggu Konfirmasi', 'border-amber-200 bg-amber-50 text-amber-700', 'fa-regular fa-hourglass'],
      'DIPROSES'            => ['Diproses', 'border-indigo-200 bg-indigo-50 text-indigo-700', 'fa-solid fa-gears'],
      'DIANTAR'             => ['Diantar', 'border-sky-200 bg-sky-50 text-sky-700', 'fa-solid fa-truck'],
      'LUNAS_SIAP_DIANTAR'  => ['Siap Diantar', 'border-violet-200 bg-violet-50 text-violet-700', 'fa-solid fa-box'],
      'SELESAI'             => ['Selesai', 'border-emerald-200 bg-emerald-50 text-emerald-700', 'fa-solid fa-circle-check'],
      'DIBATALKAN'          => ['Dibatalkan', 'border-red-200 bg-red-50 text-red-700', 'fa-solid fa-ban'],
      default               => [str_replace('_',' ', $s ?: '-'), 'border-slate-200 bg-slate-50 text-slate-700', 'fa-regular fa-circle'],
    };
  };

  $card = "bg-white rounded-3xl border border-slate-200 shadow-sm";
@endphp

<div class="space-y-6">

  {{-- HERO: fokus action --}}
  <div class="rounded-3xl overflow-hidden border border-slate-200 shadow-sm bg-gradient-to-r from-indigo-700 via-indigo-600 to-slate-900 text-white relative">
    <div class="absolute -right-20 -top-20 w-72 h-72 rounded-full bg-white/10 blur-2xl"></div>
    <div class="absolute -left-24 -bottom-24 w-80 h-80 rounded-full bg-white/10 blur-2xl"></div>

    <div class="p-6 md:p-8 relative">
      <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        <div class="min-w-0">
          <div class="text-white/75 text-xs font-extrabold uppercase tracking-wider">Admin Dashboard • Juragan Kucek</div>
          <h2 class="mt-2 text-2xl md:text-3xl font-extrabold tracking-tight">
            Prioritas Hari Ini
          </h2>
          <p class="mt-1 text-white/75 text-sm">
            Jangan lihat grafik dulu. Kerjain yang “numpuk” dulu.
          </p>

          {{-- Priority chips --}}
          <div class="mt-4 flex flex-wrap gap-2">
            <a href="{{ route('admin.verify.index') }}"
               class="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-white/15 hover:bg-white/20 border border-white/20 active:scale-[0.99] transition text-sm font-extrabold">
              <i class="fa-solid fa-file-invoice-dollar"></i>
              Verifikasi Bayar
              @if($pendingPaymentsCount > 0)
                <span class="inline-flex items-center justify-center min-w-[26px] h-6 px-2 rounded-full bg-white text-indigo-700 text-xs font-extrabold">
                  {{ $pendingPaymentsCount }}
                </span>
              @endif
            </a>

            <a href="{{ route('admin.orders.index', ['status' => 'MENUNGGU_KONFIRMASI']) }}"
               class="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/15 active:scale-[0.99] transition text-sm font-extrabold">
              <i class="fa-regular fa-hourglass"></i>
              Menunggu Konfirmasi
              @if($ordersNeedConfirmCount > 0)
                <span class="inline-flex items-center justify-center min-w-[26px] h-6 px-2 rounded-full bg-amber-400 text-slate-900 text-xs font-extrabold">
                  {{ $ordersNeedConfirmCount }}
                </span>
              @endif
            </a>

            <a href="{{ route('admin.report.index') }}"
               class="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/15 active:scale-[0.99] transition text-sm font-extrabold">
              <i class="fa-solid fa-chart-line"></i>
              Laporan
            </a>
          </div>

          {{-- Quick search --}}
          <form method="GET" action="{{ route('admin.orders.index') }}" class="mt-5">
            <div class="flex flex-col sm:flex-row gap-2">
              <div class="relative flex-1">
                <i class="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-white/60"></i>
                <input name="search" placeholder="Cari order_code / username..."
                       class="w-full rounded-2xl bg-white/10 border border-white/15 pl-11 pr-4 py-3 text-white placeholder:text-white/50 outline-none focus:ring-2 focus:ring-white/25" />
              </div>
              <button class="px-5 py-3 rounded-2xl bg-white text-indigo-700 font-extrabold hover:bg-white/90 active:scale-[0.99] transition inline-flex items-center justify-center gap-2">
                <i class="fa-solid fa-arrow-right"></i>
                Cari
              </button>
            </div>
          </form>
        </div>

        {{-- Revenue panel --}}
        <div class="w-full lg:w-[420px] grid grid-cols-2 gap-3">
          <div class="rounded-3xl bg-white/10 border border-white/15 p-4">
            <div class="text-xs text-white/70 font-extrabold uppercase tracking-wide">Pendapatan Hari Ini</div>
            <div class="mt-2 text-xl font-extrabold">{{ $money($revenueToday) }}</div>
            <div class="mt-1 text-[11px] text-white/70">Approved (verified_at)</div>
          </div>
          <div class="rounded-3xl bg-white/10 border border-white/15 p-4">
            <div class="text-xs text-white/70 font-extrabold uppercase tracking-wide">Pendapatan Bulan Ini</div>
            <div class="mt-2 text-xl font-extrabold">{{ $money($revenueThisMonth) }}</div>
            <div class="mt-1 text-[11px] text-white/70">Berjalan</div>
          </div>

          <div class="col-span-2 rounded-3xl bg-white/10 border border-white/15 p-4">
            <div class="flex items-center justify-between gap-3">
              <div class="min-w-0">
                <div class="text-xs text-white/70 font-extrabold uppercase tracking-wide">Kondisi Operasional</div>
                <div class="mt-2 flex flex-wrap gap-2">
                  <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-white/10 border border-white/15">
                    <i class="fa-solid fa-file-invoice"></i> Order hari ini: {{ $ordersTodayCount }}
                  </span>
                  <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-white/10 border border-white/15">
                    <i class="fa-solid fa-gears"></i> Berjalan: {{ $ordersInProgressCount }}
                  </span>
                  <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-white/10 border border-white/15">
                    <i class="fa-solid fa-users"></i> Customer aktif: {{ $customersActiveCount }}
                  </span>
                  <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-white/10 border border-white/15">
                    <i class="fa-solid fa-tags"></i> Layanan aktif: {{ $servicesActiveCount }}
                  </span>
                </div>
              </div>
              <div class="text-right">
                <div class="text-[11px] text-white/70">Update:</div>
                <div class="text-sm font-extrabold">{{ now()->format('H:i') }}</div>
              </div>
            </div>
          </div>
        </div>
        {{-- end revenue panel --}}
      </div>
    </div>
  </div>

  {{-- KPI: compact tapi jelas --}}
  <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
    <div class="{{ $card }} p-5">
      <div class="flex items-start justify-between gap-3">
        <div>
          <div class="text-xs font-extrabold text-slate-500 uppercase tracking-wide">Pending Verifikasi</div>
          <div class="mt-2 text-3xl font-extrabold text-slate-900">{{ number_format($pendingPaymentsCount) }}</div>
          <div class="mt-1 text-xs text-slate-500">Pembayaran PENDING</div>
        </div>
        <div class="w-12 h-12 rounded-2xl bg-violet-50 border border-violet-100 inline-flex items-center justify-center text-violet-700">
          <i class="fa-solid fa-file-invoice-dollar text-xl"></i>
        </div>
      </div>
    </div>

    <div class="{{ $card }} p-5">
      <div class="flex items-start justify-between gap-3">
        <div>
          <div class="text-xs font-extrabold text-slate-500 uppercase tracking-wide">Butuh Konfirmasi</div>
          <div class="mt-2 text-3xl font-extrabold text-slate-900">{{ number_format($ordersNeedConfirmCount) }}</div>
          <div class="mt-1 text-xs text-slate-500">MENUNGGU_KONFIRMASI</div>
        </div>
        <div class="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-100 inline-flex items-center justify-center text-amber-700">
          <i class="fa-regular fa-hourglass text-xl"></i>
        </div>
      </div>
    </div>

    <div class="{{ $card }} p-5">
      <div class="flex items-start justify-between gap-3">
        <div>
          <div class="text-xs font-extrabold text-slate-500 uppercase tracking-wide">Proses Berjalan</div>
          <div class="mt-2 text-3xl font-extrabold text-slate-900">{{ number_format($ordersInProgressCount) }}</div>
          <div class="mt-1 text-xs text-slate-500">Diproses / Siap / Diantar</div>
        </div>
        <div class="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 inline-flex items-center justify-center text-indigo-700">
          <i class="fa-solid fa-gears text-xl"></i>
        </div>
      </div>
    </div>

    <div class="{{ $card }} p-5">
      <div class="flex items-start justify-between gap-3">
        <div>
          <div class="text-xs font-extrabold text-slate-500 uppercase tracking-wide">Order Masuk</div>
          <div class="mt-2 text-3xl font-extrabold text-slate-900">{{ number_format($ordersTodayCount) }}</div>
          <div class="mt-1 text-xs text-slate-500">Hari ini</div>
        </div>
        <div class="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-100 inline-flex items-center justify-center text-emerald-700">
          <i class="fa-solid fa-bolt text-xl"></i>
        </div>
      </div>
    </div>
  </div>

  {{-- Trend + Top Services --}}
  <div class="grid grid-cols-1 xl:grid-cols-12 gap-4">
    {{-- Trend --}}
    <div class="xl:col-span-8 {{ $card }} overflow-hidden">
      <div class="px-5 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
        <div>
          <div class="font-extrabold text-slate-900 flex items-center gap-2">
            <span class="w-9 h-9 rounded-2xl bg-indigo-600 text-white inline-flex items-center justify-center">
              <i class="fa-solid fa-chart-line"></i>
            </span>
            Tren Pendapatan (14 Hari)
          </div>
          <div class="text-xs text-slate-500 mt-1">Rentang: <b class="text-slate-700">{{ $trendRangeText }}</b></div>
        </div>
        <a href="{{ route('admin.report.index') }}"
           class="text-xs font-extrabold text-indigo-600 hover:text-indigo-800 inline-flex items-center gap-2">
          Lihat laporan
          <i class="fa-solid fa-arrow-right"></i>
        </a>
      </div>

      <div class="p-5">
        <div class="w-full" style="height: 280px;">
          <canvas id="dashTrend" class="w-full h-full"></canvas>
        </div>
        <div id="dashTrendEmpty" class="hidden mt-3 text-sm text-slate-500">
          Belum ada data untuk grafik pada rentang ini.
        </div>
        <div class="mt-2 text-[11px] text-slate-500">
          Grafik dihitung dari pembayaran APPROVED berdasarkan verified_at.
        </div>
      </div>
    </div>

    {{-- Top layanan --}}
    <div class="xl:col-span-4 {{ $card }} overflow-hidden">
      <div class="px-5 py-4 bg-slate-50 border-b border-slate-200">
        <div class="font-extrabold text-slate-900 flex items-center gap-2">
          <span class="w-9 h-9 rounded-2xl bg-slate-900 text-white inline-flex items-center justify-center">
            <i class="fa-solid fa-trophy"></i>
          </span>
          Top Layanan (30 Hari)
        </div>
        <div class="text-xs text-slate-500 mt-1">Yang paling menghasilkan (quick insight).</div>
      </div>

      <div class="p-5 space-y-3">
        @php
          $topMax = 0;
          if (!empty($topServices) && count($topServices) > 0) {
            $topMax = (float)($topServices[0]->total ?? 0);
            if ($topMax <= 0) $topMax = 1;
          } else {
            $topMax = 1;
          }
        @endphp

        @forelse($topServices as $t)
          @php
            $total = (float)($t->total ?? 0);
            $pct = min(100, ($total / $topMax) * 100);
          @endphp
          <div class="rounded-2xl border border-slate-200 p-4 hover:bg-slate-50 transition">
            <div class="flex items-start justify-between gap-3">
              <div class="min-w-0">
                <div class="font-extrabold text-slate-900 truncate">{{ $t->service_name ?? '—' }}</div>
                <div class="text-xs text-slate-500 mt-1">{{ (int)($t->tx_count ?? 0) }} transaksi</div>
              </div>
              <div class="text-right">
                <div class="text-sm font-extrabold text-slate-900">{{ $money($total) }}</div>
                <div class="text-[11px] text-slate-500">ID: {{ $t->service_id ?? '-' }}</div>
              </div>
            </div>
            <div class="mt-3 h-2 rounded-full bg-slate-100 overflow-hidden">
              <div class="h-2 bg-indigo-600" style="width: {{ $pct }}%"></div>
            </div>
          </div>
        @empty
          <div class="rounded-2xl border border-slate-200 p-6 text-center text-slate-500">
            <i class="fa-regular fa-folder-open text-2xl"></i>
            <div class="mt-2 font-bold text-slate-700">Belum ada data</div>
            <div class="text-sm mt-1">Top layanan akan muncul setelah ada pembayaran APPROVED.</div>
          </div>
        @endforelse
      </div>
    </div>
  </div>

  {{-- Operational Lists --}}
  <div class="grid grid-cols-1 xl:grid-cols-12 gap-4">
    {{-- Pesanan terbaru --}}
    <div class="xl:col-span-7 {{ $card }} overflow-hidden">
      <div class="px-5 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
        <div class="font-extrabold text-slate-900 flex items-center gap-2">
          <span class="w-9 h-9 rounded-2xl bg-indigo-600 text-white inline-flex items-center justify-center">
            <i class="fa-solid fa-file-invoice"></i>
          </span>
          Pesanan Terbaru
        </div>
        <a href="{{ route('admin.orders.index') }}" class="text-xs font-extrabold text-indigo-600 hover:text-indigo-800">
          Lihat semua
        </a>
      </div>

      <div class="divide-y divide-slate-100">
        @forelse($recentOrders as $o)
          @php
            [$stLabel, $stClass, $stIcon] = $statusMeta($o->status ?? null);
            $orderCode = $o->order_code ?? '-';
            $custName  = optional($o->customer)->name ?? '-';
            $svcName   = optional($o->service)->name ?? '-';
            $total     = (float)($o->total_price ?? 0);
          @endphp

          <a href="{{ route('admin.orders.show', $o) }}" class="block p-5 hover:bg-slate-50 transition">
            <div class="flex items-start justify-between gap-3">
              <div class="min-w-0">
                <div class="flex items-center gap-2">
                  <div class="font-extrabold text-slate-900 truncate">{{ $orderCode }}</div>
                  <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold border {{ $stClass }}">
                    <i class="{{ $stIcon }}"></i>
                    {{ $stLabel }}
                  </span>
                </div>

                <div class="text-xs text-slate-500 mt-1 truncate">
                  {{ $custName }} • {{ $svcName }}
                </div>

                <div class="mt-2 text-sm font-extrabold text-slate-900">
                  {{ $money($total) }}
                </div>
              </div>

              <div class="text-right whitespace-nowrap">
                <div class="text-xs text-slate-500">Dibuat</div>
                <div class="text-sm font-extrabold text-slate-900">{{ $fmtDate($o->created_at) }}</div>
                <div class="text-[11px] text-slate-500">{{ $fmtTime($o->created_at) }}</div>
              </div>
            </div>
          </a>
        @empty
          <div class="p-10 text-center text-slate-500">
            <i class="fa-regular fa-folder-open text-3xl"></i>
            <div class="mt-2 font-bold text-slate-700">Belum ada pesanan</div>
            <div class="text-sm mt-1">Order terbaru akan muncul di sini.</div>
          </div>
        @endforelse
      </div>
    </div>

    {{-- Pembayaran pending --}}
    <div class="xl:col-span-5 {{ $card }} overflow-hidden">
      <div class="px-5 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
        <div class="font-extrabold text-slate-900 flex items-center gap-2">
          <span class="w-9 h-9 rounded-2xl bg-slate-900 text-white inline-flex items-center justify-center">
            <i class="fa-solid fa-money-check-dollar"></i>
          </span>
          Pembayaran Pending
        </div>
        <a href="{{ route('admin.verify.index') }}" class="text-xs font-extrabold text-indigo-600 hover:text-indigo-800">
          Buka verifikasi
        </a>
      </div>

      <div class="divide-y divide-slate-100">
        @forelse($pendingPayments as $p)
          @php
            $o = $p->order ?? null;
            $orderCode = optional($o)->order_code ?? '-';
            $custName  = optional(optional($o)->customer)->name ?? '-';
            $svcName   = optional(optional($o)->service)->name ?? '-';
            $amount    = (float)($p->amount ?? optional($o)->total_price ?? 0);
            $method    = strtoupper((string)($p->method ?? '-'));
          @endphp

          <div class="p-5">
            <div class="flex items-start justify-between gap-3">
              <div class="min-w-0">
                <div class="font-extrabold text-slate-900 truncate">{{ $orderCode }}</div>
                <div class="text-xs text-slate-500 mt-1 truncate">{{ $custName }} • {{ $svcName }}</div>

                <div class="mt-2 flex flex-wrap items-center gap-2">
                  <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold border border-violet-200 bg-violet-50 text-violet-700">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    PENDING
                  </span>
                  <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold border border-slate-200 bg-slate-50 text-slate-700">
                    <i class="fa-solid fa-credit-card text-slate-500"></i>
                    {{ $method }}
                  </span>
                </div>
              </div>

              <div class="text-right whitespace-nowrap">
                <div class="text-sm font-extrabold text-slate-900">{{ $money($amount) }}</div>
                <div class="text-[11px] text-slate-500 mt-1">{{ $fmtDate($p->created_at) }}</div>
                <div class="text-[11px] text-slate-500">{{ $fmtTime($p->created_at) }}</div>
              </div>
            </div>
          </div>
        @empty
          <div class="p-10 text-center text-slate-500">
            <i class="fa-regular fa-face-smile-beam text-3xl"></i>
            <div class="mt-2 font-bold text-slate-700">Tidak ada pending 🎉</div>
            <div class="text-sm mt-1">Bagus. Admin bisa fokus ke produksi.</div>
          </div>
        @endforelse
      </div>
    </div>
  </div>

</div>
@endsection

@push('scripts')
<script>
  (function () {
    const canvas = document.getElementById('dashTrend');
    if (!canvas) return;

    const labels = @json($trendLabels ?? []);
    const values = @json($trendTotals ?? []);
    const emptyEl = document.getElementById('dashTrendEmpty');

    function formatRp(n) {
      try { return new Intl.NumberFormat('id-ID').format(n || 0); }
      catch { return String(n || 0); }
    }

    function draw() {
      const parent = canvas.parentElement;
      const w = Math.max(360, parent.clientWidth || 900);
      const h = Math.max(240, parent.clientHeight || 280);
      const dpr = window.devicePixelRatio || 1;

      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';

      const ctx = canvas.getContext('2d');
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);

      const max = Math.max(...values, 0);
      const hasData = max > 0;

      if (!hasData) {
        if (emptyEl) emptyEl.classList.remove('hidden');
        ctx.fillStyle = '#64748b';
        ctx.font = '14px system-ui, -apple-system, Segoe UI, Roboto';
        ctx.fillText('Belum ada data untuk grafik pada rentang ini.', 16, 40);
        return;
      }
      if (emptyEl) emptyEl.classList.add('hidden');

      const padL = 64, padR = 18, padT = 18, padB = 38;
      const plotW = w - padL - padR;
      const plotH = h - padT - padB;

      // Grid
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 1;
      for (let i = 0; i <= 4; i++) {
        const y = padT + (plotH * i / 4);
        ctx.beginPath();
        ctx.moveTo(padL, y);
        ctx.lineTo(w - padR, y);
        ctx.stroke();
      }

      // Y labels
      ctx.fillStyle = '#64748b';
      ctx.font = '12px system-ui, -apple-system, Segoe UI, Roboto';
      for (let i = 0; i <= 4; i++) {
        const v = Math.round(max * (1 - i / 4));
        const y = padT + (plotH * i / 4);
        ctx.fillText('Rp ' + formatRp(v), 10, y + 4);
      }

      const n = Math.max(values.length, 1);
      const stepX = plotW / Math.max(n - 1, 1);

      function xy(i, v) {
        const x = padL + (i * stepX);
        const y = padT + plotH - (v / max) * plotH;
        return [x, y];
      }

      // Area
      ctx.beginPath();
      for (let i = 0; i < values.length; i++) {
        const [x, y] = xy(i, values[i] || 0);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.lineTo(padL + (values.length - 1) * stepX, padT + plotH);
      ctx.lineTo(padL, padT + plotH);
      ctx.closePath();
      ctx.fillStyle = 'rgba(79, 70, 229, 0.08)';
      ctx.fill();

      // Line
      ctx.strokeStyle = '#4f46e5';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 0; i < values.length; i++) {
        const [x, y] = xy(i, values[i] || 0);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Points (sparse)
      ctx.fillStyle = '#4f46e5';
      for (let i = 0; i < values.length; i++) {
        if (i % 3 !== 0 && i !== values.length - 1) continue;
        const [x, y] = xy(i, values[i] || 0);
        ctx.beginPath();
        ctx.arc(x, y, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      // X labels
      ctx.fillStyle = '#64748b';
      ctx.font = '11px system-ui, -apple-system, Segoe UI, Roboto';
      for (let i = 0; i < labels.length; i++) {
        if (i % 3 !== 0 && i !== labels.length - 1) continue;
        const x = padL + (i * stepX);
        ctx.fillText(labels[i], x - 12, h - 14);
      }
    }

    draw();
    window.addEventListener('resize', () => draw());
  })();
</script>
@endpush
