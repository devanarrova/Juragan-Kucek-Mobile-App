@extends('admin.layouts.app')

@section('title','Data Pesanan')

@section('content')
@php
  $hasStatus = request()->filled('status');
  $hasSearch = request()->filled('search');

  /**
   * Helper kecil khusus view untuk badge pembayaran.
   * Null-safe (kalau payment belum ada).
   */
  $paymentUi = function ($payment) {
    $status = $payment?->status;
    $note   = $payment?->admin_note;

    $badgeClass = match($status) {
      'PENDING'  => 'bg-amber-50 text-amber-700 border-amber-200',
      'APPROVED' => 'bg-emerald-50 text-emerald-700 border-emerald-200',
      'REJECTED' => 'bg-red-50 text-red-700 border-red-200',
      null       => 'bg-slate-50 text-slate-600 border-slate-200',
      default    => 'bg-slate-50 text-slate-600 border-slate-200'
    };

    $icon = match($status) {
      'PENDING'  => 'fa-regular fa-clock',
      'APPROVED' => 'fa-solid fa-circle-check',
      'REJECTED' => 'fa-solid fa-circle-xmark',
      null       => 'fa-regular fa-circle-question',
      default    => 'fa-regular fa-circle-question'
    };

    $label = $status ?? 'BELUM ADA';

    $title = null;
    if ($status === 'REJECTED' && $note) {
      $title = 'Alasan: ' . mb_strimwidth($note, 0, 140, '...');
    }

    return compact('badgeClass','icon','label','title');
  };
@endphp

<div class="space-y-4">

  {{-- Alerts --}}
  @if(session('err'))
    <div class="rounded-2xl border border-red-200 bg-red-50 p-4 text-red-800 shadow-sm">
      <i class="fa-solid fa-triangle-exclamation"></i>
      <span class="ml-2">{{ session('err') }}</span>
    </div>
  @endif

  @if($errors->any())
    <div class="rounded-2xl border border-red-200 bg-red-50 p-4 text-red-800 shadow-sm">
      <div class="font-semibold mb-2">
        <i class="fa-solid fa-triangle-exclamation"></i>
        <span class="ml-2">Terjadi kesalahan</span>
      </div>
      <ul class="list-disc pl-5 text-sm space-y-1">
        @foreach($errors->all() as $e)
          <li>{{ $e }}</li>
        @endforeach
      </ul>
    </div>
  @endif

  {{-- Header --}}
  <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-3">
    <div>
      <h2 class="text-2xl font-bold text-slate-900">Data Pesanan</h2>
      <p class="text-sm text-slate-500 mt-1">Kelola pesanan: status, pembayaran, detail, dan cetak nota.</p>
    </div>

    <div class="flex items-center gap-2">
      <span class="inline-flex items-center gap-2 px-3 py-2 rounded-2xl bg-white border border-slate-200 text-sm text-slate-600 shadow-sm">
        <i class="fa-solid fa-list-check text-slate-500"></i>
        Total: <b class="text-slate-800">{{ $orders->total() }}</b>
      </span>
    </div>
  </div>

  {{-- P9: Quick lookup (input manual + scan QR optional) --}}
  <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
      <div>
        <div class="font-bold text-slate-900">Scan / Cari Order (Akses Cepat)</div>
        <div class="text-xs text-slate-500 mt-0.5">Tempel <b>order code</b> atau hasil scan QR dari nota/kwitansi untuk langsung masuk detail.</div>
      </div>

      <form id="lookupForm" method="GET" action="{{ route('admin.orders.lookup') }}" class="w-full md:w-auto flex flex-col sm:flex-row gap-2">
        <div class="relative flex-1 sm:w-[340px]">
          <i class="fa-solid fa-qrcode absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
          <input
            id="orderCodeInput"
            name="code"
            value="{{ old('code') }}"
            placeholder="Contoh: JK-2026-000123 / JK_ORDER:JK-2026-000123"
            class="w-full rounded-xl border border-slate-200 pl-10 pr-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200"
            autocomplete="off"
          />
        </div>

        <button class="px-4 py-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.99] transition inline-flex items-center justify-center gap-2">
          <i class="fa-solid fa-magnifying-glass"></i> Cari
        </button>

        <button type="button" id="openScanModal"
                class="px-4 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 active:scale-[0.99] transition inline-flex items-center justify-center gap-2">
          <i class="fa-solid fa-camera text-slate-600"></i> Scan QR
        </button>
      </form>
    </div>
  </div>

  {{-- Filter --}}
  <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
    <form class="grid grid-cols-1 md:grid-cols-12 gap-3">
      <div class="md:col-span-5 relative">
        <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
        <input
          name="search"
          value="{{ request('search') }}"
          placeholder="Cari kode order / username..."
          class="w-full rounded-xl border border-slate-200 pl-10 pr-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200"
        />
      </div>

      <div class="md:col-span-4 relative">
        <i class="fa-solid fa-filter absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
        <select
          name="status"
          class="w-full rounded-xl border border-slate-200 pl-10 pr-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200"
        >
          <option value="">Semua Status</option>
          @foreach($statuses as $st)
            <option value="{{ $st }}" @selected(request('status')===$st)>{{ status_label($st) }}</option>
          @endforeach
        </select>
      </div>

      <div class="md:col-span-3 flex gap-2">
        <button class="flex-1 px-4 py-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.99] transition inline-flex items-center justify-center gap-2">
          <i class="fa-solid fa-filter"></i> Terapkan
        </button>

        <a href="{{ route('admin.orders.index') }}"
           class="px-4 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 active:scale-[0.99] transition inline-flex items-center justify-center"
           title="Reset">
          <i class="fa-solid fa-rotate-left text-slate-500"></i>
        </a>
      </div>
    </form>

    {{-- Chips filter aktif --}}
    @if($hasStatus || $hasSearch)
      <div class="mt-3 flex flex-wrap items-center gap-2">
        <span class="text-xs text-slate-500">Filter aktif:</span>

        @if($hasStatus)
          <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-slate-50 text-slate-700">
            <i class="fa-solid fa-tag text-slate-500"></i>
            Status: {{ status_label(request('status')) }}
            <a class="ml-1 text-slate-500 hover:text-slate-700"
               href="{{ route('admin.orders.index', array_filter(['search'=>request('search')])) }}"
               title="Hapus status">
              <i class="fa-solid fa-xmark"></i>
            </a>
          </span>
        @endif

        @if($hasSearch)
          <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-slate-200 bg-slate-50 text-slate-700">
            <i class="fa-solid fa-magnifying-glass text-slate-500"></i>
            Search: "{{ request('search') }}"
            <a class="ml-1 text-slate-500 hover:text-slate-700"
               href="{{ route('admin.orders.index', array_filter(['status'=>request('status')])) }}"
               title="Hapus search">
              <i class="fa-solid fa-xmark"></i>
            </a>
          </span>
        @endif

        <a href="{{ route('admin.orders.index') }}"
           class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 active:scale-[0.99] transition">
          <i class="fa-solid fa-trash-can"></i>
          Reset semua
        </a>
      </div>
    @endif
  </div>

  {{-- Mobile cards --}}
  <div class="grid grid-cols-1 gap-3 md:hidden">
    @forelse($orders as $o)
      @php
        $pay = $o->payment;
        $pui = $paymentUi($pay);

        $canDelete = ($o->status === 'MENUNGGU_KONFIRMASI') && ($o->payment === null);

        $canPrintNota = ($o->status === 'MENUNGGU_KONFIRMASI');
        $canPrintKwitansi = in_array($o->status, ['DIANTAR','SELESAI'], true) && ($o->payment?->status === 'APPROVED');
      @endphp

      <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm hover:bg-slate-50 transition">
        <div class="flex items-start justify-between gap-3">
          <a href="{{ route('admin.orders.show',$o) }}" class="min-w-0 flex-1 active:scale-[0.99] transition">
            <div class="font-bold text-slate-900 truncate">{{ $o->order_code }}</div>

            <div class="text-xs text-slate-500 mt-1 flex flex-wrap items-center gap-2">
              <span class="inline-flex items-center gap-1">
                <i class="fa-regular fa-user"></i>
                {{ $o->customer->username ?? '-' }}
              </span>
              <span class="text-slate-300">•</span>
              <span class="inline-flex items-center gap-1">
                <i class="fa-regular fa-calendar"></i>
                {{ $o->pickup_date ? tgl_id($o->pickup_date) : '-' }}
              </span>
            </div>

            <div class="text-xs text-slate-500 mt-1 inline-flex items-center gap-2">
              <i class="fa-solid fa-broom"></i>
              <span class="truncate">{{ $o->service->name ?? '-' }}</span>
            </div>

            {{-- Badge pembayaran --}}
            <div class="mt-2 flex flex-wrap gap-2">
              <span
                class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border {{ $pui['badgeClass'] }}"
                @if($pui['title']) title="{{ $pui['title'] }}" @endif
              >
                <i class="{{ $pui['icon'] }}"></i>
                Pembayaran: {{ $pui['label'] }}
              </span>
            </div>
          </a>

          <div class="flex flex-col items-end gap-2">
            <span class="shrink-0 px-3 py-1 rounded-full text-xs font-semibold inline-flex items-center gap-2 {{ status_badge_class($o->status) }}">
              <i class="{{ status_icon($o->status) }}"></i>
              {{ status_label($o->status) }}
            </span>

            <div class="flex items-center gap-2">
              @php $unread = (int) ($o->unread_messages_count ?? 0); @endphp
              <a href="{{ route('admin.orders.show',$o) }}#chat"
                 class="relative inline-flex items-center justify-center w-9 h-9 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.99] transition"
                 title="Chat">
                <i class="fa-solid fa-message text-slate-700"></i>
                @if($unread > 0)
                  <span class="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-red-600 text-white text-[10px] font-bold flex items-center justify-center border-2 border-white">
                    {{ $unread > 9 ? '9+' : $unread }}
                  </span>
                @endif
              </a>

              @if($canPrintNota)
                <a target="_blank"
                   href="{{ route('admin.orders.print.nota', $o) }}"
                   class="inline-flex items-center justify-center w-9 h-9 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.99] transition"
                   title="Cetak Nota Operasional">
                  <i class="fa-solid fa-print text-slate-700"></i>
                </a>
              @endif

              @if($canPrintKwitansi)
                <a target="_blank"
                   href="{{ route('admin.orders.print.kwitansi', $o) }}"
                   class="inline-flex items-center justify-center w-9 h-9 rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 active:scale-[0.99] transition"
                   title="Cetak Kwitansi Lunas">
                  <i class="fa-solid fa-receipt text-emerald-700"></i>
                </a>
              @endif

              @if($canDelete)
                <form method="POST" action="{{ route('admin.orders.destroy', $o) }}"
                      onsubmit="return confirm('Yakin hapus pesanan {{ $o->order_code }}? Tindakan ini tidak bisa dibatalkan.');">
                  @csrf
                  @method('DELETE')
                  <button type="submit"
                          class="inline-flex items-center justify-center w-9 h-9 rounded-xl border border-red-200 bg-red-50 text-red-600 hover:bg-red-100 active:scale-[0.99] transition"
                          title="Hapus">
                    <i class="fa-solid fa-trash"></i>
                  </button>
                </form>
              @endif
            </div>
          </div>
        </div>
      </div>
    @empty
      <div class="bg-white rounded-2xl border border-slate-200 p-10 text-center text-slate-500 shadow-sm">
        <i class="fa-regular fa-folder-open text-3xl"></i>
        <div class="mt-2 font-semibold text-slate-700">Belum ada pesanan</div>
        <div class="text-sm mt-1">Coba reset filter atau tunggu pesanan baru.</div>
      </div>
    @endforelse
  </div>

  {{-- Desktop table --}}
  <div class="hidden md:block bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="bg-slate-50 text-slate-600">
          <tr>
            <th class="text-left px-4 py-3">Order</th>
            <th class="text-left px-4 py-3">Customer</th>
            <th class="text-left px-4 py-3">Layanan</th>
            <th class="text-left px-4 py-3">Jemput</th>
            <th class="text-left px-4 py-3">Pembayaran</th>
            <th class="text-left px-4 py-3">Status</th>
            <th class="text-right px-4 py-3">Aksi</th>
          </tr>
        </thead>

        <tbody class="divide-y divide-slate-100">
          @forelse($orders as $o)
            @php
              $pay = $o->payment;
              $pui = $paymentUi($pay);

              $canDelete = ($o->status === 'MENUNGGU_KONFIRMASI') && ($o->payment === null);

              $canPrintNota = ($o->status === 'MENUNGGU_KONFIRMASI');
              $canPrintKwitansi = in_array($o->status, ['DIANTAR','SELESAI'], true) && ($o->payment?->status === 'APPROVED');
            @endphp

            <tr class="hover:bg-slate-50 transition">
              <td class="px-4 py-3">
                <div class="font-semibold text-slate-900">{{ $o->order_code }}</div>
                <div class="text-xs text-slate-500">ID: {{ $o->id }}</div>
              </td>

              <td class="px-4 py-3">
                <div class="font-medium text-slate-800">{{ $o->customer->username ?? '-' }}</div>
                <div class="text-xs text-slate-500">{{ $o->customer->name ?? '' }}</div>
              </td>

              <td class="px-4 py-3">
                <div class="font-medium text-slate-800">{{ $o->service->name ?? '-' }}</div>
                <div class="text-xs text-slate-500">Estimasi: {{ $o->estimated_qty ?? '-' }}</div>
              </td>

              <td class="px-4 py-3 text-slate-700">
                <div class="inline-flex items-center gap-2">
                  <i class="fa-regular fa-calendar text-slate-400"></i>
                  <span>{{ $o->pickup_date ? tgl_id($o->pickup_date) : '-' }}</span>
                </div>
              </td>

              <td class="px-4 py-3">
                <span
                  class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border {{ $pui['badgeClass'] }}"
                  @if($pui['title']) title="{{ $pui['title'] }}" @endif
                >
                  <i class="{{ $pui['icon'] }}"></i>
                  {{ $pui['label'] }}
                </span>
              </td>

              <td class="px-4 py-3">
                <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold {{ status_badge_class($o->status) }}">
                  <i class="{{ status_icon($o->status) }}"></i>
                  {{ status_label($o->status) }}
                </span>
              </td>

              <td class="px-4 py-3 text-right">
                <div class="inline-flex items-center gap-2 justify-end">
                  <a class="inline-flex items-center gap-2 px-3 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 active:scale-[0.99] transition"
                     href="{{ route('admin.orders.show',$o) }}">
                    Detail <i class="fa-solid fa-arrow-right text-xs text-slate-500"></i>
                  </a>

                  @php $unread = (int) ($o->unread_messages_count ?? 0); @endphp
                  <a href="{{ route('admin.orders.show',$o) }}#chat"
                     class="relative inline-flex items-center justify-center w-10 h-10 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.99] transition"
                     title="Chat">
                    <i class="fa-solid fa-message text-slate-700"></i>
                    @if($unread > 0)
                      <span class="absolute -top-1 -right-1 min-w-[20px] h-[20px] px-1 rounded-full bg-red-600 text-white text-[10px] font-bold flex items-center justify-center border-2 border-white">
                        {{ $unread > 99 ? '99+' : ($unread > 9 ? '9+' : $unread) }}
                      </span>
                    @endif
                  </a>

                  @if($canPrintNota)
                    <a target="_blank"
                       class="inline-flex items-center justify-center w-10 h-10 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.99] transition"
                       href="{{ route('admin.orders.print.nota', $o) }}"
                       title="Cetak Nota Operasional">
                      <i class="fa-solid fa-print text-slate-700"></i>
                    </a>
                  @endif

                  @if($canPrintKwitansi)
                    <a target="_blank"
                       class="inline-flex items-center justify-center w-10 h-10 rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 active:scale-[0.99] transition"
                       href="{{ route('admin.orders.print.kwitansi', $o) }}"
                       title="Cetak Kwitansi Lunas">
                      <i class="fa-solid fa-receipt text-emerald-700"></i>
                    </a>
                  @endif

                  @if($canDelete)
                    <form method="POST" action="{{ route('admin.orders.destroy', $o) }}"
                          onsubmit="return confirm('Yakin hapus pesanan {{ $o->order_code }}? Tindakan ini tidak bisa dibatalkan.');">
                      @csrf
                      @method('DELETE')
                      <button type="submit"
                              class="inline-flex items-center justify-center w-10 h-10 rounded-xl border border-red-200 bg-red-50 text-red-600 hover:bg-red-100 active:scale-[0.99] transition"
                              title="Hapus">
                        <i class="fa-solid fa-trash"></i>
                      </button>
                    </form>
                  @endif
                </div>
              </td>
            </tr>
          @empty
            <tr>
              <td colspan="7" class="px-4 py-10">
                <div class="bg-white rounded-2xl border border-slate-200 p-10 text-center text-slate-500 shadow-sm">
                  <i class="fa-regular fa-folder-open text-3xl"></i>
                  <div class="mt-2 font-semibold text-slate-700">Belum ada pesanan</div>
                  <div class="text-sm mt-1">Coba ubah filter atau tunggu pesanan baru.</div>
                </div>
              </td>
            </tr>
          @endforelse
        </tbody>
      </table>
    </div>
  </div>

  <div class="pt-2">
    {{ $orders->links() }}
  </div>

</div>
@endsection

@push('modals')
  {{-- Modal: Scan QR (optional) --}}
  <div id="qrModal" class="fixed inset-0 z-[999999] hidden">
    <div class="absolute inset-0 bg-black/50" data-close></div>

    <div class="relative mx-auto mt-16 w-[92vw] max-w-lg">
      <div class="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
        <div class="p-4 border-b border-slate-100 flex items-center justify-between">
          <div class="font-bold text-slate-900 inline-flex items-center gap-2">
            <i class="fa-solid fa-qrcode text-slate-600"></i>
            Scan QR Nota / Kwitansi
          </div>
          <button type="button" id="closeQrModal" class="w-10 h-10 rounded-xl hover:bg-slate-100 inline-flex items-center justify-center text-slate-600">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </div>

        <div class="p-4 space-y-3">
          <div id="qrReader" class="rounded-xl overflow-hidden border border-slate-200 bg-slate-50"></div>

          <div id="qrError" class="hidden rounded-xl border border-red-200 bg-red-50 p-3 text-xs text-red-700"></div>
          <div class="text-xs text-slate-500">
            Tips: kalau kamera laptop dosen bermasalah, pakai input manual di atas (tetap valid buat demo).
          </div>

          <div class="flex justify-end">
            <button type="button" id="stopScan"
              class="px-4 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 active:scale-[0.99] transition inline-flex items-center gap-2">
              <i class="fa-solid fa-circle-stop text-slate-600"></i> Tutup
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
@endpush

@push('scripts')
  {{-- html5-qrcode via CDN (opsional). Kalau offline, download & taruh di public lalu ganti src. --}}
  <script src="https://unpkg.com/html5-qrcode@2.3.10/html5-qrcode.min.js"></script>
  <script>
    (function () {
      const modal    = document.getElementById('qrModal');
      const openBtn  = document.getElementById('openScanModal');
      const closeBtn = document.getElementById('closeQrModal');
      const stopBtn  = document.getElementById('stopScan');
      const overlay  = modal ? modal.querySelector('[data-close]') : null;

      const input = document.getElementById('orderCodeInput');
      const form  = document.getElementById('lookupForm');
      const errEl = document.getElementById('qrError');

      let qr = null;

      function showErr(msg) {
        if (!errEl) return;
        errEl.textContent = msg;
        errEl.classList.remove('hidden');
      }

      function clearErr() {
        if (!errEl) return;
        errEl.textContent = '';
        errEl.classList.add('hidden');
      }

      async function openModal() {
        if (!modal) return;
        clearErr();
        modal.classList.remove('hidden');
        document.body.classList.add('modal-open');

        if (typeof Html5Qrcode === 'undefined') {
          showErr('Library scanner belum termuat. Pakai input manual aja.');
          return;
        }

        try {
          qr = new Html5Qrcode('qrReader');
          const devices = await Html5Qrcode.getCameras();
          if (!devices || devices.length === 0) {
            showErr('Kamera tidak ditemukan. Pakai input manual.');
            return;
          }

          await qr.start(
            { facingMode: 'environment' },
            { fps: 10, qrbox: { width: 220, height: 220 } },
            (decodedText) => {
              if (input) input.value = decodedText;
              closeModal(true);
            }
          );
        } catch (e) {
          showErr('Gagal akses kamera: ' + (e && e.message ? e.message : e));
        }
      }

      async function closeModal(autoSubmit) {
        if (!modal) return;

        if (qr) {
          try { await qr.stop(); } catch (_) {}
          try { qr.clear(); } catch (_) {}
          qr = null;
        }

        modal.classList.add('hidden');
        document.body.classList.remove('modal-open');

        if (autoSubmit && form) {
          form.submit();
        }
      }

      openBtn && openBtn.addEventListener('click', openModal);
      closeBtn && closeBtn.addEventListener('click', () => closeModal(false));
      stopBtn && stopBtn.addEventListener('click', () => closeModal(false));
      overlay && overlay.addEventListener('click', () => closeModal(false));

      window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal && !modal.classList.contains('hidden')) {
          closeModal(false);
        }
      });
    })();
  </script>
@endpush
