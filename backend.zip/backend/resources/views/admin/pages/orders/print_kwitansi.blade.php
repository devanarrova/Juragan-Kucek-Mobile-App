<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Kwitansi Lunas - {{ $order->order_code }}</title>
  <style>
    * { box-sizing: border-box; }
    body { font-family: Arial, Helvetica, sans-serif; color:#0f172a; }
    .wrap { max-width: 820px; margin: 0 auto; padding: 18px; }
    .top { display:flex; align-items:center; justify-content:space-between; gap:16px; }
    .brand { display:flex; align-items:center; gap:12px; }
    .logo { width:44px; height:44px; border-radius:12px; border:1px solid #e2e8f0; background:#fff; display:flex; align-items:center; justify-content:center; overflow:hidden; }
    .logo img { width:100%; height:100%; object-fit:contain; padding:6px; }
    .muted { color:#64748b; font-size:12px; }
    .title { font-size:18px; font-weight:800; margin:0; }
    .badgePaid { display:inline-flex; align-items:center; padding:6px 10px; border-radius:999px; border:1px solid #bbf7d0; font-size:12px; font-weight:900; background:#ecfdf5; color:#047857; }
    .grid { display:grid; grid-template-columns: 1fr 1fr; gap:12px; margin-top:14px; }
    .card { border:1px solid #e2e8f0; border-radius:14px; padding:12px; }
    .row { display:flex; justify-content:space-between; gap:12px; font-size:13px; margin:6px 0; }
    .row b { color:#0f172a; }
    .total { margin-top:10px; border-top:1px dashed #cbd5e1; padding-top:10px; display:flex; justify-content:space-between; align-items:center; }
    .total .label { font-weight:900; color:#0f172a; }
    .total .value { font-weight:900; font-size:18px; }
    .actions { margin-top:14px; display:flex; gap:10px; }
    .btn { border:1px solid #e2e8f0; padding:10px 12px; border-radius:12px; background:#fff; cursor:pointer; font-weight:700; }
    .btnPrimary { border-color:#1F717C; background:#1F717C; color:#fff; }
    .qrBox svg { display:block; width:100%; height:auto; }
    @media print {
      .actions { display:none !important; }
      @page { margin: 12mm; }
    }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="top">
      <div class="brand">
        <div class="logo">
          <img src="{{ asset('assets/img/logo-juragan-kucek.png') }}" alt="logo" onerror="this.style.display='none'">
        </div>
        <div>
          <div class="muted" style="letter-spacing:.12em; text-transform:uppercase; font-weight:800;">Juragan Kucek</div>
          <h1 class="title">KWITANSI LUNAS</h1>
          <div class="muted">Dicetak: {{ tgl_id($printedAt, 'd M Y') }} • {{ $printedAt->format('H:i') }}</div>
        </div>
      </div>
	      <div style="display:flex; align-items:flex-start; justify-content:flex-end; gap:12px;">
	        <div style="width:98px;">
	          @include('admin.components.print.qr', [
	            'value' => 'JK_PAID:' . ($order->order_code ?? ''),
	            'size' => 98,
	            'caption' => 'SCAN PAID'
	          ])
	        </div>
	        <div style="text-align:right">
	          <div class="badgePaid">LUNAS</div>
	          <div style="margin-top:8px; font-weight:900; font-size:16px;">{{ $order->order_code }}</div>
	          <div class="muted">Order ID: {{ $order->id }}</div>
	        </div>
	      </div>
    </div>

    <div class="grid">
      <div class="card">
        <div style="font-weight:800; margin-bottom:6px;">Customer</div>
        <div class="row"><span>Username</span><b>{{ $order->customer->username ?? '-' }}</b></div>
        <div class="row"><span>Nama</span><b>{{ $order->customer->name ?? '-' }}</b></div>
        <div class="row"><span>No HP</span><b>{{ $order->customer->phone ?? '-' }}</b></div>
      </div>

      <div class="card">
        <div style="font-weight:800; margin-bottom:6px;">Pembayaran</div>
        <div class="row"><span>Metode</span><b>{{ $payment->method ?? '-' }}</b></div>
        @if(!empty($payment->channel_code))
          <div class="row"><span>Channel</span><b>{{ $payment->channel_name ?? $payment->channel_code }}</b></div>
          <div class="row"><span>Tujuan</span><b>{{ $payment->destination_account }} a.n {{ $payment->destination_holder }}</b></div>
        @endif
        <div class="row"><span>Tgl Verifikasi</span><b>{{ $payment->verified_at ? tgl_id($payment->verified_at, 'd M Y') : '-' }} {{ $payment->verified_at ? $payment->verified_at->format('H:i') : '' }}</b></div>
        <div class="row"><span>Verifier</span><b>{{ optional($payment->verifiedByAdmin)->name ?? '-' }}</b></div>
      </div>
    </div>

    <div class="card" style="margin-top:12px;">
      <div style="font-weight:800; margin-bottom:6px;">Detail Transaksi</div>
      <div class="row"><span>Layanan</span><b>{{ $order->service->name ?? '-' }}</b></div>
      <div class="row"><span>Final Qty</span><b>{{ $order->final_qty ?? '-' }} {{ $order->service->unit_label ?? '' }}</b></div>
      <div class="row"><span>Harga / Unit</span><b>{{ rupiah($order->service->base_price ?? 0) }}</b></div>

      <div class="total">
        <div class="label">TOTAL DIBAYAR</div>
        <div class="value">{{ rupiah($order->total_price ?? $payment->amount ?? 0) }}</div>
      </div>

      <div style="margin-top:16px; display:flex; justify-content:space-between; gap:16px;">
        <div class="muted" style="max-width:420px;">
          Catatan: Kwitansi ini berlaku sebagai bukti pembayaran lunas untuk pesanan {{ $order->order_code }}.
        </div>
        <div style="text-align:center; min-width:220px;">
          <div class="muted">Tanda tangan</div>
          <div style="height:54px;"></div>
          <div style="border-top:1px solid #cbd5e1; padding-top:6px; font-weight:700;">Admin / Petugas</div>
        </div>
      </div>
    </div>

    <div class="actions">
      <button class="btn" onclick="history.back()">Kembali</button>
      <button class="btn btnPrimary" onclick="window.print()">Cetak</button>
    </div>
  </div>
</body>
</html>
