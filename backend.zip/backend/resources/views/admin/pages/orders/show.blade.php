@extends('admin.layouts.detail')

@section('title','Detail Pesanan')

@section('content')
@php
  $p = $order->payment;

  // sesuai services: base_price, pricing_type, unit_label
  $unitPrice   = (float) ($order->service->base_price ?? 0);
  $pricingType = $order->service->pricing_type ?? null; // per_kg / per_item
  $unitLabel   = $order->service->unit_label ?? 'unit';

  $pricingTypeLabel = $pricingType === 'per_kg'
      ? 'Per Kg'
      : ($pricingType === 'per_item' ? 'Per Item' : '-');

  // hanya editable pada status ini
  $canEditFinal = ($order->status === 'SELESAI_MENUNGGU_PEMBAYARAN');
  $canChangeStatus = isset($allowedStatuses) && is_array($allowedStatuses) && count($allowedStatuses) > 1;

  $histories = $order->statusHistories?->sortByDesc('created_at') ?? collect();

  // ✅ Print rules
  $canPrintNota = ($order->status === 'MENUNGGU_KONFIRMASI');
  $canPrintKwitansi = in_array($order->status, ['DIANTAR','SELESAI'], true) && ($order->payment?->status === 'APPROVED');
@endphp

{{-- Alerts --}}
@if(session('ok'))
  <div class="mb-4 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-emerald-800 shadow-sm">
    <i class="fa-solid fa-circle-check"></i>
    <span class="ml-2">{{ session('ok') }}</span>
  </div>
@endif

@if($errors->any())
  <div class="mb-4 rounded-2xl border border-red-200 bg-red-50 p-4 text-red-800 shadow-sm">
    <div class="font-semibold mb-2">
      <i class="fa-solid fa-triangle-exclamation"></i>
      <span class="ml-2">Terjadi kesalahan</span>
    </div>
    <ul class="list-disc pl-5 text-sm space-y-1">
      @foreach($errors->all() as $e)
        <li>{{ $e }}</li>
      @endforeach
    </ul>
  </div>
@endif

<div class="space-y-6">

  {{-- Header --}}
  <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
    <div class="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
      <div>
        <div class="flex items-center gap-3">
          <div class="h-11 w-11 rounded-2xl bg-indigo-600 text-white flex items-center justify-center">
            <i class="fa-solid fa-receipt"></i>
          </div>
          <div>
            <h3 class="text-xl md:text-2xl font-bold text-slate-900">Detail Pesanan</h3>
            <p class="text-sm text-slate-500 mt-0.5">
              <span class="font-semibold text-slate-800">{{ $order->order_code }}</span>
              <span class="mx-2 text-slate-300">•</span>
              ID: {{ $order->id }}
            </p>
          </div>
        </div>

        {{-- Chips ringkas --}}
        <div class="mt-4 flex flex-wrap gap-2">
          <span class="px-3 py-1 rounded-full text-xs bg-slate-100 text-slate-700 inline-flex items-center gap-2">
            <i class="fa-regular fa-user text-slate-500"></i>
            {{ $order->customer->username ?? '-' }}
          </span>

          <span class="px-3 py-1 rounded-full text-xs bg-slate-100 text-slate-700 inline-flex items-center gap-2">
            <i class="fa-solid fa-broom text-slate-500"></i>
            {{ $order->service->name ?? '-' }}
          </span>

          <span class="px-3 py-1 rounded-full text-xs bg-slate-100 text-slate-700 inline-flex items-center gap-2">
            <i class="fa-regular fa-calendar text-slate-500"></i>
            {{ $order->pickup_date ? tgl_id($order->pickup_date) : '-' }}
          </span>
        </div>

        {{-- Bonus pricing info --}}
        <div class="mt-3 text-xs text-slate-500 flex flex-wrap gap-2">
          <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-slate-200 bg-white">
            <i class="fa-solid fa-tags text-slate-400"></i>
            Tipe: <b class="text-slate-700">{{ $pricingTypeLabel }}</b>
          </span>
          <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-slate-200 bg-white">
            <i class="fa-solid fa-ruler text-slate-400"></i>
            Satuan: <b class="text-slate-700">{{ $unitLabel }}</b>
          </span>
          <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-slate-200 bg-white">
            <i class="fa-solid fa-money-bill-wave text-slate-400"></i>
            Harga: <b class="text-slate-700">{{ rupiah($unitPrice) }}</b> / {{ $unitLabel }}
          </span>
        </div>

        {{-- Quick actions --}}
        <div class="mt-3 flex flex-wrap gap-2">
          <button type="button" id="copyCode"
                  class="px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.99] transition text-xs font-semibold inline-flex items-center gap-2">
            <i class="fa-regular fa-copy text-slate-500"></i> Salin Kode
          </button>

          @if($canPrintNota)
            <a target="_blank"
               href="{{ route('admin.orders.print.nota', $order) }}"
               class="px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.99] transition text-xs font-semibold inline-flex items-center gap-2">
              <i class="fa-solid fa-print text-slate-500"></i> Cetak Nota
            </a>
          @endif

          @if($canPrintKwitansi)
            <a target="_blank"
               href="{{ route('admin.orders.print.kwitansi', $order) }}"
               class="px-3 py-2 rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 active:scale-[0.99] transition text-xs font-semibold inline-flex items-center gap-2">
              <i class="fa-solid fa-receipt"></i> Cetak Kwitansi
            </a>
          @endif

          <a href="#pembayaran"
             class="px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.99] transition text-xs font-semibold inline-flex items-center gap-2">
            <i class="fa-solid fa-money-check-dollar text-slate-500"></i> Pembayaran
          </a>
          <a href="#timeline"
             class="px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.99] transition text-xs font-semibold inline-flex items-center gap-2">
            <i class="fa-solid fa-timeline text-slate-500"></i> Timeline
          </a>
          <a href="#chat"
             class="px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.99] transition text-xs font-semibold inline-flex items-center gap-2">
            <i class="fa-solid fa-comments text-slate-500"></i> Chat
          </a>
        </div>
      </div>

      <div class="flex items-center gap-2">
        <span class="px-3 py-1 rounded-full text-xs font-semibold inline-flex items-center gap-2 {{ status_badge_class($order->status) }}">
          <i class="{{ status_icon($order->status) }}"></i>
          {{ status_label($order->status) }}
        </span>

        @if($canPrintNota)
          <a target="_blank"
             href="{{ route('admin.orders.print.nota', $order) }}"
             class="inline-flex items-center justify-center w-10 h-10 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.99] transition"
             title="Cetak Nota Operasional">
            <i class="fa-solid fa-print text-slate-700"></i>
          </a>
        @endif

        @if($canPrintKwitansi)
          <a target="_blank"
             href="{{ route('admin.orders.print.kwitansi', $order) }}"
             class="inline-flex items-center justify-center w-10 h-10 rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 active:scale-[0.99] transition"
             title="Cetak Kwitansi Lunas">
            <i class="fa-solid fa-receipt text-emerald-700"></i>
          </a>
        @endif
      </div>
    </div>
  </div>

  {{-- Summary Cards --}}
  <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    <div class="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
      <div class="flex items-start justify-between">
        <div>
          <p class="text-xs text-slate-500">Estimasi Qty</p>
          <p class="text-lg font-bold text-slate-900 mt-1">{{ $order->estimated_qty ?? '-' }}</p>
          <p class="text-xs text-slate-500 mt-1">Satuan: {{ $unitLabel }}</p>
        </div>
        <div class="h-10 w-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600">
          <i class="fa-solid fa-scale-balanced"></i>
        </div>
      </div>
    </div>

    <div class="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
      <div class="flex items-start justify-between">
        <div>
          <p class="text-xs text-slate-500">Final Qty</p>
          <p class="text-lg font-bold text-slate-900 mt-1">{{ $order->final_qty ?? '-' }}</p>
          <p class="text-xs text-slate-500 mt-1">Satuan: {{ $unitLabel }}</p>
        </div>
        <div class="h-10 w-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600">
          <i class="fa-solid fa-check-double"></i>
        </div>
      </div>
    </div>

    <div class="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
      <div class="flex items-start justify-between">
        <div>
          <p class="text-xs text-slate-500">Total Harga</p>
          <p class="text-lg font-bold text-slate-900 mt-1">
            {{ $order->total_price ? rupiah($order->total_price) : '-' }}
          </p>
          <p class="text-xs text-slate-500 mt-1">Otomatis dari Final Qty</p>
        </div>
        <div class="h-10 w-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600">
          <i class="fa-solid fa-money-bill-wave"></i>
        </div>
      </div>
    </div>
  </div>

  {{-- Customer & Address --}}
  <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
    <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
      <div class="flex items-center gap-2 mb-4">
        <i class="fa-regular fa-user text-slate-500"></i>
        <h6 class="font-bold text-slate-800">Customer</h6>
      </div>
      <div class="text-sm text-slate-700 space-y-2">
        <div class="flex justify-between gap-4">
          <span class="text-slate-500">Username</span>
          <span class="font-semibold text-slate-900">{{ $order->customer->username ?? '-' }}</span>
        </div>
        <div class="flex justify-between gap-4">
          <span class="text-slate-500">Nama</span>
          <span class="font-semibold text-slate-900">{{ $order->customer->name ?? '-' }}</span>
        </div>
      </div>
    </div>

    <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
      <div class="flex items-center gap-2 mb-4">
        <i class="fa-solid fa-basket-shopping text-slate-500"></i>
        <h6 class="font-bold text-slate-800">Layanan</h6>
      </div>
      <div class="text-sm text-slate-700 space-y-2">
        <div class="flex justify-between gap-4">
          <span class="text-slate-500">Nama</span>
          <span class="font-semibold text-slate-900">{{ $order->service->name ?? '-' }}</span>
        </div>
        <div class="flex justify-between gap-4">
          <span class="text-slate-500">Tipe</span>
          <span class="font-semibold text-slate-900">{{ $pricingTypeLabel }}</span>
        </div>
        <div class="flex justify-between gap-4">
          <span class="text-slate-500">Harga</span>
          <span class="font-semibold text-slate-900">{{ rupiah($unitPrice) }} / {{ $unitLabel }}</span>
        </div>
      </div>
    </div>

    <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm md:col-span-2">
      <div class="flex items-center gap-2 mb-4">
        <i class="fa-solid fa-location-dot text-slate-500"></i>
        <h6 class="font-bold text-slate-800">Alamat & Catatan</h6>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-slate-700">
        <div class="rounded-xl border border-slate-200 bg-slate-50 p-4">
          <div class="text-xs text-slate-500 mb-1">Alamat Jemput</div>
          <div class="font-medium">{{ $order->pickup_address ?? '-' }}</div>
        </div>
        <div class="rounded-xl border border-slate-200 bg-slate-50 p-4">
          <div class="text-xs text-slate-500 mb-1">Catatan</div>
          <div class="font-medium">{{ $order->notes ?? '-' }}</div>
        </div>
      </div>
    </div>
  </div>

  {{-- Update Proses --}}
  <div id="update-proses" class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
    <div class="flex items-start justify-between gap-3 mb-4">
      <div>
        <div class="flex items-center gap-2">
          <i class="fa-solid fa-pen-to-square text-slate-500"></i>
          <h6 class="font-bold text-slate-800">Update Proses</h6>
        </div>
        <p class="text-xs text-slate-500 mt-1">
          Final Qty & Total Harga hanya bisa diisi pada status <b>{{ status_label('SELESAI_MENUNGGU_PEMBAYARAN') }}</b>.
        </p>
      </div>
    </div>

    <form id="updateForm"
          data-unit-price="{{ $unitPrice }}"
          method="POST"
          action="{{ route('admin.orders.update', $order) }}"
          class="space-y-4">
      @csrf
      @method('PATCH')

      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label class="text-sm text-slate-600">Status</label>
          <select id="statusSelect" name="status" required
                  @disabled(!$canChangeStatus)
                  class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200">
            @foreach($allowedStatuses as $st)
              <option value="{{ $st }}" @selected($order->status===$st)>{{ status_label($st) }}</option>
            @endforeach
          </select>

          @if(!$canChangeStatus)
            <input type="hidden" name="status" value="{{ $order->status }}">
            <p class="text-xs text-slate-500 mt-2">Status ini tidak bisa diubah lewat dropdown. Perubahan terjadi otomatis (upload pembayaran) atau lewat tombol Approve/Reject.</p>
          @endif

          @if($order->status === 'SELESAI_MENUNGGU_PEMBAYARAN')
            <p class="text-xs text-amber-700 mt-2">Menunggu Verifikasi Pembayaran akan berubah otomatis ketika customer mengirim bukti pembayaran.</p>
          @endif
        </div>

        <div>
          <label class="text-sm text-slate-600">Final Qty ({{ $unitLabel }})</label>
          <input id="finalQty"
                 name="final_qty"
                 inputmode="decimal"
                 value="{{ old('final_qty', $order->final_qty) }}"
                 placeholder="contoh: 3.5"
                 class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-200 disabled:bg-slate-100 disabled:text-slate-500"
                 @disabled(!$canEditFinal)>
          <p class="text-xs text-slate-500 mt-2">Harga: <b>{{ rupiah($unitPrice) }}</b> / {{ $unitLabel }}</p>
        </div>

        <div>
          <label class="text-sm text-slate-600">Total Harga (Otomatis)</label>
          <input id="totalPrice"
                 name="total_price"
                 value="{{ old('total_price', $order->total_price) }}"
                 class="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none bg-slate-50 text-slate-700 disabled:bg-slate-100 disabled:text-slate-500"
                 readonly
                 @disabled(!$canEditFinal)>

          <div class="text-xs text-slate-500 mt-2">
            Preview: <b class="text-slate-700" id="totalPreview">
              {{ $order->total_price ? rupiah($order->total_price) : '-' }}
            </b>
          </div>
        </div>
      </div>

      <div class="flex flex-wrap gap-2">
        <button class="px-4 py-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.99] transition inline-flex items-center gap-2">
          <i class="fa-solid fa-floppy-disk"></i> Simpan
        </button>
      </div>
    </form>
  </div>

  {{-- Timeline --}}
  <div id="timeline" class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
    <div class="flex items-center justify-between gap-3 mb-5">
      <div class="flex items-center gap-2">
        <i class="fa-solid fa-timeline text-slate-500"></i>
        <h6 class="font-bold text-slate-800">Timeline Status</h6>
      </div>
      <span class="text-xs text-slate-500">{{ $histories->count() }} item</span>
    </div>

    @if($histories->count() === 0)
      <div class="bg-white rounded-2xl border border-slate-200 p-10 text-center text-slate-500 shadow-sm">
        <i class="fa-regular fa-folder-open text-3xl"></i>
        <div class="mt-2 font-semibold text-slate-700">Belum ada timeline</div>
        <div class="text-sm mt-1">Riwayat status akan muncul setelah ada perubahan.</div>
      </div>
    @else
      <ol class="relative border-s border-slate-200 pl-6 space-y-5">
        @foreach($histories as $h)
          <li class="relative">
            <span class="absolute -left-[18px] top-4 h-9 w-9 rounded-full bg-indigo-600 text-white flex items-center justify-center ring-4 ring-indigo-100">
              <i class="{{ status_icon($h->new_status) }} text-sm"></i>
            </span>

            <div class="rounded-2xl border border-slate-200 bg-white p-4 hover:bg-slate-50 transition">
              <div class="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
                <div class="min-w-0">
                  <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold {{ status_badge_class($h->new_status) }}">
                    <i class="{{ status_icon($h->new_status) }}"></i>
                    {{ status_label($h->new_status) }}
                  </span>

                  @if(!empty($h->old_status))
                    <div class="mt-2 text-xs text-slate-500 flex flex-wrap items-center gap-2">
                      <span class="px-2 py-1 rounded-full bg-slate-100 text-slate-700 font-medium">
                        {{ status_label($h->old_status) }}
                      </span>
                      <i class="fa-solid fa-arrow-right-long"></i>
                      <span class="px-2 py-1 rounded-full bg-slate-100 text-slate-700 font-medium">
                        {{ status_label($h->new_status) }}
                      </span>
                    </div>
                  @endif

                  <div class="mt-2 text-xs text-slate-500 inline-flex items-center gap-2">
                    <i class="fa-regular fa-user"></i>
                    Oleh: <span class="font-medium">{{ $h->changed_by_role }}</span>
                    @if(!empty($h->changed_by_id))
                      <span class="text-slate-400">(ID: {{ $h->changed_by_id }})</span>
                    @endif
                  </div>

                  @if(!empty($h->note))
                    <div class="mt-3 text-sm text-slate-700 bg-slate-50 border border-slate-200 rounded-xl p-3">
                      {{ $h->note }}
                    </div>
                  @endif
                </div>

                <div class="text-xs text-slate-500 whitespace-nowrap inline-flex items-center gap-2">
                  <i class="fa-regular fa-clock"></i>
                  <span>{{ $h->created_at ? tgl_id($h->created_at, 'd M Y H:i') : '-' }}</span>
                </div>
              </div>
            </div>
          </li>
        @endforeach
      </ol>
    @endif
  </div>

  {{-- Pembayaran --}}
  <div id="pembayaran" class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
    <div class="flex items-center gap-2 mb-4">
      <i class="fa-solid fa-money-check-dollar text-slate-500"></i>
      <h6 class="font-bold text-slate-800">Pembayaran</h6>
    </div>

    @if(!$p)
      <div class="bg-white rounded-2xl border border-slate-200 p-10 text-center text-slate-500 shadow-sm">
        <i class="fa-regular fa-credit-card text-3xl"></i>
        <div class="mt-2 font-semibold text-slate-700">Belum ada pembayaran</div>
        <div class="text-sm mt-1">Bukti/konfirmasi pembayaran akan tampil di sini.</div>
      </div>
    @else
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-slate-700">
        <div class="rounded-xl border border-slate-200 bg-slate-50 p-4">
          <div class="text-xs text-slate-500">Metode</div>
          <div class="font-semibold text-slate-900 mt-1">{{ $p->method }}</div>
          @if($p->channel_code)
            <div class="text-xs text-slate-500 mt-1">{{ $p->channel_name ?? $p->channel_code }} • {{ $p->destination_account }} a.n {{ $p->destination_holder }}</div>
          @endif
        </div>

        <div class="rounded-xl border border-slate-200 bg-slate-50 p-4">
          <div class="text-xs text-slate-500">Nominal</div>
          <div class="font-semibold text-slate-900 mt-1">{{ rupiah($p->amount) }}</div>
        </div>

        <div class="rounded-xl border border-slate-200 bg-slate-50 p-4">
          <div class="text-xs text-slate-500">Status</div>
          <div class="font-semibold text-slate-900 mt-1">{{ $p->status }}</div>
        </div>

        <div class="rounded-xl border border-slate-200 bg-slate-50 p-4">
          <div class="text-xs text-slate-500">Catatan Customer</div>
          <div class="font-semibold text-slate-900 mt-1">{{ $p->customer_note ?? '-' }}</div>
        </div>

        <div class="md:col-span-2 rounded-xl border border-slate-200 bg-slate-50 p-4">
          <div class="text-xs text-slate-500">Catatan Admin</div>
          <div class="font-semibold text-slate-900 mt-1">{{ $p->admin_note ?? '-' }}</div>
        </div>
      </div>

      @if(!empty($p->proof_path))
        <div class="mt-4">
          <img src="{{ asset('storage/'.$p->proof_path) }}"
               class="max-w-full md:max-w-sm rounded-2xl border border-slate-200"
               alt="Bukti pembayaran">
        </div>
      @endif

      @if($p->status === 'PENDING')
        <div class="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          <form method="POST" action="{{ route('admin.orders.payment.approve', $order) }}"
                class="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 shadow-sm">
            @csrf
            <p class="font-semibold text-emerald-800 mb-3 inline-flex items-center gap-2">
              <i class="fa-solid fa-circle-check"></i> Approve
            </p>
            <input class="w-full rounded-xl border border-emerald-200 px-4 py-2 outline-none"
                   name="admin_note" placeholder="Catatan (opsional)">
            <button class="mt-3 px-4 py-2 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 active:scale-[0.99] transition inline-flex items-center gap-2">
              <i class="fa-solid fa-check"></i> Approve
            </button>
          </form>

          <form method="POST" action="{{ route('admin.orders.payment.reject', $order) }}"
                class="rounded-2xl border border-red-200 bg-red-50 p-4 shadow-sm">
            @csrf
            <p class="font-semibold text-red-800 mb-3 inline-flex items-center gap-2">
              <i class="fa-solid fa-circle-xmark"></i> Reject
            </p>
            <textarea class="w-full rounded-xl border border-red-200 px-4 py-2 outline-none"
                      name="admin_note" placeholder="Alasan reject (wajib)" required></textarea>
            <button class="mt-3 px-4 py-2 rounded-xl bg-red-600 text-white hover:bg-red-700 active:scale-[0.99] transition inline-flex items-center gap-2">
              <i class="fa-solid fa-xmark"></i> Reject
            </button>
          </form>
        </div>
      @endif
    @endif
  </div>

  {{-- Chat --}}
  <div id="chat" class="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
    <div class="p-6 border-b border-slate-200">
      <div class="flex items-center gap-2">
        <i class="fa-solid fa-comments text-slate-500"></i>
        <h6 class="font-bold text-slate-800">Chat Per Pesanan</h6>
      </div>
      <p class="text-xs text-slate-500 mt-1">Input chat selalu tampil di bawah layar.</p>
    </div>

    <div id="chatBox"
         class="h-[520px] overflow-auto p-6 bg-slate-50 text-sm"
         style="padding-bottom: 140px;">
      <div class="text-slate-500">Memuat pesan...</div>
    </div>
  </div>

</div>

{{-- Chat Composer FIXED --}}
<div class="fixed left-0 right-0 z-50"
     style="bottom: calc(var(--bn-h, 84px) + 12px);">
  <div class="max-w-6xl mx-auto px-6 md:px-8">
    <div class="bg-white border border-slate-200 rounded-2xl shadow-sm p-3">
      @php
        $chatClosed = ($order->status === 'SELESAI');
      @endphp
      <form class="flex gap-2" method="POST" action="{{ route('admin.orders.messages.store', $order) }}">
        @csrf
        <input id="chatInput"
               class="flex-1 rounded-xl border border-slate-200 px-4 py-3 outline-none focus:ring-2 focus:ring-indigo-200 disabled:bg-slate-100 disabled:text-slate-500"
               name="body"
               placeholder="{{ $chatClosed ? 'Chat ditutup (pesanan sudah SELESAI)' : 'Tulis pesan...' }}"
               @disabled($chatClosed)
               required>
        <button
          class="px-5 py-3 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.99] transition inline-flex items-center gap-2 disabled:bg-slate-300 disabled:text-slate-600 disabled:cursor-not-allowed"
          @disabled($chatClosed)
        >
          <i class="fa-solid fa-paper-plane"></i>
          Kirim
        </button>
      </form>
      @if($chatClosed)
        <div class="mt-2 text-xs text-slate-500">
          Chat dinonaktifkan karena status pesanan sudah <b>SELESAI</b>.
        </div>
      @endif
    </div>
  </div>
</div>

@push('scripts')
<script>
(function () {
  // Copy order code
  const copyBtn = document.getElementById('copyCode');
  copyBtn?.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(@json($order->order_code));
      copyBtn.innerHTML = '<i class="fa-solid fa-check text-emerald-600"></i> Tersalin';
      setTimeout(() => {
        copyBtn.innerHTML = '<i class="fa-regular fa-copy text-slate-500"></i> Salin Kode';
      }, 1200);
    } catch (e) {}
  });

  // Update Proses: lock & auto total
  const form = document.getElementById('updateForm');
  const statusSelect = document.getElementById('statusSelect');
  const qty = document.getElementById('finalQty');
  const total = document.getElementById('totalPrice');
  const preview = document.getElementById('totalPreview');

  const unitPrice = parseFloat(form?.dataset?.unitPrice || '0');

  function isEditableStatus(st) { return st === 'SELESAI_MENUNGGU_PEMBAYARAN'; }

  function setEditable(editable) {
    if (!qty || !total) return;
    qty.disabled = !editable;
    total.disabled = !editable;
    total.readOnly = true;
    if (editable) recomputeTotal();
  }

  function formatRupiahNumber(n) {
    const x = Math.round(n);
    return 'Rp ' + x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  }

  function recomputeTotal() {
    if (!qty || !total || qty.disabled) return;
    const raw = (qty.value || '').toString().replace(',', '.');
    const q = parseFloat(raw);
    if (!isFinite(q) || q < 0) {
      total.value = '';
      if (preview) preview.textContent = '-';
      return;
    }
    const t = q * unitPrice;
    const numeric = isFinite(t) ? Math.round(t) : '';
    total.value = numeric;
    if (preview) preview.textContent = numeric !== '' ? formatRupiahNumber(numeric) : '-';
  }

  if (statusSelect) {
    setEditable(isEditableStatus(statusSelect.value));
    statusSelect.addEventListener('change', () => setEditable(isEditableStatus(statusSelect.value)));
  }
  if (qty) qty.addEventListener('input', recomputeTotal);

  // Chat polling
  async function loadMessages() {
    try {
      const res = await fetch("{{ route('admin.orders.messages', $order) }}");
      const data = await res.json();

      const box = document.getElementById('chatBox');
      if (!box) return;

      if (!Array.isArray(data)) {
        box.innerHTML = `<div class="text-slate-500">Format data chat tidak sesuai.</div>`;
        return;
      }

      box.innerHTML = data.map(m => `
        <div class="mb-3">
          <div class="flex items-center justify-between gap-3">
            <div class="font-semibold text-slate-800">${m.sender_role ?? '-'}</div>
            <div class="text-xs text-slate-500 whitespace-nowrap">${m.created_at ?? ''}</div>
          </div>
          <div class="text-slate-700 mt-1">${m.body ?? ''}</div>
        </div>
      `).join('');

      box.scrollTop = box.scrollHeight;
    } catch (e) {
      const box = document.getElementById('chatBox');
      if (box) box.innerHTML = `<div class="text-slate-500">Gagal memuat pesan.</div>`;
    }
  }

  loadMessages();
  setInterval(loadMessages, 3000);

  window.addEventListener('hashchange', () => {
    if (location.hash === '#chat') {
      setTimeout(() => document.getElementById('chatInput')?.focus(), 200);
    }
  });
})();
</script>
@endpush
@endsection
