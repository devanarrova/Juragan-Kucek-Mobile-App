@extends('admin.layouts.app')

@section('title','Profil Admin')
@section('page_title','Profil Admin')

@section('content')
@php
  $admin = $admin ?? auth('admin')->user();

  $photoUrl = ($admin && $admin->profile_photo)
      ? asset('storage/'.$admin->profile_photo)
      : null;

  $name = $admin?->name ?? $admin?->username ?? 'Admin';
  $username = $admin?->username ?? '-';
  $role = ($admin && ($admin->is_superadmin ?? false)) ? 'Super Admin' : 'Admin';

  $initial = mb_strtoupper(mb_substr($name ?: 'A', 0, 1));
@endphp

<div class="space-y-6">

  {{-- Hero header --}}
  <div class="rounded-3xl overflow-hidden border border-slate-200 shadow-sm bg-gradient-to-r from-[#1F717C] via-[#1F717C] to-slate-900 text-white relative">
    <div class="absolute -right-20 -top-20 w-72 h-72 rounded-full bg-white/10 blur-2xl"></div>
    <div class="absolute -left-24 -bottom-24 w-80 h-80 rounded-full bg-white/10 blur-2xl"></div>

    <div class="p-6 md:p-8 relative">
      <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
        <div class="flex items-center gap-4 min-w-0">
          @if($photoUrl)
            <img id="avatarPreview" src="{{ $photoUrl }}"
                 class="w-16 h-16 md:w-20 md:h-20 rounded-3xl object-cover border border-white/20 bg-white shadow-sm"
                 alt="Foto Profil">
            <div id="avatarFallback" class="hidden"></div>
          @else
            <div id="avatarFallback"
                 class="w-16 h-16 md:w-20 md:h-20 rounded-3xl bg-white/15 border border-white/20 flex items-center justify-center font-extrabold text-3xl shadow-sm">
              {{ $initial }}
            </div>
            <img id="avatarPreview" class="hidden w-16 h-16 md:w-20 md:h-20 rounded-3xl object-cover border border-white/20 bg-white shadow-sm" alt="Foto Profil">
          @endif

          <div class="min-w-0">
            <div class="text-xs text-white/70 font-extrabold uppercase tracking-wider">Akun Admin</div>
            <div class="mt-1 text-2xl font-extrabold truncate">{{ $name }}</div>
            <div class="text-sm text-white/75 truncate">{{ '@'.$username }} • {{ $role }}</div>

            <div class="mt-3 flex flex-wrap items-center gap-2">
              <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-white/10 border border-white/15">
                <i class="fa-solid fa-shield-halved"></i> Keamanan: Password wajib lama
              </span>
              <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-white/10 border border-white/15">
                <i class="fa-solid fa-image"></i> Foto max 2MB
              </span>
            </div>
          </div>
        </div>

        <div class="text-white/75 text-sm">
          <div class="font-extrabold text-white">Tips</div>
          <ul class="mt-2 space-y-1 text-xs">
            <li>• Pakai foto 1:1 biar rapi di topbar.</li>
            <li>• Password baru minimal 6 karakter (atau lebih kuat).</li>
            <li>• Username dipakai untuk login berikutnya.</li>
          </ul>
        </div>
      </div>
    </div>
  </div>

  {{-- Alerts --}}
  @if(session('ok_profile'))
    <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-2xl p-4 font-extrabold">
      <i class="fa-solid fa-circle-check mr-2"></i>{{ session('ok_profile') }}
    </div>
  @endif

  @if(session('ok_password'))
    <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-2xl p-4 font-extrabold">
      <i class="fa-solid fa-circle-check mr-2"></i>{{ session('ok_password') }}
    </div>
  @endif

  <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">

    {{-- LEFT: Profil form --}}
    <div class="lg:col-span-7 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
      <div class="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
        <div>
          <div class="font-extrabold text-slate-900 flex items-center gap-2">
            <span class="w-9 h-9 rounded-2xl bg-[#1F717C] text-white inline-flex items-center justify-center">
              <i class="fa-solid fa-user-pen"></i>
            </span>
            Update Profil
          </div>
          <div class="text-xs text-slate-500 mt-1">Ubah nama, username, dan foto profil.</div>
        </div>
      </div>

      <form method="POST" action="{{ route('admin.profile.update') }}" enctype="multipart/form-data" class="p-6 space-y-4">
        @csrf
        @method('PATCH')

        @if($errors->profile->any())
          <div class="bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4">
            <div class="font-extrabold flex items-center gap-2">
              <i class="fa-solid fa-triangle-exclamation"></i>
              Ada input profil yang salah
            </div>
            <ul class="list-disc pl-5 mt-2 text-sm space-y-1">
              @foreach($errors->profile->all() as $e)
                <li>{{ $e }}</li>
              @endforeach
            </ul>
          </div>
        @endif

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="text-xs font-extrabold text-slate-600">Nama</label>
            <input name="name" value="{{ old('name', $admin->name) }}" required
                   class="mt-1 w-full rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:ring-2 focus:ring-[#1F717C]/20">
          </div>

          <div>
            <label class="text-xs font-extrabold text-slate-600">Username</label>
            <input name="username" value="{{ old('username', $admin->username) }}" required
                   class="mt-1 w-full rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:ring-2 focus:ring-[#1F717C]/20">
            <div class="text-[11px] text-slate-500 mt-1">Dipakai untuk login berikutnya.</div>
          </div>
        </div>

        <div class="rounded-3xl border border-slate-200 bg-slate-50 p-4">
          <div class="flex items-start justify-between gap-4">
            <div class="min-w-0">
              <div class="text-xs font-extrabold text-slate-700">Foto Profil</div>
              <div class="text-xs text-slate-500 mt-1">JPG/PNG/WEBP • Max 2MB • Disarankan 1:1</div>
            </div>
            <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-white border border-slate-200 text-slate-700">
              <i class="fa-solid fa-image text-slate-500"></i>
              <span id="photoFileName">Belum dipilih</span>
            </span>
          </div>

          <input id="profilePhotoInput" type="file" name="profile_photo" accept="image/*"
                 class="mt-3 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 outline-none focus:ring-2 focus:ring-[#1F717C]/20">
        </div>

        <div class="flex items-center justify-end gap-2 pt-2">
          <button type="submit"
                  class="px-5 py-3 rounded-2xl bg-[#1F717C] text-white hover:opacity-95 active:scale-[0.99] transition font-extrabold inline-flex items-center gap-2">
            <i class="fa-solid fa-floppy-disk"></i>
            Simpan Profil
          </button>
        </div>
      </form>
    </div>

    {{-- RIGHT: Password --}}
    <div class="lg:col-span-5 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
      <div class="px-6 py-4 bg-slate-50 border-b border-slate-200">
        <div class="font-extrabold text-slate-900 flex items-center gap-2">
          <span class="w-9 h-9 rounded-2xl bg-slate-900 text-white inline-flex items-center justify-center">
            <i class="fa-solid fa-key"></i>
          </span>
          Keamanan
        </div>
        <div class="text-xs text-slate-500 mt-1">Ganti password wajib pakai password lama.</div>
      </div>

      <form method="POST" action="{{ route('admin.profile.password') }}" class="p-6 space-y-4">
        @csrf
        @method('PATCH')

        @if($errors->password->any())
          <div class="bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4">
            <div class="font-extrabold flex items-center gap-2">
              <i class="fa-solid fa-triangle-exclamation"></i>
              Ada input password yang salah
            </div>
            <ul class="list-disc pl-5 mt-2 text-sm space-y-1">
              @foreach($errors->password->all() as $e)
                <li>{{ $e }}</li>
              @endforeach
            </ul>
          </div>
        @endif

        {{-- Old password --}}
        <div>
          <label class="text-xs font-extrabold text-slate-600">Password Lama</label>
          <div class="mt-1 relative">
            <input id="oldPass" type="password" name="old_password" required
                   class="w-full rounded-2xl border border-slate-200 px-4 py-3 pr-12 outline-none focus:ring-2 focus:ring-slate-200">
            <button type="button" class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
                    onclick="togglePass('oldPass', this)">
              <i class="fa-solid fa-eye"></i>
            </button>
          </div>
        </div>

        {{-- New pass --}}
        <div>
          <label class="text-xs font-extrabold text-slate-600">Password Baru</label>
          <div class="mt-1 relative">
            <input id="newPass" type="password" name="password" required
                   class="w-full rounded-2xl border border-slate-200 px-4 py-3 pr-12 outline-none focus:ring-2 focus:ring-slate-200">
            <button type="button" class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
                    onclick="togglePass('newPass', this)">
              <i class="fa-solid fa-eye"></i>
            </button>
          </div>
          <div class="text-[11px] text-slate-500 mt-1">Minimal 6 karakter. Lebih kuat: campur huruf & angka.</div>
        </div>

        {{-- Confirm --}}
        <div>
          <label class="text-xs font-extrabold text-slate-600">Konfirmasi Password Baru</label>
          <div class="mt-1 relative">
            <input id="confirmPass" type="password" name="password_confirmation" required
                   class="w-full rounded-2xl border border-slate-200 px-4 py-3 pr-12 outline-none focus:ring-2 focus:ring-slate-200">
            <button type="button" class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
                    onclick="togglePass('confirmPass', this)">
              <i class="fa-solid fa-eye"></i>
            </button>
          </div>
        </div>

        <div class="pt-2">
          <button type="submit"
                  class="w-full px-5 py-3 rounded-2xl bg-slate-900 text-white hover:bg-slate-800 active:scale-[0.99] transition font-extrabold inline-flex items-center justify-center gap-2">
            <i class="fa-solid fa-lock"></i>
            Update Password
          </button>
        </div>
      </form>
    </div>

  </div>
</div>
@endsection

@push('scripts')
<script>
  (function () {
    const input = document.getElementById('profilePhotoInput');
    const img   = document.getElementById('avatarPreview');
    const fall  = document.getElementById('avatarFallback');
    const fileNameEl = document.getElementById('photoFileName');

    if (input) {
      input.addEventListener('change', () => {
        const file = input.files && input.files[0];
        if (!file) return;

        if (fileNameEl) fileNameEl.textContent = file.name;

        if (img) {
          const url = URL.createObjectURL(file);
          img.src = url;
          img.classList.remove('hidden');
        }
        if (fall) fall.classList.add('hidden');
      });
    }
  })();

  function togglePass(id, btn) {
    const el = document.getElementById(id);
    if (!el) return;

    const isPass = el.type === 'password';
    el.type = isPass ? 'text' : 'password';

    const icon = btn.querySelector('i');
    if (icon) {
      icon.className = isPass ? 'fa-solid fa-eye-slash' : 'fa-solid fa-eye';
    }
  }
</script>
@endpush
