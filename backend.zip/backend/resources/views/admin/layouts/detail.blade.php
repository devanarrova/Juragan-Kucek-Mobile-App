<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>@yield('title', 'Detail') Juragan Kucek</title>

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    body { font-family: 'Inter', sans-serif; background-color: #f1f5f9; }
    :root { --bn-h: 84px; } /* tinggi bottom navbar */
  </style>

  @stack('head')
</head>

<body class="min-h-screen w-full overflow-y-auto text-slate-800">
  {{-- Content --}}
  <main class="max-w-6xl mx-auto p-6 md:p-8"
      style="padding-bottom: calc(var(--bn-h) + 110px);">
  @yield('content')
</main>

  {{-- Bottom Navbar (khusus detail) --}}
  <nav class="fixed bottom-0 left-0 right-0 z-50 bg-white/90 backdrop-blur border-t border-slate-200"
     style="height: var(--bn-h);">
    <div class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-2">
      <a href="{{ route('admin.orders.index') }}"
         class="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-2xl border border-slate-200 hover:bg-slate-50">
        <i class="fa-solid fa-arrow-left"></i>
        <span class="font-semibold">Kembali</span>
      </a>

      <a href="#update-proses"
         class="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-2xl bg-indigo-600 text-white hover:bg-indigo-700">
        <i class="fa-solid fa-pen-to-square"></i>
        <span class="font-semibold">Update</span>
      </a>

      <a href="#pembayaran"
         class="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-2xl border border-slate-200 hover:bg-slate-50">
        <i class="fa-solid fa-money-check-dollar"></i>
        <span class="font-semibold">Pembayaran</span>
      </a>

      <a href="#chat"
         class="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-2xl border border-slate-200 hover:bg-slate-50">
        <i class="fa-solid fa-comments"></i>
        <span class="font-semibold">Chat</span>
      </a>
      <a href="#timeline"
         class="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-2xl border border-slate-200 hover:bg-slate-50">
        <i class="fa-solid fa-comments"></i>
        <span class="font-semibold">Timeline</span>
      </a>
    </div>
  </nav>

  @stack('scripts')
</body>
</html>
