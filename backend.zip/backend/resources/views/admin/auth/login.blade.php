<!doctype html>
<html lang="id" class="h-full">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="color-scheme" content="light dark">
  <title>Login Admin - Juragan Kucek</title>

  {{-- Apply theme ASAP (no flash) --}}
  <script>
    (function () {
      const saved = localStorage.getItem('jk_theme'); // 'dark' | 'light' | null
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      const useDark = saved ? (saved === 'dark') : prefersDark;
      document.documentElement.classList.toggle('dark', useDark);
    })();
  </script>

  {{-- Tailwind config SAFE sebelum CDN load --}}
  <script>
    window.tailwind = window.tailwind || {};
    window.tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            jkGreen: '#1F717C',
            jkBlue:  '#20A9B9',
          }
        }
      }
    };
  </script>

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
    html, body { height: 100%; }
    body { font-family: 'Inter', sans-serif; }
  </style>
</head>

<body class="min-h-screen bg-slate-50 dark:bg-slate-950">
  <div class="min-h-screen flex">

    {{-- Left Brand Panel --}}
    <div class="hidden lg:flex w-[44%] relative overflow-hidden">
      <div class="absolute inset-0 bg-gradient-to-br from-jkGreen via-jkBlue to-slate-900"></div>

      <div class="absolute -top-24 -right-24 w-80 h-80 rounded-full bg-white/10 blur-3xl"></div>
      <div class="absolute -bottom-24 -left-24 w-96 h-96 rounded-full bg-white/10 blur-3xl"></div>

      <div class="relative z-10 w-full p-10 flex flex-col justify-between text-white">
        <div class="flex items-center gap-4">
          {{-- Logo dibungkus putih (tidak ikut background) --}}
          <div class="w-12 h-12 rounded-2xl bg-white shadow-md border border-white/40 flex items-center justify-center p-2">
            <img
              src="{{ asset('assets/img/logo-juragan-kucek.png') }}"
              alt="Juragan Kucek"
              class="w-full h-full object-contain"
              onerror="this.style.display='none'"
            />
          </div>

          <div class="min-w-0">
            <div class="text-xs font-extrabold uppercase tracking-widest text-white/75">Juragan Kucek</div>
            <div class="text-2xl font-extrabold tracking-tight">Admin Panel</div>
          </div>
        </div>

        <div class="max-w-md">
          <div class="text-4xl font-extrabold leading-tight">
            Kelola order, verifikasi pembayaran, dan laporan pendapatan.
          </div>
          <p class="mt-3 text-white/75 text-sm leading-relaxed">
            Login khusus admin. Jaga kerahasiaan akun dan password.
          </p>

          <div class="mt-7 grid grid-cols-1 gap-3">
            <div class="rounded-2xl bg-white/10 border border-white/15 p-4">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-2xl bg-white/10 border border-white/15 flex items-center justify-center">
                  <i class="fa-solid fa-shield-halved"></i>
                </div>
                <div>
                  <div class="font-extrabold">Akses aman</div>
                  <div class="text-xs text-white/75">Ubah password wajib pakai password lama.</div>
                </div>
              </div>
            </div>

            <div class="rounded-2xl bg-white/10 border border-white/15 p-4">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-2xl bg-white/10 border border-white/15 flex items-center justify-center">
                  <i class="fa-solid fa-bolt"></i>
                </div>
                <div>
                  <div class="font-extrabold">Prioritas jelas</div>
                  <div class="text-xs text-white/75">Badge pending bantu admin fokus.</div>
                </div>
              </div>
            </div>
          </div>

          <div class="mt-10 text-xs text-white/70">
            © {{ date('Y') }} Juragan Kucek. All rights reserved.
          </div>
        </div>
      </div>
    </div>

    {{-- Right Login Panel --}}
    <div class="flex-1 flex items-center justify-center p-6">
      <div class="w-full max-w-md">

        {{-- Mobile header --}}
        <div class="lg:hidden mb-6">
          <div class="flex items-center justify-between gap-3">
            <div class="flex items-center gap-3">
              <div class="w-12 h-12 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-center p-2">
                <img
                  src="{{ asset('assets/img/logo-juragan-kucek.png') }}"
                  alt="Juragan Kucek"
                  class="w-full h-full object-contain"
                  onerror="this.style.display='none'"
                />
              </div>
              <div>
                <div class="text-xs font-extrabold uppercase tracking-widest text-slate-500 dark:text-slate-400">Juragan Kucek</div>
                <div class="text-xl font-extrabold text-slate-900 dark:text-white">Admin Login</div>
              </div>
            </div>

            {{-- Theme toggle (mobile) --}}
            <button type="button" data-theme-toggle
                    class="w-11 h-11 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition text-slate-700 dark:text-slate-200">
              <i class="fa-solid fa-moon"></i>
            </button>
          </div>
        </div>

        {{-- Card --}}
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          <div class="p-6 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/40">
            <div class="flex items-center justify-between gap-3">
              <div>
                <div class="text-xs font-extrabold uppercase tracking-widest text-slate-500 dark:text-slate-400">Login</div>
                <div class="text-2xl font-extrabold text-slate-900 dark:text-white mt-1">Masuk Admin</div>
                <div class="text-sm text-slate-500 dark:text-slate-400 mt-1">Gunakan username & password admin.</div>
              </div>

              <div class="flex items-center gap-2">
                {{-- Theme toggle (desktop) --}}
                <button type="button" data-theme-toggle
                        class="hidden lg:inline-flex w-11 h-11 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition text-slate-700 dark:text-slate-200">
                  <i class="fa-solid fa-moon"></i>
                </button>

                <div class="w-11 h-11 rounded-2xl bg-jkGreen/10 border border-jkGreen/15 text-jkGreen flex items-center justify-center">
                  <i class="fa-solid fa-right-to-bracket"></i>
                </div>
              </div>
            </div>
          </div>

          <div class="p-6">
            @if ($errors->any())
              <div class="mb-4 rounded-2xl border border-red-200 dark:border-red-900/40 bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-200 p-4">
                <div class="font-extrabold flex items-center gap-2">
                  <i class="fa-solid fa-triangle-exclamation"></i>
                  Login gagal
                </div>
                <div class="text-sm mt-1">
                  {{ $errors->first() }}
                </div>
              </div>
            @endif

            <form method="POST" action="{{ route('admin.login.post') }}" class="space-y-4">
              @csrf

              <div>
                <label class="text-xs font-extrabold text-slate-600 dark:text-slate-300">Username</label>
                <div class="mt-1 relative">
                  <i class="fa-solid fa-user absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                  <input
                    name="username"
                    value="{{ old('username') }}"
                    required
                    autofocus
                    autocomplete="username"
                    placeholder="Masukkan username"
                    class="w-full rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950
                           text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500
                           pl-11 pr-4 py-3 outline-none
                           focus:ring-2 focus:ring-jkBlue/25 focus:border-jkBlue"
                  />
                </div>
              </div>

              <div>
                <label class="text-xs font-extrabold text-slate-600 dark:text-slate-300">Password</label>
                <div class="mt-1 relative">
                  <i class="fa-solid fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                  <input
                    id="adminPassword"
                    type="password"
                    name="password"
                    required
                    autocomplete="current-password"
                    placeholder="Masukkan password"
                    class="w-full rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950
                           text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500
                           pl-11 pr-12 py-3 outline-none
                           focus:ring-2 focus:ring-jkBlue/25 focus:border-jkBlue"
                  />
                  <button type="button" id="togglePass"
                          class="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-xl
                                 hover:bg-slate-100 dark:hover:bg-slate-800
                                 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white transition">
                    <i class="fa-solid fa-eye"></i>
                  </button>
                </div>
              </div>

              <button
                type="submit"
                class="w-full px-5 py-3 rounded-2xl text-white font-extrabold shadow-sm
                       bg-gradient-to-r from-jkGreen to-jkBlue
                       hover:opacity-95 active:scale-[0.99] transition inline-flex items-center justify-center gap-2"
              >
                <i class="fa-solid fa-right-to-bracket"></i>
                Masuk
              </button>

              <div class="text-center text-xs text-slate-500 dark:text-slate-400 pt-1">
                Jika lupa akses admin, hubungi <b>Super Admin</b>.
              </div>
            </form>
          </div>
        </div>

        <div class="mt-4 text-center text-xs text-slate-400 dark:text-slate-500">
          Juragan Kucek • Admin Panel
        </div>

      </div>
    </div>

  </div>

  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const html = document.documentElement;

      // show/hide password
      const pass = document.getElementById('adminPassword');
      const togglePass = document.getElementById('togglePass');
      if (pass && togglePass) {
        togglePass.addEventListener('click', () => {
          const isPass = pass.type === 'password';
          pass.type = isPass ? 'text' : 'password';
          togglePass.innerHTML = isPass
            ? '<i class="fa-solid fa-eye-slash"></i>'
            : '<i class="fa-solid fa-eye"></i>';
        });
      }

      // theme toggle (support multi buttons)
      const toggles = document.querySelectorAll('[data-theme-toggle]');
      function setTheme(isDark) {
        html.classList.toggle('dark', isDark);
        localStorage.setItem('jk_theme', isDark ? 'dark' : 'light');
        toggles.forEach(btn => {
          btn.innerHTML = isDark
            ? '<i class="fa-solid fa-sun"></i>'
            : '<i class="fa-solid fa-moon"></i>';
        });
      }

      setTheme(html.classList.contains('dark'));
      toggles.forEach(btn => btn.addEventListener('click', () => {
        setTheme(!html.classList.contains('dark'));
      }));
    });
  </script>
</body>
</html>
