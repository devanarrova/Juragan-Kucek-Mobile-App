@php
  $pendingPaymentsCount   = (int) ($pendingPaymentsCount ?? 0);
  $ordersNeedConfirmCount = (int) ($ordersNeedConfirmCount ?? 0);
@endphp

<aside class="w-64 bg-white text-slate-600 flex-shrink-0 flex flex-col shadow-xl z-20 border-r border-slate-200 no-print">
  <div class="h-20 flex items-center justify-center border-b border-slate-100 bg-white px-6 gap-3">
  <img
    src="{{ asset('assets/img/logo-juragan-kucek.png') }}"
    alt="Juragan Kucek"
    class="w-13 h-12 rounded-xl object-contain border border-slate-200 shadow-sm bg-white"
  />
  <div class="leading-tight">
    <div class="font-extrabold text-[15px] text-slate-900 tracking-wide uppercase">Juragan Kucek</div>
    <div class="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Admin Panel</div>
  </div>
</div>


  <nav class="flex-1 overflow-y-auto py-6 space-y-1 px-3 no-scrollbar">
    <p class="px-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Utama</p>

    <x-admin.nav-item
      :href="route('admin.dashboard')"
      :active="request()->routeIs('admin.dashboard')"
      icon="fa-solid fa-chart-pie">
      Beranda
    </x-admin.nav-item>

    <p class="px-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 mt-6">Manajemen</p>

    <x-admin.nav-item
      :href="route('admin.users.index')"
      :active="request()->routeIs('admin.users.*')"
      icon="fa-solid fa-users">
      Data Pengguna
    </x-admin.nav-item>

    {{-- Badge: orders MENUNGGU_KONFIRMASI --}}
    <x-admin.nav-item
      :href="route('admin.orders.index')"
      :active="request()->routeIs('admin.orders.*')"
      icon="fa-solid fa-file-invoice"
      :badge="$ordersNeedConfirmCount"
      badgeTone="amber">
      Data Pesanan
    </x-admin.nav-item>

    {{-- Badge: payments PENDING --}}
    <x-admin.nav-item
      :href="route('admin.verify.index')"
      :active="request()->routeIs('admin.verify.*')"
      icon="fa-solid fa-file-invoice-dollar"
      :badge="$pendingPaymentsCount"
      badgeTone="violet">
      Verifikasi Bayar
    </x-admin.nav-item>

    <x-admin.nav-item
      :href="route('admin.services.index')"
      :active="request()->routeIs('admin.services.*')"
      icon="fa-solid fa-tags">
      Jenis Layanan
    </x-admin.nav-item>

    <x-admin.nav-item
      :href="route('admin.report.index')"
      :active="request()->routeIs('admin.report.*')"
      icon="fa-solid fa-chart-line">
      Laporan
    </x-admin.nav-item>
  </nav>

  <div class="p-4 border-t border-slate-100 bg-slate-50">
    <form method="POST" action="{{ route('admin.logout') }}">
      @csrf
      <button type="submit"
        class="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-red-50 text-red-600 hover:bg-red-100 border border-red-200 transition text-xs uppercase tracking-wide shadow-sm">
        <i class="fa-solid fa-right-from-bracket"></i> Logout
      </button>
    </form>
  </div>
</aside>
