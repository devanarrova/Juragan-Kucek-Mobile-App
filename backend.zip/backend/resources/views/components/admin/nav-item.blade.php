@props([
  'href' => '#',
  'active' => false,
  'icon' => null,
  'badge' => 0,
  'badgeTone' => 'indigo', // indigo | violet | amber (badge khusus, optional)
])

@php
  $badge = (int) ($badge ?? 0);

  $base = 'flex items-center justify-between gap-3 px-4 py-3 rounded-xl transition group';

  // ACTIVE: hijau custom #1F717C
  $cls  = $active
    ? 'bg-[#1F717C]/10 text-[#1F717C] ring-1 ring-[#1F717C]/20'
    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900';

  $iconWrap = $active
    ? 'bg-[#1F717C] text-white shadow-sm'
    : 'bg-slate-100 text-slate-600 group-hover:bg-slate-200';

  // Badge tone (untuk prioritas), tetap beda warna biar prioritas kebaca
  $badgeClass = match($badgeTone) {
    'violet' => 'bg-violet-600 text-white',
    'amber'  => 'bg-amber-500 text-white',
    // default: kalau mau ikut warna active, pakai hijau
    default  => 'bg-[#1F717C] text-white',
  };
@endphp

<a href="{{ $href }}" class="{{ $base }} {{ $cls }}">
  <div class="flex items-center gap-3 min-w-0">
    @if($icon)
      <span class="w-9 h-9 rounded-lg inline-flex items-center justify-center {{ $iconWrap }} transition">
        <i class="{{ $icon }}"></i>
      </span>
    @endif

    <span class="font-semibold truncate">
      {{ $slot }}
    </span>
  </div>

  @if($badge > 0)
    <span class="min-w-[26px] h-6 px-2 rounded-full text-xs font-extrabold inline-flex items-center justify-center {{ $badgeClass }}"
          title="Butuh perhatian">
      {{ $badge }}
    </span>
  @endif
</a>
