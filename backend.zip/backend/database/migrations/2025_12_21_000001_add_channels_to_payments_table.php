<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            // BANK_TRANSFER / E_WALLET

            $table->string('channel_code')->nullable()->after('method');
            $table->string('channel_name')->nullable()->after('channel_code');
            $table->string('destination_account')->nullable()->after('channel_name');
            $table->string('destination_holder')->nullable()->after('destination_account');

            $table->index(['method', 'channel_code']);
        });
    }

    public function down(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            $table->dropIndex(['method', 'channel_code']);
            $table->dropColumn([
                'channel_code',
                'channel_name',
                'destination_account',
                'destination_holder',
            ]);
        });
    }
};
