<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
       Schema::create('orders', function (\Illuminate\Database\Schema\Blueprint $table) {
        $table->id();
        $table->string('order_code')->unique();

        $table->foreignId('customer_id')->constrained('customers')->cascadeOnDelete();
        $table->foreignId('service_id')->constrained('services');

        $table->decimal('estimated_qty', 8, 2); // estimasi kg / pcs
        $table->date('pickup_date');
        $table->text('pickup_address');
        $table->text('notes')->nullable();

        $table->decimal('final_qty', 8, 2)->nullable();      // admin isi nanti
        $table->decimal('total_price', 12, 2)->nullable();   // admin isi nanti
        $table->string('status')->default('MENUNGGU_KONFIRMASI');

        $table->timestamps();
    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
