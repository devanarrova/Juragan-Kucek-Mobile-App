<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            if (!Schema::hasColumn('payments', 'customer_read_at')) {
                $table->timestamp('customer_read_at')->nullable()->after('verified_at');
                $table->index(['status', 'customer_read_at']);
            }
        });

        // Backfill agar pembayaran lama tidak muncul sebagai unread massal.
        // Kalau verified_at sudah ada dan status sudah diputuskan, anggap sudah "read".
        DB::table('payments')
            ->whereIn('status', ['APPROVED', 'REJECTED'])
            ->whereNotNull('verified_at')
            ->whereNull('customer_read_at')
            ->update(['customer_read_at' => DB::raw('verified_at')]);
    }

    public function down(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            if (Schema::hasColumn('payments', 'customer_read_at')) {
                $table->dropIndex(['status', 'customer_read_at']);
                $table->dropColumn('customer_read_at');
            }
        });
    }
};
