<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasColumn('order_status_histories', 'customer_read_at')) {
            Schema::table('order_status_histories', function (Blueprint $table) {
                $table->timestamp('customer_read_at')->nullable()->after('note');
                $table->index(['order_id', 'new_status', 'customer_read_at'], 'osh_customer_unread_idx');
            });

            // Backfill supaya tidak langsung "banjir" unread untuk data lama.
            DB::table('order_status_histories')
                ->whereIn('new_status', ['DIPROSES', 'DIANTAR', 'SELESAI'])
                ->update(['customer_read_at' => DB::raw('created_at')]);
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('order_status_histories', 'customer_read_at')) {
            Schema::table('order_status_histories', function (Blueprint $table) {
                $table->dropIndex('osh_customer_unread_idx');
                $table->dropColumn('customer_read_at');
            });
        }
    }
};
