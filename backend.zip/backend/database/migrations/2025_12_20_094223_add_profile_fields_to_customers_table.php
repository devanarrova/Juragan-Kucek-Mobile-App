<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('customers', function (Blueprint $table) {
            $table->string('phone', 30)->nullable()->after('username');
            $table->text('default_address')->nullable()->after('phone');
            // simpan path storage, contoh: customers/123/avatar.jpg (nullable)
            $table->string('profile_photo')->nullable()->after('default_address');
        });
    }

    public function down(): void
    {
        Schema::table('customers', function (Blueprint $table) {
            $table->dropColumn(['phone','default_address','profile_photo']);
        });
    }
};
