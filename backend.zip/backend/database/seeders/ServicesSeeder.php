<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Service;

class ServicesSeeder extends Seeder
{
    public function run(): void
    {
        $services = [
            // Kiloan
            ['name' => 'Cuci Setrika',      'pricing_type' => 'per_kg',   'unit_label' => 'kg',  'base_price' => 6000,  'is_active' => true],
            ['name' => 'Cuci Kering Lipat', 'pricing_type' => 'per_kg',   'unit_label' => 'kg',  'base_price' => 4000,  'is_active' => true],
            ['name' => 'Setrika',          'pricing_type' => 'per_kg',   'unit_label' => 'kg',  'base_price' => 4000,  'is_active' => true],

            // Satuan (per pcs)
            ['name' => 'Sprei',            'pricing_type' => 'per_item', 'unit_label' => 'pcs', 'base_price' => 13000, 'is_active' => true],
            ['name' => 'Blazer',           'pricing_type' => 'per_item', 'unit_label' => 'pcs', 'base_price' => 15000, 'is_active' => true],
            ['name' => 'Sweater',          'pricing_type' => 'per_item', 'unit_label' => 'pcs', 'base_price' => 15000, 'is_active' => true],
            ['name' => 'Tas Ransel',       'pricing_type' => 'per_item', 'unit_label' => 'pcs', 'base_price' => 20000, 'is_active' => true],
            ['name' => 'Bed Cover Single', 'pricing_type' => 'per_item', 'unit_label' => 'pcs', 'base_price' => 20000, 'is_active' => true],
            ['name' => 'Helm Standard',    'pricing_type' => 'per_item', 'unit_label' => 'pcs', 'base_price' => 30000, 'is_active' => true],
            ['name' => 'Karpet Kecil',     'pricing_type' => 'per_item', 'unit_label' => 'pcs', 'base_price' => 30000, 'is_active' => true],
        ];

        foreach ($services as $s) {
            Service::updateOrCreate(
                ['name' => $s['name'], 'pricing_type' => $s['pricing_type']],
                $s
            );
        }
    }
}
