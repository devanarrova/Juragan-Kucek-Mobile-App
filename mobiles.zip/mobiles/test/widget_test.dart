import 'package:flutter_test/flutter_test.dart';
import 'package:mobiles/app.dart';

void main() {
  testWidgets('App builds and shows Beranda', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());

    // Pastikan app tampil dan default tab Beranda muncul
    expect(find.text('Beranda'), findsOneWidget);
  });
}
