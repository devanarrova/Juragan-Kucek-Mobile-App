import 'dart:async';

import 'package:flutter/foundation.dart';

import '../auth/auth_session.dart';
import '../network/api_service.dart';

class NotificationSummary {
  final int unreadMessages;
  final int unreadEvents;
  final int orderUpdatesSince;
  final DateTime? serverTime;

  const NotificationSummary({
    required this.unreadMessages,
    required this.unreadEvents,
    required this.orderUpdatesSince,
    required this.serverTime,
  });

  static NotificationSummary empty() => const NotificationSummary(
        unreadMessages: 0,
        unreadEvents: 0,
        orderUpdatesSince: 0,
        serverTime: null,
      );

  factory NotificationSummary.fromMap(Map<String, dynamic> m) {
    final unread = (m['unread_messages'] is int)
        ? m['unread_messages'] as int
        : int.tryParse('${m['unread_messages']}') ?? 0;
    final updates = (m['order_updates_since'] is int)
        ? m['order_updates_since'] as int
        : int.tryParse('${m['order_updates_since']}') ?? 0;
    final events = (m['unread_events'] is int)
        ? m['unread_events'] as int
        : int.tryParse('${m['unread_events']}') ?? 0;
    final st = m['server_time']?.toString();
    final serverTime = (st == null || st.trim().isEmpty) ? null : DateTime.tryParse(st);

    return NotificationSummary(
      unreadMessages: unread,
      unreadEvents: events,
      orderUpdatesSince: updates,
      serverTime: serverTime,
    );
  }
}

class OrderEventNotif {
  final int id;
  final int orderId;
  final String status;
  final String title;
  final String message;
  final DateTime? createdAt;
  final DateTime? readAt;

  const OrderEventNotif({
    required this.id,
    required this.orderId,
    required this.status,
    required this.title,
    required this.message,
    required this.createdAt,
    required this.readAt,
  });

  bool get isUnread => readAt == null;

  factory OrderEventNotif.fromMap(Map<String, dynamic> m) {
    final id = (m['id'] is int) ? m['id'] as int : int.tryParse('${m['id']}') ?? 0;
    final orderId = (m['order_id'] is int)
        ? m['order_id'] as int
        : int.tryParse('${m['order_id']}') ?? 0;
    final status = (m['status'] ?? '').toString();
    final title = (m['title'] ?? '').toString();
    final message = (m['message'] ?? '').toString();
    final ca = m['created_at']?.toString();
    final ra = m['read_at']?.toString();
    return OrderEventNotif(
      id: id,
      orderId: orderId,
      status: status,
      title: title,
      message: message,
      createdAt: (ca == null || ca.isEmpty) ? null : DateTime.tryParse(ca),
      readAt: (ra == null || ra.isEmpty) ? null : DateTime.tryParse(ra),
    );
  }
}

/// Sumber kebenaran notifikasi (in-app) di client.
///
/// Tujuan: badge lonceng di AppBar + badge per order di Riwayat.
///
/// Endpoint backend:
/// - GET /api/notifications/summary
/// - GET /api/notifications/orders
class CustomerNotificationSession {
  CustomerNotificationSession._();

  static final CustomerNotificationSession instance =
      CustomerNotificationSession._();

  final ValueNotifier<NotificationSummary> summary =
      ValueNotifier<NotificationSummary>(NotificationSummary.empty());

  /// orderId -> unreadMessages dari admin
  final ValueNotifier<Map<int, int>> unreadByOrder =
      ValueNotifier<Map<int, int>>(<int, int>{});

  /// Daftar event status (DIPROSES/DIANTAR/SELESAI) milik customer.
  /// Dipakai di tab "Event" pada halaman Notifikasi.
  final ValueNotifier<List<OrderEventNotif>> events =
      ValueNotifier<List<OrderEventNotif>>(<OrderEventNotif>[]);

  final ValueNotifier<bool> loading = ValueNotifier<bool>(false);

  final ApiService _api = ApiService();
  bool _inited = false;

  void init() {
    if (_inited) return;
    _inited = true;

    AuthSession.instance.token.addListener(_onTokenChanged);
    _onTokenChanged();
  }

  void _onTokenChanged() {
    final t = AuthSession.instance.token.value;
    if (t == null || t.isEmpty) {
      summary.value = NotificationSummary.empty();
      unreadByOrder.value = <int, int>{};
      events.value = <OrderEventNotif>[];
      return;
    }
    // token ada => refresh
    unawaited(refreshAll());
  }

  Future<void> refreshAll() async {
    final token = AuthSession.tokenOrEmpty;
    if (token.isEmpty) return;

    loading.value = true;
    try {
      // ambil summary & per-order (paralel)
      final results = await Future.wait([
        _api.get('/notifications/summary', bearer: token),
        _api.get('/notifications/orders', bearer: token),
      ]);

      final sRes = results[0];
      if (sRes is Map) {
        summary.value = NotificationSummary.fromMap(
          Map<String, dynamic>.from(sRes),
        );
      }

      final oRes = results[1];
      if (oRes is Map && oRes['data'] is List) {
        final list = oRes['data'] as List;
        final map = <int, int>{};
        for (final x in list) {
          if (x is Map) {
            final m = Map<String, dynamic>.from(x);
            final id = (m['order_id'] is int)
                ? m['order_id'] as int
                : int.tryParse('${m['order_id']}') ?? 0;
            final c = (m['unread_messages'] is int)
                ? m['unread_messages'] as int
                : int.tryParse('${m['unread_messages']}') ?? 0;
            if (id > 0) map[id] = c;
          }
        }
        unreadByOrder.value = map;
      }
    } catch (_) {
      // silent: UI bisa tetap jalan walau polling gagal sementara
    } finally {
      loading.value = false;
    }
  }

  int unreadForOrder(int orderId) => unreadByOrder.value[orderId] ?? 0;

  /// Dipanggil setelah user buka chat order dan backend sudah markRead.
  /// Kita set lokal biar badge langsung hilang (tanpa nunggu polling).
  void markOrderMessagesRead(int orderId) {
    final map = Map<int, int>.from(unreadByOrder.value);
    final before = map[orderId] ?? 0;
    if (before == 0) return;

    map[orderId] = 0;
    unreadByOrder.value = map;

    final s = summary.value;
    final newTotal = (s.unreadMessages - before);
    summary.value = NotificationSummary(
      unreadMessages: newTotal < 0 ? 0 : newTotal,
      unreadEvents: s.unreadEvents,
      orderUpdatesSince: s.orderUpdatesSince,
      serverTime: s.serverTime,
    );
  }

  Future<void> refreshEvents({int limit = 50}) async {
    final token = AuthSession.tokenOrEmpty;
    if (token.isEmpty) return;

    try {
      final res = await _api.get('/notifications/events?limit=$limit', bearer: token);
      if (res is Map && res['data'] is List) {
        final list = res['data'] as List;
        final parsed = <OrderEventNotif>[];
        for (final x in list) {
          if (x is Map) {
            final m = Map<String, dynamic>.from(x);
            final ev = OrderEventNotif.fromMap(m);
            if (ev.id > 0 && ev.orderId > 0) parsed.add(ev);
          }
        }
        events.value = parsed;
      }
    } catch (_) {
      // silent
    }
  }


  Future<bool> deletePaymentEvent(int id) async {
    final token = AuthSession.tokenOrEmpty;
    if (token.isEmpty) return false;

    final current = events.value;
    final target = current.where((e) => e.id == id).toList();
    final wasUnread = target.isNotEmpty ? target.first.isUnread : false;

    try {
      await _api.delete('/notifications/events/$id', bearer: token);

      events.value = current.where((e) => e.id != id).toList(growable: false);

      unawaited(refreshAll());

      if (wasUnread) {
        final s = summary.value;
        final next = (s.unreadEvents - 1);
        summary.value = NotificationSummary(
          unreadMessages: s.unreadMessages,
          unreadEvents: next < 0 ? 0 : next,
          orderUpdatesSince: s.orderUpdatesSince,
          serverTime: s.serverTime,
        );
      }

      return true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> clearPaymentEvents() async {
    final token = AuthSession.tokenOrEmpty;
    if (token.isEmpty) return false;

    try {
      await _api.post('/notifications/events/clear', const {}, bearer: token);

      events.value = const [];
      final s = summary.value;
      summary.value = NotificationSummary(
        unreadMessages: s.unreadMessages,
        unreadEvents: 0,
        orderUpdatesSince: s.orderUpdatesSince,
        serverTime: s.serverTime,
      );

      unawaited(refreshAll());

      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> markEventsReadAll() async {
    final token = AuthSession.tokenOrEmpty;
    if (token.isEmpty) return;

    try {
      // ApiService.post membutuhkan 2 argumen positional: path dan body.
      await _api.post('/notifications/events/read-all', const {}, bearer: token);

      // update lokal supaya badge langsung turun
      final s = summary.value;
      summary.value = NotificationSummary(
        unreadMessages: s.unreadMessages,
        unreadEvents: 0,
        orderUpdatesSince: s.orderUpdatesSince,
        serverTime: s.serverTime,
      );

      final now = DateTime.now();
      events.value = events.value
          .map((e) => e.isUnread
              ? OrderEventNotif(
                  id: e.id,
                  orderId: e.orderId,
                  status: e.status,
                  title: e.title,
                  message: e.message,
                  createdAt: e.createdAt,
                  readAt: now,
                )
              : e)
          .toList(growable: false);

      unawaited(refreshAll());

    } catch (_) {
      // silent
    }
  }
}
