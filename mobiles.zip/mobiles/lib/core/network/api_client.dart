import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

/// Exception khusus untuk error HTTP non-2xx.
///
/// Penting: toString() dibuat kompatibel dengan format error lama,
/// supaya layar-layar existing tidak rusak (mereka banyak menampilkan `e.toString()`).
class ApiHttpException implements Exception {
  final String method;
  final String path;
  final int statusCode;
  final String rawBody;
  final dynamic decodedBody;

  const ApiHttpException({
    required this.method,
    required this.path,
    required this.statusCode,
    required this.rawBody,
    this.decodedBody,
  });

  @override
  String toString() {
    final d = decodedBody;
    if (d is Map && d['message'] != null) {
      return '$method $path gagal ($statusCode): ${d['message']}';
    }
    return '$method $path gagal ($statusCode): $rawBody';
  }
}

class ApiClient {
  final String baseUrl;
  final Duration timeout;

  const ApiClient({
    required this.baseUrl,
    this.timeout = const Duration(seconds: 20),
  });

  Map<String, String> _headers({String? bearerToken, bool json = false}) {
    final h = <String, String>{'Accept': 'application/json'};
    if (json) h['Content-Type'] = 'application/json';
    if (bearerToken != null && bearerToken.trim().isNotEmpty) {
      h['Authorization'] = 'Bearer $bearerToken';
    }
    return h;
  }

  dynamic _decodeBody(String body) {
    if (body.trim().isEmpty) return null;
    try {
      return jsonDecode(body);
    } catch (_) {
      return body;
    }
  }

  Exception _wrapError(String method, String path, Object e) {
    if (e is TimeoutException) {
      return Exception('$method $path timeout (${timeout.inSeconds}s).');
    }
    if (e is SocketException) {
      return Exception(
          '$method $path gagal: tidak bisa konek ke server (${e.message}).');
    }
    return Exception('$method $path gagal: $e');
  }

  Exception _httpError(String method, String path, int code, String body) {
    final decoded = _decodeBody(body);
    return ApiHttpException(
      method: method,
      path: path,
      statusCode: code,
      rawBody: body,
      decodedBody: decoded,
    );
  }

  Future<dynamic> getJson(String path, {String? bearerToken}) async {
    final uri = Uri.parse('$baseUrl$path');
    try {
      final res = await http
          .get(uri, headers: _headers(bearerToken: bearerToken))
          .timeout(timeout);

      if (res.statusCode < 200 || res.statusCode >= 300) {
        throw _httpError('GET', path, res.statusCode, res.body);
      }
      return _decodeBody(res.body);
    } catch (e) {
      if (e is ApiHttpException) rethrow;
      throw _wrapError('GET', path, e);
    }
  }

  Future<dynamic> postJson(
    String path,
    Map<String, dynamic> body, {
    String? bearerToken,
  }) async {
    final uri = Uri.parse('$baseUrl$path');
    try {
      final res = await http
          .post(
            uri,
            headers: _headers(bearerToken: bearerToken, json: true),
            body: jsonEncode(body),
          )
          .timeout(timeout);

      if (res.statusCode < 200 || res.statusCode >= 300) {
        throw _httpError('POST', path, res.statusCode, res.body);
      }
      return _decodeBody(res.body);
    } catch (e) {
      if (e is ApiHttpException) rethrow;
      throw _wrapError('POST', path, e);
    }
  }

  Future<dynamic> putJson(
    String path,
    Map<String, dynamic> body, {
    String? bearerToken,
  }) async {
    final uri = Uri.parse('$baseUrl$path');
    try {
      final res = await http
          .put(
            uri,
            headers: _headers(bearerToken: bearerToken, json: true),
            body: jsonEncode(body),
          )
          .timeout(timeout);

      if (res.statusCode < 200 || res.statusCode >= 300) {
        throw _httpError('PUT', path, res.statusCode, res.body);
      }
      return _decodeBody(res.body);
    } catch (e) {
      if (e is ApiHttpException) rethrow;
      throw _wrapError('PUT', path, e);
    }
  }

  Future<dynamic> deleteJson(String path, {String? bearerToken}) async {
    final uri = Uri.parse('$baseUrl$path');
    try {
      final res = await http
          .delete(uri, headers: _headers(bearerToken: bearerToken))
          .timeout(timeout);

      if (res.statusCode < 200 || res.statusCode >= 300) {
        throw _httpError('DELETE', path, res.statusCode, res.body);
      }
      return _decodeBody(res.body);
    } catch (e) {
      if (e is ApiHttpException) rethrow;
      throw _wrapError('DELETE', path, e);
    }
  }

  Future<dynamic> postMultipart(
    String path, {
    required Map<String, String> fields,
    required Map<String, File> files,
    String? bearerToken,
  }) async {
    final uri = Uri.parse('$baseUrl$path');
    try {
      final req = http.MultipartRequest('POST', uri);
      req.headers.addAll(_headers(bearerToken: bearerToken));
      req.fields.addAll(fields);

      for (final e in files.entries) {
        req.files.add(await http.MultipartFile.fromPath(e.key, e.value.path));
      }

      final streamed = await req.send().timeout(timeout);
      final res = await http.Response.fromStream(streamed);

      if (res.statusCode < 200 || res.statusCode >= 300) {
        throw _httpError('POST', path, res.statusCode, res.body);
      }
      return _decodeBody(res.body);
    } catch (e) {
      if (e is ApiHttpException) rethrow;
      throw _wrapError('POST', path, e);
    }
  }
}
