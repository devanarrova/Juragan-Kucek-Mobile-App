import 'dart:io';

import '../auth/auth_session.dart';
import '../config/app_config.dart';
import '../router/app_navigator.dart';
import 'api_client.dart';

class ApiService {
  final ApiClient _client;

  ApiService({ApiClient? client})
      : _client = client ?? ApiClient(baseUrl: AppConfig.apiBaseUrl);

  Future<dynamic> get(String path, {String? bearer}) async {
    try {
      return await _client.getJson(path, bearerToken: bearer);
    } on ApiHttpException catch (e) {
      if (e.statusCode == 401) {
        // token invalid / expired -> paksa logout, AuthGate akan balik ke Login.
        await AuthSession.instance.clear();
        AppNavigator.resetToLogin();
      }
      rethrow;
    }
  }

  Future<dynamic> post(
    String path,
    Map<String, dynamic> body, {
    String? bearer,
  }) async {
    try {
      return await _client.postJson(path, body, bearerToken: bearer);
    } on ApiHttpException catch (e) {
      if (e.statusCode == 401) {
        await AuthSession.instance.clear();
        AppNavigator.resetToLogin();
      }
      rethrow;
    }
  }

  Future<dynamic> put(
    String path,
    Map<String, dynamic> body, {
    String? bearer,
  }) async {
    try {
      return await _client.putJson(path, body, bearerToken: bearer);
    } on ApiHttpException catch (e) {
      if (e.statusCode == 401) {
        await AuthSession.instance.clear();
        AppNavigator.resetToLogin();
      }
      rethrow;
    }
  }

  Future<dynamic> delete(String path, {String? bearer}) async {
    try {
      return await _client.deleteJson(path, bearerToken: bearer);
    } on ApiHttpException catch (e) {
      if (e.statusCode == 401) {
        await AuthSession.instance.clear();
        AppNavigator.resetToLogin();
      }
      rethrow;
    }
  }

  Future<dynamic> postMultipart(
    String path, {
    required Map<String, String> fields,
    required Map<String, File> files,
    String? bearer,
  }) async {
    try {
      return await _client.postMultipart(
        path,
        fields: fields,
        files: files,
        bearerToken: bearer,
      );
    } on ApiHttpException catch (e) {
      if (e.statusCode == 401) {
        await AuthSession.instance.clear();
        AppNavigator.resetToLogin();
      }
      rethrow;
    }
  }
}
