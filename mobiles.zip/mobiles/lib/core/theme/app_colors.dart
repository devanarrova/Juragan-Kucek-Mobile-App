import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const jkDarkCyan = Color(0xFF1F717C); // #1F717C
  static const jkCyan = Color(0xFF20A9B9); // #20A9B9

  // LIGHT (lebih cocok untuk laundry)
  static const bgLight = Color(0xFFF3FBFC);
  static const surfaceLight = Color(0xFFFFFFFF);
  static const textDark = Color(0xFF102A2E);

  // DARK (kalau suatu saat mau)
  static const bgDark = Color(0xFF0B1416);
  static const surfaceDark = Color(0xFF0F1E21);
}
