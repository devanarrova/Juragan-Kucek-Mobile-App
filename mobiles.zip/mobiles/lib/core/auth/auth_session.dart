import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class AuthSession {
  AuthSession._();

  static final AuthSession instance = AuthSession._();

  static const _kTokenKey = 'customer_token';

  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  /// null = belum login
  final ValueNotifier<String?> token = ValueNotifier<String?>(null);

  /// Biar kode lain bisa aman pakai token walau null
  static String get tokenOrEmpty => instance.token.value ?? '';

  Future<void> init() async {
    token.value = await _storage.read(key: _kTokenKey);
  }

  Future<void> setToken(String newToken) async {
    await _storage.write(key: _kTokenKey, value: newToken);
    token.value = newToken;
  }

  Future<void> clear() async {
    await _storage.delete(key: _kTokenKey);
    token.value = null;
  }
}
