import 'package:flutter/foundation.dart';
import 'package:characters/characters.dart';

import '../network/api_service.dart';
import 'auth_session.dart';

class CustomerProfile {
  final int? id;
  final String name;
  final String phone;
  final String defaultAddress;
  final String? profilePhotoUrl;

  const CustomerProfile({
    required this.id,
    required this.name,
    required this.phone,
    required this.defaultAddress,
    required this.profilePhotoUrl,
  });

  String get initial {
    final n = name.trim();
    if (n.isEmpty) return '?';
    return n.characters.first.toUpperCase();
  }

  String get firstName {
    final n = name.trim();
    if (n.isEmpty) return '';
    return n.split(RegExp(r'\s+')).first;
  }

  static CustomerProfile fromMap(Map<String, dynamic> m) {
    return CustomerProfile(
      id: (m['id'] is int) ? m['id'] as int : int.tryParse('${m['id']}'),
      name: (m['name'] ?? '').toString(),
      phone: (m['phone'] ?? '').toString(),
      defaultAddress: (m['default_address'] ?? '').toString(),
      profilePhotoUrl: (m['profile_photo_url'] == null)
          ? null
          : m['profile_photo_url'].toString(),
    );
  }
}

/// Sumber kebenaran data profil di client.
///
/// Problem yang kamu alami (avatar & sapaan tidak ikut berubah) terjadi
/// karena profil cuma di-fetch di halaman Profil, tapi Home/AppBar pakai placeholder.
/// Jadi kita butuh "session" yang bisa didengar (ValueNotifier).
class CustomerProfileSession {
  CustomerProfileSession._();

  static final CustomerProfileSession instance = CustomerProfileSession._();

  final ValueNotifier<CustomerProfile?> profile =
      ValueNotifier<CustomerProfile?>(null);
  final ValueNotifier<bool> loading = ValueNotifier<bool>(false);

  final ApiService _api = ApiService();
  bool _inited = false;

  void init() {
    if (_inited) return;
    _inited = true;

    // ikuti perubahan token: login => fetch profil, logout => clear.
    AuthSession.instance.token.addListener(_onTokenChanged);
    _onTokenChanged();
  }

  void _onTokenChanged() {
    final t = AuthSession.instance.token.value;
    if (t == null || t.isEmpty) {
      profile.value = null;
      return;
    }
    // token ada => refresh profil
    refresh();
  }

  Map<String, dynamic>? _extractCustomer(dynamic res) {
    if (res is Map) {
      final c = res['customer'];
      if (c is Map) return Map<String, dynamic>.from(c);
      // fallback: kalau backend return langsung object
      return Map<String, dynamic>.from(res);
    }
    return null;
  }

  Future<void> refresh() async {
    final token = AuthSession.tokenOrEmpty;
    if (token.isEmpty) return;

    loading.value = true;
    try {
      final res = await _api.get('/me', bearer: token);
      final c = _extractCustomer(res);
      if (c != null) {
        profile.value = CustomerProfile.fromMap(c);
      }
    } catch (_) {
      // error ditangani per layar (snackbar/UI). Session cukup silent.
    } finally {
      loading.value = false;
    }
  }

  /// Pakai ini kalau kita sudah punya response customer (misal dari PUT /me).
  void setFromResponse(dynamic res) {
    final c = _extractCustomer(res);
    if (c == null) return;
    profile.value = CustomerProfile.fromMap(c);
  }
}
