import 'package:flutter/material.dart';

import '../../features/auth/login_screen.dart';
import 'main_shell.dart';

/// Navigator global supaya kita bisa reset route (misal saat token invalid/401)
/// tanpa butuh BuildContext.
class AppNavigator {
  static final GlobalKey<NavigatorState> key = GlobalKey<NavigatorState>();

  static void resetToLogin() {
    final nav = key.currentState;
    if (nav == null) return;
    nav.pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (_) => false,
    );
  }

  static void resetToMain() {
    final nav = key.currentState;
    if (nav == null) return;
    nav.pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MainShell()),
      (_) => false,
    );
  }
}
