import 'dart:async';

import 'package:flutter/material.dart';

import '../../features/home/home_screen.dart';
import '../../features/services/services_screen.dart';
import '../../features/order_create/order_create_screen.dart';
import '../../features/orders/orders_screen.dart';
import '../../features/settings/settings_screen.dart';
import '../../features/notifications/notifications_screen.dart';
import '../auth/customer_profile_session.dart';
import '../notifications/customer_notification_session.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> with WidgetsBindingObserver {
  final ValueNotifier<int> _index = ValueNotifier<int>(0);

  // 0 = Home, 1 = Layanan, 2 = Buat Pesanan (FAB), 3 = Riwayat, 4 = Pengaturan
  late final List<Widget> _tabs;

  Timer? _notifPoller;
  final Duration _notifInterval = const Duration(seconds: 15);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _tabs = [
      HomeScreen(
        onCreateOrder: () => _go(2),
        onOpenServices: () => _go(1),
        onOpenOrders: () => _go(3),
        onOpenSupport: () => _go(4),

        // sementara: kalau belum ada "pesanan aktif", arahkan ke tab Riwayat
        onOpenActiveOrderDetail: () => _go(3),
        onOpenActiveOrderChat: () => _go(3),
      ),
      const ServicesScreen(),

      // non-const karena ada callback
      OrderCreateScreen(onSwitchTab: _go),

      const OrdersScreen(),
      const SettingsScreen(),
    ];

    // initial fetch notif (badge lonceng + badge per order)
    CustomerNotificationSession.instance.refreshAll();
    _startNotifPolling();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      CustomerNotificationSession.instance.refreshAll();
      _startNotifPolling();
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive ||
        state == AppLifecycleState.detached) {
      _stopNotifPolling();
    }
  }

  static Color _alpha(Color c, double opacity) =>
      c.withAlpha((opacity * 255).round().clamp(0, 255));

  void _go(int i) => _index.value = i;

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _stopNotifPolling();
    _index.dispose();
    super.dispose();
  }

  void _startNotifPolling() {
    _notifPoller?.cancel();
    _notifPoller = Timer.periodic(_notifInterval, (_) {
      CustomerNotificationSession.instance.refreshAll();
    });
  }

  void _stopNotifPolling() {
    _notifPoller?.cancel();
    _notifPoller = null;
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return ValueListenableBuilder<int>(
      valueListenable: _index,
      builder: (context, idx, _) {
        return Scaffold(
          appBar: AppBar(
            title: Row(
              children: [
                Image.asset(
                  'assets/images/logo-jk.png',
                  height: 28,
                ),
                const SizedBox(width: 10),
                const Text(
                  'Juragan Kucek',
                  style: TextStyle(fontWeight: FontWeight.w900),
                ),
              ],
            ),
            actions: [
              ValueListenableBuilder<NotificationSummary>(
                valueListenable: CustomerNotificationSession.instance.summary,
                builder: (_, s, __) {
                  final unread = s.unreadMessages + s.unreadEvents;
                  return IconButton(
                    tooltip: 'Notifikasi',
                    onPressed: () async {
                      await Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => const NotificationsScreen(),
                        ),
                      );
                      // setelah balik, refresh sekali (biar badge nyambung)
                      CustomerNotificationSession.instance.refreshAll();
                    },
                    icon: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        const Icon(Icons.notifications_none_rounded),
                        if (unread > 0)
                          Positioned(
                            right: -2,
                            top: -2,
                            child: _Badge(count: unread),
                          ),
                      ],
                    ),
                  );
                },
              ),
              Padding(
                padding: const EdgeInsets.only(right: 10),
                child: InkWell(
                  borderRadius: BorderRadius.circular(999),
                  onTap: () => _go(4),
                  child: ValueListenableBuilder<CustomerProfile?>(
                    valueListenable: CustomerProfileSession.instance.profile,
                    builder: (_, p, __) {
                      final initial = p?.initial ?? '?';
                      final url = p?.profilePhotoUrl;

                      return CircleAvatar(
                        radius: 16,
                        backgroundColor: _alpha(cs.primary, 0.18),
                        foregroundImage:
                            (url != null && url.trim().isNotEmpty)
                                ? NetworkImage(url)
                                : null,
                        child: Text(
                          initial,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            color: cs.primary,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
          body: IndexedStack(
            index: idx,
            children: _tabs,
          ),
          floatingActionButtonLocation:
              FloatingActionButtonLocation.centerDocked,
          floatingActionButton: FloatingActionButton(
            heroTag: 'fab_order',
            backgroundColor: cs.secondary,
            foregroundColor: cs.onSecondary,
            onPressed: () => _go(2),
            child: const Icon(Icons.local_laundry_service_rounded, size: 28),
          ),
          bottomNavigationBar: SafeArea(
            top: false,
            child: BottomAppBar(
              shape: const CircularNotchedRectangle(),
              notchMargin: 8,
              color: cs.surface,
              child: SizedBox(
                height: 64,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _NavItem(
                      label: 'Beranda',
                      icon: Icons.home_rounded,
                      selected: idx == 0,
                      onTap: () => _go(0),
                    ),
                    _NavItem(
                      label: 'Layanan',
                      icon: Icons.local_laundry_service_rounded,
                      selected: idx == 1,
                      onTap: () => _go(1),
                    ),

                    const SizedBox(width: 44), // ruang FAB

                    _NavItem(
                      label: 'Riwayat',
                      icon: Icons.receipt_long_rounded,
                      selected: idx == 3,
                      onTap: () => _go(3),
                    ),
                    _NavItem(
                      label: 'Pengaturan',
                      icon: Icons.settings_rounded,
                      selected: idx == 4,
                      onTap: () => _go(4),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _NavItem extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _NavItem({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  static Color _alpha(Color c, double opacity) =>
      c.withAlpha((opacity * 255).round().clamp(0, 255));

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final color = selected ? cs.secondary : _alpha(cs.onSurface, 0.70);

    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                  color: color,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final int count;

  const _Badge({required this.count});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final text = count > 99 ? '99+' : count.toString();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: cs.error,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: cs.surface, width: 1.2),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: cs.onError,
          fontSize: 10,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}
