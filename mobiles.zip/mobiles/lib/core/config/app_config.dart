class AppConfig {
  AppConfig._();

  /// Android Emulator (default): 10.0.2.2
  /// Run:
  /// flutter run --dart-define=API_BASE_URL=http://10.0.2.2:8000/api
  ///
  /// HP fisik:
  /// flutter run --dart-define=API_BASE_URL=http://192.168.x.x:8000/api
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8000/api',
  );
}
