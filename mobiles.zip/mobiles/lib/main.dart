import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'core/auth/auth_session.dart';
import 'core/auth/customer_profile_session.dart';
import 'core/notifications/customer_notification_session.dart';
import 'core/theme/app_theme.dart';
import 'core/router/main_shell.dart';
import 'core/router/app_navigator.dart';
import 'features/auth/login_screen.dart';

/// Kalau kamu mau test flow login dari nol, set jadi true (sementara).
/// Setelah beres testing, balikin ke false.
const bool kForceLogoutOnStartForTesting = false;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await AuthSession.instance.init();

  // init session profil (untuk avatar & sapaan di seluruh app)
  CustomerProfileSession.instance.init();

  // init session notifikasi (badge lonceng + badge per order)
  CustomerNotificationSession.instance.init();

  if (kForceLogoutOnStartForTesting) {
    await AuthSession.instance.clear();
  }

  if (kDebugMode) {
    final t = AuthSession.tokenOrEmpty;
    debugPrint(
        'Auth token loaded: ${t.isEmpty ? "EMPTY" : "OK (len=${t.length})"}');
  }

  runApp(const JuraganKucekApp());
}

class JuraganKucekApp extends StatelessWidget {
  const JuraganKucekApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Juragan Kucek',
      debugShowCheckedModeBanner: false,
      navigatorKey: AppNavigator.key,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: ThemeMode.light,
      home: const _AuthGate(),
    );
  }
}

class _AuthGate extends StatelessWidget {
  const _AuthGate();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String?>(
      valueListenable: AuthSession.instance.token,
      builder: (_, token, __) {
        // token kosong => Login
        if (token == null || token.isEmpty) {
          return const LoginScreen();
        }
        // token ada => Beranda/MainShell
        return const MainShell();
      },
    );
  }
}
