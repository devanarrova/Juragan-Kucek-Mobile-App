import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/auth/auth_session.dart';
import '../../core/auth/customer_profile_session.dart';
import '../../core/network/api_service.dart';
import '../chat/order_chat_screen.dart';
import '../orders/order_detail_screen.dart';
import '../profile/profile_screen.dart';

/// BERANDA CUSTOMER (UI/UX revamp)
///
/// Target:
/// - Beranda tidak lagi terlihat "template" (lebih mirip app laundry sungguhan)
/// - Ada data real: pesanan aktif + layanan populer
/// - Ada fallback demo yang aman: kalau gagal fetch, user masih bisa klik aksi cepat.
class HomeScreen extends StatefulWidget {
  final VoidCallback onCreateOrder;
  final VoidCallback onOpenServices;
  final VoidCallback onOpenOrders;
  final VoidCallback onOpenSupport;
  final VoidCallback onOpenActiveOrderDetail;
  final VoidCallback onOpenActiveOrderChat;

  const HomeScreen({
    super.key,
    required this.onCreateOrder,
    required this.onOpenServices,
    required this.onOpenOrders,
    required this.onOpenSupport,
    required this.onOpenActiveOrderDetail,
    required this.onOpenActiveOrderChat,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ApiService _api = ApiService();

  bool _loading = true;
  String? _error;

  List<Map<String, dynamic>> _orders = const [];
  List<Map<String, dynamic>> _services = const [];

  Future<void> _loadAll({bool silent = false}) async {
    if (!silent) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }

    try {
      final token = AuthSession.tokenOrEmpty;
      if (token.isEmpty) throw Exception('Token kosong. Silakan login ulang.');

      final results = await Future.wait([
        _api.get('/orders', bearer: token),
        _api.get('/services'),
      ]).timeout(const Duration(seconds: 20));

      final ordersRes = results[0];
      final servicesRes = results[1];

      final ordersList = (ordersRes is List) ? ordersRes : <dynamic>[];
      final servicesList = (servicesRes is List) ? servicesRes : <dynamic>[];

      final orders = <Map<String, dynamic>>[];
      for (final x in ordersList) {
        if (x is Map) orders.add(Map<String, dynamic>.from(x));
      }

      // urut terbaru (id desc)
      orders.sort((a, b) {
        final aId = int.tryParse('${a['id']}') ?? 0;
        final bId = int.tryParse('${b['id']}') ?? 0;
        return bId.compareTo(aId);
      });

      final services = <Map<String, dynamic>>[];
      for (final x in servicesList) {
        if (x is Map) services.add(Map<String, dynamic>.from(x));
      }

      if (!mounted) return;
      setState(() {
        _orders = orders;
        _services = services;
        _loading = false;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString();
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  Future<void> _refresh() async {
    // refresh profil juga (avatar + alamat)
    await CustomerProfileSession.instance.refresh();
    await _loadAll(silent: true);
  }

  static Color _opa(Color c, double o) =>
      c.withAlpha((o * 255).round().clamp(0, 255));

  String _statusLabel(String s) {
    switch (s) {
      case 'MENUNGGU_KONFIRMASI':
        return 'Menunggu Konfirmasi';
      case 'DIPROSES':
        return 'Diproses';
      case 'SELESAI_MENUNGGU_PEMBAYARAN':
        return 'Menunggu Pembayaran';
      case 'MENUNGGU_VERIFIKASI_PEMBAYARAN':
        return 'Menunggu Verifikasi';
      case 'PEMBAYARAN_DITOLAK':
        return 'Pembayaran Ditolak';
      case 'LUNAS_SIAP_DIANTAR':
        return 'Lunas, Siap Diantar';
      case 'DIANTAR':
        return 'Diantar';
      case 'SELESAI':
        return 'Selesai';
      case 'DIBATALKAN':
        return 'Dibatalkan';
      default:
        return s;
    }
  }

  String _statusHint(String s) {
    switch (s) {
      case 'MENUNGGU_KONFIRMASI':
        return 'Pesanan kamu sedang menunggu konfirmasi admin.';
      case 'DIPROSES':
        return 'Pesanan kamu sedang diproses. Kami update kalau sudah selesai.';
      case 'SELESAI_MENUNGGU_PEMBAYARAN':
        return 'Pesanan selesai diproses. Silakan lakukan pembayaran.';
      case 'MENUNGGU_VERIFIKASI_PEMBAYARAN':
        return 'Bukti bayar sudah masuk. Menunggu verifikasi admin.';
      case 'PEMBAYARAN_DITOLAK':
        return 'Bukti bayar ditolak. Upload ulang dengan foto yang jelas.';
      case 'LUNAS_SIAP_DIANTAR':
        return 'Pembayaran diterima. Pesanan siap diantar.';
      case 'DIANTAR':
        return 'Kurir sedang mengantar pesanan kamu.';
      case 'SELESAI':
        return 'Pesanan selesai. Terima kasih sudah menggunakan Juragan Kucek!';
      default:
        return 'Status: ${_statusLabel(s)}';
    }
  }

  num? _numFrom(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }

  num? _extractUnitPrice(Map<String, dynamic> s) {
    const keys = [
      'price',
      'price_per_kg',
      'price_per_unit',
      'unit_price',
      'rate',
      'base_price',
    ];
    for (final k in keys) {
      final n = _numFrom(s[k]);
      if (n != null && n > 0) return n;
    }
    return null;
  }

  String _fmtRupiah(num value) {
    final v = value.round();
    final s = v.toString();
    final buf = StringBuffer();
    int count = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      buf.write(s[i]);
      count++;
      if (count % 3 == 0 && i != 0) buf.write('.');
    }
    return 'Rp ${buf.toString().split('').reversed.join()}';
  }

  Map<String, dynamic>? _activeOrder() {
    for (final o in _orders) {
      final s = (o['status'] ?? '').toString();
      if (s.isEmpty) continue;
      if (s == 'SELESAI' || s == 'DIBATALKAN') continue;
      return o;
    }
    return null;
  }

  int? _int(dynamic v) => (v is int) ? v : int.tryParse('$v');

  Map<String, dynamic> _serviceFromOrder(Map<String, dynamic> order) {
    final s = order['service'];
    if (s is Map) return Map<String, dynamic>.from(s);
    return const <String, dynamic>{};
  }

  Future<void> _openActiveDetail(BuildContext context, Map<String, dynamic> o) async {
    final id = _int(o['id']);
    if (id == null) {
      widget.onOpenActiveOrderDetail();
      return;
    }
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => OrderDetailScreen(orderId: id)),
    );
  }

  Future<void> _openActiveChat(BuildContext context, Map<String, dynamic> o) async {
    final id = _int(o['id']);
    final code = (o['order_code'] ?? '').toString();
    if (id == null || code.isEmpty) {
      widget.onOpenActiveOrderChat();
      return;
    }
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => OrderChatScreen(orderId: id, orderCode: code)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    final active = _activeOrder();

    return RefreshIndicator(
      color: cs.secondary,
      backgroundColor: _opa(cs.surface, 0.97),
      onRefresh: _refresh,
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                ValueListenableBuilder<CustomerProfile?>(
                  valueListenable: CustomerProfileSession.instance.profile,
                  builder: (_, p, __) {
                    return _HeaderCard(
                      profile: p,
                      loading: CustomerProfileSession.instance.loading.value,
                      onOpenProfile: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const ProfileScreen()),
                        );
                      },
                      onCreateOrder: widget.onCreateOrder,
                    );
                  },
                ),
                const SizedBox(height: 12),

                if (_error != null)
                  _ErrorBanner(message: _error!, onRetry: () => _loadAll()),

                _SectionTitle(
                  title: 'Pesanan Aktif',
                  actionText: 'Lihat riwayat',
                  onAction: widget.onOpenOrders,
                ),
                const SizedBox(height: 10),

                if (_loading)
                  const _SkeletonActiveOrder()
                else if (active == null)
                  _EmptyActiveOrder(onCreateOrder: widget.onCreateOrder)
                else
                  _ActiveOrderCard(
                    order: active,
                    statusLabel: _statusLabel((active['status'] ?? '').toString()),
                    statusHint: _statusHint((active['status'] ?? '').toString()),
                    service: _serviceFromOrder(active),
                    money: _fmtRupiah,
                    onOpenDetail: () => _openActiveDetail(context, active),
                    onOpenChat: () => _openActiveChat(context, active),
                  ),

                const SizedBox(height: 16),

                _SectionTitle(title: 'Aksi Cepat'),
                const SizedBox(height: 10),
                _QuickActionsGrid(
                  hasActive: active != null,
                  activeStatus: (active?['status'] ?? '').toString(),
                  onCreateOrder: widget.onCreateOrder,
                  onOrders: widget.onOpenOrders,
                  onServices: widget.onOpenServices,
                  onSupport: widget.onOpenSupport,
                  onPay: active == null
                      ? null
                      : () => _openActiveDetail(context, active),
                ),

                const SizedBox(height: 16),

                _SectionTitle(
                  title: 'Layanan Populer',
                  actionText: 'Semua layanan',
                  onAction: widget.onOpenServices,
                ),
                const SizedBox(height: 10),
                if (_loading)
                  const _SkeletonServices()
                else
                  _ServicesCarousel(
                    services: _services,
                    unitPriceOf: _extractUnitPrice,
                    money: _fmtRupiah,
                    onTapService: widget.onOpenServices,
                    onTapOrder: widget.onCreateOrder,
                  ),

                const SizedBox(height: 16),

                _SectionTitle(title: 'Tips'),
                const SizedBox(height: 10),
                _TipsCard(
                  tips: const [
                    'Pastikan alamat pickup jelas supaya kurir cepat menemukan lokasi.',
                    'Foto bukti bayar harus jelas (tidak blur) agar verifikasi cepat.',
                    'Gunakan chat di detail pesanan kalau ada permintaan khusus.',
                  ],
                ),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _HeaderCard extends StatelessWidget {
  final CustomerProfile? profile;
  final bool loading;
  final VoidCallback onOpenProfile;
  final VoidCallback onCreateOrder;

  const _HeaderCard({
    required this.profile,
    required this.loading,
    required this.onOpenProfile,
    required this.onCreateOrder,
  });

  static Color _opa(Color c, double o) =>
      c.withAlpha((o * 255).round().clamp(0, 255));

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final p = profile;
    final first = p?.firstName ?? '';
    final hello = first.isEmpty ? 'Halo 👋' : 'Halo, $first 👋';
    final addr = (p?.defaultAddress ?? '').trim();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        hello,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          color: cs.onSurface,
                        ),
                      ),
                      if (loading) ...[
                        const SizedBox(width: 10),
                        SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: cs.secondary,
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    addr.isEmpty
                        ? 'Tambahkan alamat default untuk pickup lebih cepat.'
                        : 'Pickup default: $addr',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12.5,
                      color: _opa(cs.onSurface, 0.72),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: onCreateOrder,
                          icon: const Icon(Icons.add_rounded),
                          label: const Text('Buat Pesanan'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      IconButton.filledTonal(
                        onPressed: onOpenProfile,
                        icon: const Icon(Icons.person_outline_rounded),
                        tooltip: 'Profil',
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: cs.secondary.withAlpha(22),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Center(
                child: Image.asset(
                  'assets/icons/wash.png',
                  width: 40,
                  height: 40,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorBanner extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const _ErrorBanner({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: cs.error.withAlpha(16),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: cs.error.withAlpha(55)),
        ),
        child: Row(
          children: [
            Icon(Icons.wifi_off_rounded, color: cs.error),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                message,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: cs.error, fontWeight: FontWeight.w800),
              ),
            ),
            const SizedBox(width: 10),
            TextButton(onPressed: onRetry, child: const Text('Coba lagi')),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final String? actionText;
  final VoidCallback? onAction;

  const _SectionTitle({
    required this.title,
    this.actionText,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Row(
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w900,
            color: cs.onSurface,
          ),
        ),
        const Spacer(),
        if (actionText != null && onAction != null)
          TextButton(
            onPressed: onAction,
            child: Text(actionText!),
          ),
      ],
    );
  }
}

class _EmptyActiveOrder extends StatelessWidget {
  final VoidCallback onCreateOrder;
  const _EmptyActiveOrder({required this.onCreateOrder});

  static Color _opa(Color c, double o) =>
      c.withAlpha((o * 255).round().clamp(0, 255));

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: cs.secondary.withAlpha(22),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Icon(Icons.inbox_outlined, color: cs.secondary),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Belum ada pesanan aktif',
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        color: cs.onSurface,
                      )),
                  const SizedBox(height: 4),
                  Text(
                    'Buat pesanan baru untuk jadwalkan pickup.',
                    style: TextStyle(
                      color: _opa(cs.onSurface, 0.70),
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            FilledButton(
              onPressed: onCreateOrder,
              child: const Text('Buat'),
            )
          ],
        ),
      ),
    );
  }
}

class _ActiveOrderCard extends StatelessWidget {
  final Map<String, dynamic> order;
  final Map<String, dynamic> service;
  final String statusLabel;
  final String statusHint;
  final String Function(num) money;
  final VoidCallback onOpenDetail;
  final VoidCallback onOpenChat;

  const _ActiveOrderCard({
    required this.order,
    required this.service,
    required this.statusLabel,
    required this.statusHint,
    required this.money,
    required this.onOpenDetail,
    required this.onOpenChat,
  });

  static Color _opa(Color c, double o) =>
      c.withAlpha((o * 255).round().clamp(0, 255));

  num? _numFrom(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    final code = (order['order_code'] ?? '-').toString();
    final serviceName = (service['name'] ?? 'Layanan').toString();
    final status = (order['status'] ?? '').toString();

    final estimatedQty = double.tryParse('${order['estimated_qty'] ?? ''}') ?? 0;
    final basePrice = _numFrom(order['base_price']) ?? _numFrom(service['base_price']) ?? 0;
    final estimatedTotal = (estimatedQty > 0 && basePrice > 0)
        ? (estimatedQty * basePrice).round()
        : null;

    final unitLabel = (service['unit_label'] ?? service['unit'] ?? '').toString();

    final needPay = status == 'SELESAI_MENUNGGU_PEMBAYARAN' || status == 'PEMBAYARAN_DITOLAK';

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    serviceName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 15,
                      color: cs.onSurface,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: needPay ? cs.error.withAlpha(16) : cs.secondary.withAlpha(18),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(
                      color: needPay ? cs.error.withAlpha(60) : cs.secondary.withAlpha(50),
                    ),
                  ),
                  child: Text(
                    statusLabel,
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 12,
                      color: needPay ? cs.error : cs.onSurface,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              code,
              style: TextStyle(
                color: _opa(cs.onSurface, 0.70),
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 10),
            _MiniProgress(status: status),
            const SizedBox(height: 10),
            Text(
              statusHint,
              style: TextStyle(
                fontSize: 12.5,
                color: _opa(cs.onSurface, 0.70),
                fontWeight: FontWeight.w600,
              ),
            ),
            if (estimatedTotal != null) ...[
              const SizedBox(height: 10),
              Row(
                children: [
                  Icon(Icons.payments_outlined, color: _opa(cs.onSurface, 0.65), size: 18),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'Estimasi: ${money(estimatedTotal)}'
                      '${unitLabel.isNotEmpty ? ' (± ${estimatedQty.toStringAsFixed(2)} $unitLabel)' : ''}',
                      style: TextStyle(
                        color: _opa(cs.onSurface, 0.72),
                        fontWeight: FontWeight.w700,
                        fontSize: 12.5,
                      ),
                    ),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: onOpenDetail,
                    icon: const Icon(Icons.receipt_long_outlined),
                    label: Text(needPay ? 'Bayar / Detail' : 'Detail'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: onOpenChat,
                    icon: const Icon(Icons.chat_bubble_outline_rounded),
                    label: const Text('Chat'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MiniProgress extends StatelessWidget {
  final String status;
  const _MiniProgress({required this.status});

  static const List<String> flow = [
    'MENUNGGU_KONFIRMASI',
    'DIPROSES',
    'SELESAI_MENUNGGU_PEMBAYARAN',
    'MENUNGGU_VERIFIKASI_PEMBAYARAN',
    'LUNAS_SIAP_DIANTAR',
    'DIANTAR',
    'SELESAI',
  ];

  int _idx(String s) {
    if (s == 'PEMBAYARAN_DITOLAK') {
      return flow.indexOf('MENUNGGU_VERIFIKASI_PEMBAYARAN');
    }
    final i = flow.indexOf(s);
    return i < 0 ? 0 : i;
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final i = _idx(status);

    return Row(
      children: List.generate(flow.length, (x) {
        final done = x <= i;
        final isLast = x == flow.length - 1;
        return Expanded(
          child: Row(
            children: [
              Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: done ? cs.secondary : cs.onSurface.withAlpha(46),
                  shape: BoxShape.circle,
                ),
              ),
              if (!isLast)
                Expanded(
                  child: Container(
                    height: 3,
                    margin: const EdgeInsets.symmetric(horizontal: 6),
                    decoration: BoxDecoration(
                      color: done ? cs.secondary.withAlpha(120) : cs.onSurface.withAlpha(28),
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                ),
            ],
          ),
        );
      }),
    );
  }
}

class _QuickActionsGrid extends StatelessWidget {
  final bool hasActive;
  final String activeStatus;
  final VoidCallback onCreateOrder;
  final VoidCallback onOrders;
  final VoidCallback onServices;
  final VoidCallback onSupport;
  final VoidCallback? onPay;

  const _QuickActionsGrid({
    required this.hasActive,
    required this.activeStatus,
    required this.onCreateOrder,
    required this.onOrders,
    required this.onServices,
    required this.onSupport,
    required this.onPay,
  });

  bool get _needPay =>
      activeStatus == 'SELESAI_MENUNGGU_PEMBAYARAN' || activeStatus == 'PEMBAYARAN_DITOLAK';

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _QuickActionTile(
                icon: Icons.add_circle_outline_rounded,
                title: 'Buat Pesanan',
                subtitle: 'Jadwalkan pickup',
                onTap: onCreateOrder,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _QuickActionTile(
                icon: Icons.receipt_long_rounded,
                title: 'Lacak',
                subtitle: 'Riwayat pesanan',
                onTap: onOrders,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _QuickActionTile(
                icon: Icons.local_laundry_service_rounded,
                title: 'Cek Harga',
                subtitle: 'Layanan & tarif',
                onTap: onServices,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _QuickActionTile(
                icon: Icons.payment_rounded,
                title: 'Pembayaran',
                subtitle: hasActive
                    ? (_needPay ? 'Perlu aksi' : 'Cek status')
                    : 'Tidak ada',
                onTap: hasActive ? onPay : null,
                danger: hasActive && _needPay,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: onSupport,
            icon: const Icon(Icons.support_agent_rounded),
            label: const Text('Bantuan / Hubungi Admin'),
          ),
        ),
      ],
    );
  }
}

class _QuickActionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;
  final bool danger;

  const _QuickActionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.danger = false,
  });

  static Color _opa(Color c, double o) =>
      c.withAlpha((o * 255).round().clamp(0, 255));

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final enabled = onTap != null;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Ink(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: cs.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.black.withAlpha(14)),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: danger
                    ? cs.error.withAlpha(18)
                    : cs.primary.withAlpha(16),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Icon(
                icon,
                color: danger ? cs.error : cs.primary,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      color: enabled ? cs.onSurface : _opa(cs.onSurface, 0.55),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: enabled
                          ? _opa(cs.onSurface, 0.65)
                          : _opa(cs.onSurface, 0.45),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ServicesCarousel extends StatelessWidget {
  final List<Map<String, dynamic>> services;
  final num? Function(Map<String, dynamic>) unitPriceOf;
  final String Function(num) money;
  final VoidCallback onTapService;
  final VoidCallback onTapOrder;

  const _ServicesCarousel({
    required this.services,
    required this.unitPriceOf,
    required this.money,
    required this.onTapService,
    required this.onTapOrder,
  });

  static Color _opa(Color c, double o) =>
      c.withAlpha((o * 255).round().clamp(0, 255));

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    final list = services.isEmpty ? const <Map<String, dynamic>>[] : services;
    final items = list.take(10).toList(growable: false);

    if (items.isEmpty) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Icon(Icons.local_laundry_service_outlined, color: _opa(cs.onSurface, 0.55)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Belum ada layanan tersedia.',
                  style: TextStyle(color: _opa(cs.onSurface, 0.70), fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return SizedBox(
      height: 140,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, i) {
          final s = items[i];
          final name = (s['name'] ?? '-').toString();
          final unitLabel = (s['unit_label'] ?? s['unit'] ?? '').toString();
          final price = unitPriceOf(s);

          return SizedBox(
            width: 220,
            child: InkWell(
              onTap: onTapService,
              borderRadius: BorderRadius.circular(20),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 42,
                            height: 42,
                            decoration: BoxDecoration(
                              color: cs.secondary.withAlpha(22),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Icon(Icons.local_laundry_service_rounded, color: cs.secondary),
                          ),
                          const Spacer(),
                          Icon(Icons.chevron_right_rounded, color: _opa(cs.onSurface, 0.45)),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontWeight: FontWeight.w900, color: cs.onSurface),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        price == null
                            ? 'Harga belum tersedia'
                            : '${money(price)}${unitLabel.isNotEmpty ? ' / $unitLabel' : ''}',
                        style: TextStyle(color: _opa(cs.onSurface, 0.70), fontWeight: FontWeight.w700),
                      ),
                      const Spacer(),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.tonal(
                          onPressed: onTapOrder,
                          child: const Text('Pesan'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _TipsCard extends StatelessWidget {
  final List<String> tips;
  const _TipsCard({required this.tips});

  static Color _opa(Color c, double o) =>
      c.withAlpha((o * 255).round().clamp(0, 255));

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            for (int i = 0; i < tips.length; i++) ...[
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      color: cs.primary.withAlpha(14),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(Icons.check_rounded, size: 16, color: cs.primary),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      tips[i],
                      style: TextStyle(
                        color: _opa(cs.onSurface, 0.72),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
              if (i != tips.length - 1) const SizedBox(height: 10),
            ]
          ],
        ),
      ),
    );
  }
}

class _SkeletonActiveOrder extends StatelessWidget {
  const _SkeletonActiveOrder();

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            _SkBar(width: 160, cs: cs),
            const SizedBox(height: 10),
            _SkBar(width: double.infinity, cs: cs),
            const SizedBox(height: 8),
            _SkBar(width: 220, cs: cs),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _SkBar(width: double.infinity, cs: cs, height: 42)),
                const SizedBox(width: 10),
                Expanded(child: _SkBar(width: double.infinity, cs: cs, height: 42)),
              ],
            )
          ],
        ),
      ),
    );
  }
}

class _SkeletonServices extends StatelessWidget {
  const _SkeletonServices();

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return SizedBox(
      height: 140,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: 3,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, __) => SizedBox(
          width: 220,
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _SkBar(width: 100, cs: cs),
                  const SizedBox(height: 10),
                  _SkBar(width: double.infinity, cs: cs),
                  const Spacer(),
                  _SkBar(width: double.infinity, cs: cs, height: 38),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _SkBar extends StatelessWidget {
  final double width;
  final double height;
  final ColorScheme cs;

  const _SkBar({required this.width, required this.cs, this.height = 14});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width.isInfinite ? double.infinity : width,
      height: height,
      decoration: BoxDecoration(
        color: cs.onSurface.withAlpha(18),
        borderRadius: BorderRadius.circular(999),
      ),
    );
  }
}
