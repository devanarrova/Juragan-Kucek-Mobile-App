import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import '../../core/auth/auth_session.dart';
import '../../core/network/api_service.dart';
import '../../core/notifications/customer_notification_session.dart';
import '../chat/order_chat_screen.dart';
import '../orders/order_detail_screen.dart';
import '../payments/payment_screen.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen>
    with SingleTickerProviderStateMixin {
  final ApiService _api = ApiService();

  bool _loading = true;
  String? _error;
  Map<int, String> _orderCodeById = const {};

  DateTime? _lastToastAt;
  late final TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _tab.addListener(_onTabChanged);
    _refreshAll(initial: true);
  }

  @override
  void dispose() {
    _tab.removeListener(_onTabChanged);
    _tab.dispose();
    super.dispose();
  }

  void _onTabChanged() {
    if (_tab.indexIsChanging) return;
    if (_tab.index == 1) {
      // Tab Pembayaran: refresh events lalu mark read agar badge turun.
      unawaited(_openEventsTab());
    }
  }

  Future<void> _openEventsTab() async {
    try {
      await CustomerNotificationSession.instance.refreshEvents(limit: 60);
      await CustomerNotificationSession.instance.markEventsReadAll();
      await CustomerNotificationSession.instance.refreshAll();
    } catch (_) {
      // silent
    }
  }

  Future<void> _openPaymentDeepLink(OrderEventNotif ev) async {
    if (!mounted) return;

    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    Map<String, dynamic>? order;
    try {
      final token = AuthSession.tokenOrEmpty;
      final res = await _api
          .get('/orders/${ev.orderId}', bearer: token)
          .timeout(const Duration(seconds: 20));

      order = res is Map ? Map<String, dynamic>.from(res) : null;
    } catch (e) {
      if (mounted) {
        Navigator.of(context, rootNavigator: true).pop();
        _toast(_friendlyError(e));
      }
      return;
    }

    if (!mounted) return;
    Navigator.of(context, rootNavigator: true).pop();

    if (order == null) {
      _toast('Gagal memuat detail pesanan.');
      return;
    }

    final orderCode =
        (order['order_code'] ?? order['code'] ?? 'Pesanan #${ev.orderId}')
            .toString();

    final totalAmount =
        (double.tryParse('${order['total_price'] ?? 0}') ?? 0).round();

    if (totalAmount <= 0) {
      _toast('Tagihan final belum tersedia. Coba cek Detail Pesanan dulu.');
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => OrderDetailScreen(orderId: ev.orderId),
        ),
      );
      return;
    }

    final allowReupload = ev.status == 'REJECTED';

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => PaymentScreen(
          orderId: ev.orderId,
          orderCode: orderCode,
          totalAmount: totalAmount,
          allowReupload: allowReupload,
        ),
      ),
    );
  }

  void _toast(String msg) {
    if (!mounted) return;

    final now = DateTime.now();
    if (_lastToastAt != null && now.difference(_lastToastAt!).inSeconds < 10) {
      return;
    }
    _lastToastAt = now;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg)),
    );
  }

  String _friendlyError(Object e) {
    if (e is TimeoutException) return 'Koneksi lambat (timeout). Coba lagi.';
    if (e is SocketException) return 'Tidak ada koneksi internet.';
    final s = e.toString();
    if (s.contains('401')) return 'Sesi kamu habis. Silakan login ulang.';
    return s;
  }

  Future<void> _refreshAll({bool initial = false}) async {
    if (initial) {
      setState(() {
        _loading = true;
        _error = null;
      });
    } else {
      setState(() => _error = null);
    }

    try {
      await CustomerNotificationSession.instance.refreshAll();
      await CustomerNotificationSession.instance.refreshEvents(limit: 60);

      final token = AuthSession.tokenOrEmpty;
      final res = await _api
          .get('/orders', bearer: token)
          .timeout(const Duration(seconds: 20));

      final list = (res is List) ? res : <dynamic>[];
      final map = <int, String>{};
      for (final x in list) {
        if (x is Map) {
          final m = Map<String, dynamic>.from(x);
          final id = int.tryParse('${m['id']}') ?? 0;
          final code = (m['order_code'] ?? '').toString();
          if (id > 0 && code.trim().isNotEmpty) map[id] = code;
        }
      }

      if (!mounted) return;
      setState(() {
        _orderCodeById = map;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = _friendlyError(e);
      });
      if (!initial) _toast(_friendlyError(e));
    }
  }

  String _month(int m) {
    switch (m) {
      case 1:
        return 'Jan';
      case 2:
        return 'Feb';
      case 3:
        return 'Mar';
      case 4:
        return 'Apr';
      case 5:
        return 'Mei';
      case 6:
        return 'Jun';
      case 7:
        return 'Jul';
      case 8:
        return 'Agu';
      case 9:
        return 'Sep';
      case 10:
        return 'Okt';
      case 11:
        return 'Nov';
      case 12:
        return 'Des';
      default:
        return '';
    }
  }

  String _fmt(DateTime? dt) {
    if (dt == null) return '';
    final d = dt.toLocal();
    final dd = d.day.toString().padLeft(2, '0');
    final hh = d.hour.toString().padLeft(2, '0');
    final mm = d.minute.toString().padLeft(2, '0');
    return '$dd ${_month(d.month)} ${d.year} $hh:$mm';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifikasi'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(44),
          child: ValueListenableBuilder<NotificationSummary>(
            valueListenable: CustomerNotificationSession.instance.summary,
            builder: (_, s, __) {
              return TabBar(
                controller: _tab,
                tabs: [
                  _TabWithBadge(label: 'Chat', count: s.unreadMessages),
                  _TabWithBadge(label: 'Pembayaran', count: s.unreadEvents),
                ],
              );
            },
          ),
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: () => _refreshAll(initial: true),
            icon: const Icon(Icons.refresh),
          ),
          PopupMenuButton<String>(
            tooltip: 'Menu',
            onSelected: (v) async {
              if (v == 'clear_payments') {
                final ok = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Hapus semua notifikasi pembayaran?'),
                    content: const Text(
                      'Ini hanya menghapus dari daftar notifikasi kamu (tidak menghapus data pembayaran).',
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: const Text('Batal'),
                      ),
                      FilledButton(
                        onPressed: () => Navigator.pop(ctx, true),
                        child: const Text('Hapus'),
                      ),
                    ],
                  ),
                );

                if (ok == true) {
                  final ok2 = await CustomerNotificationSession.instance
                      .clearPaymentEvents();
                  if (!ok2) {
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content:
                              Text('Gagal menghapus notifikasi pembayaran.')),
                    );
                    return;
                  }
                  if (!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                        content: Text('Notifikasi pembayaran dibersihkan.')),
                  );
                }
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(
                value: 'clear_payments',
                child: Text('Hapus semua notifikasi pembayaran'),
              ),
            ],
          ),
        ],
      ),
      body: _loading
          ? Center(child: CircularProgressIndicator(color: cs.primary))
          : TabBarView(
              controller: _tab,
              children: [
                _buildChatTab(context),
                _buildEventTab(context),
              ],
            ),
    );
  }

  Widget _buildChatTab(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return ValueListenableBuilder<NotificationSummary>(
      valueListenable: CustomerNotificationSession.instance.summary,
      builder: (_, s, __) {
        final unreadTotal = s.unreadMessages;
        return ValueListenableBuilder<Map<int, int>>(
          valueListenable: CustomerNotificationSession.instance.unreadByOrder,
          builder: (_, map, __) {
            final items =
                map.entries.where((e) => e.key > 0 && e.value > 0).toList();

            items.sort((a, b) {
              final c = b.value.compareTo(a.value);
              if (c != 0) return c;
              return b.key.compareTo(a.key);
            });

            return RefreshIndicator(
              onRefresh: () => _refreshAll(initial: false),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: cs.primary.withAlpha(14),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: cs.primary.withAlpha(40)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.chat_bubble_outline, color: cs.primary),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            unreadTotal > 0
                                ? 'Kamu punya $unreadTotal pesan baru dari admin.'
                                : 'Tidak ada pesan baru dari admin.',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (_error != null) _ErrorBox(message: _error!),
                  if (_error != null) const SizedBox(height: 12),
                  if (items.isEmpty) ...[
                    const SizedBox(height: 60),
                    Center(
                      child: Text(
                        'Belum ada notifikasi chat.',
                        style: TextStyle(
                          color: cs.onSurface.withAlpha(160),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ] else ...[
                    Text(
                      'Pesanan dengan pesan baru',
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        color: cs.onSurface,
                      ),
                    ),
                    const SizedBox(height: 10),
                    for (final e in items)
                      Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: ListTile(
                          leading: const Icon(Icons.chat_bubble_outline),
                          title: Text(
                            _orderCodeById[e.key] ?? 'Pesanan #${e.key}',
                            style: const TextStyle(fontWeight: FontWeight.w900),
                          ),
                          subtitle: const Text('Ketuk untuk buka chat'),
                          trailing: _NotifBadge(count: e.value),
                          onTap: () {
                            final code =
                                _orderCodeById[e.key] ?? 'Pesanan #${e.key}';
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => OrderChatScreen(
                                  orderId: e.key,
                                  orderCode: code,
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                  ],
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildEventTab(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return ValueListenableBuilder<NotificationSummary>(
      valueListenable: CustomerNotificationSession.instance.summary,
      builder: (_, s, __) {
        final unreadTotal = s.unreadEvents;
        return ValueListenableBuilder<List<OrderEventNotif>>(
          valueListenable: CustomerNotificationSession.instance.events,
          builder: (_, list, __) {
            final events = List<OrderEventNotif>.from(list);

            return RefreshIndicator(
              onRefresh: () => _refreshAll(initial: false),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: cs.secondary.withAlpha(14),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: cs.secondary.withAlpha(40)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.payments_outlined, color: cs.secondary),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            unreadTotal > 0
                                ? 'Ada $unreadTotal update pembayaran.'
                                : 'Tidak ada update pembayaran baru.',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (_error != null) _ErrorBox(message: _error!),
                  if (_error != null) const SizedBox(height: 12),
                  if (events.isEmpty) ...[
                    const SizedBox(height: 60),
                    Center(
                      child: Text(
                        'Belum ada event pembayaran.',
                        style: TextStyle(
                          color: cs.onSurface.withAlpha(160),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ] else ...[
                    Text(
                      'Update pembayaran terbaru',
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        color: cs.onSurface,
                      ),
                    ),
                    const SizedBox(height: 10),
                    for (final ev in events)
                      Dismissible(
                        key: ValueKey('payment-event-${ev.id}'),
                        direction: DismissDirection.endToStart,
                        background: Container(
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.symmetric(horizontal: 18),
                          decoration: BoxDecoration(
                            color: cs.error.withAlpha(18),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Icon(Icons.delete_outline, color: cs.error),
                        ),
                        confirmDismiss: (_) async {
                          final confirm = await showDialog<bool>(
                            context: context,
                            builder: (ctx) => AlertDialog(
                              title: const Text('Hapus notifikasi?'),
                              content: const Text(
                                'Ini hanya menghapus dari daftar notifikasi kamu, tidak menghapus data pembayaran.',
                              ),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(ctx, false),
                                  child: const Text('Batal'),
                                ),
                                FilledButton(
                                  onPressed: () => Navigator.pop(ctx, true),
                                  child: const Text('Hapus'),
                                ),
                              ],
                            ),
                          );

                          if (confirm != true) return false;

                          final ok = await CustomerNotificationSession.instance
                              .deletePaymentEvent(ev.id);
                          if (!ok) {
                            if (!mounted) return false;
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                  content: Text('Gagal menghapus notifikasi.')),
                            );
                            return false;
                          }

                          if (!mounted) return true;
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                                content: Text('Notifikasi dihapus.')),
                          );
                          return true;
                        },
                        child: Card(
                          margin: const EdgeInsets.only(bottom: 10),
                          child: ListTile(
                            leading: _EventIcon(status: ev.status),
                            title: Text(
                              ev.title,
                              style:
                                  const TextStyle(fontWeight: FontWeight.w900),
                            ),
                            subtitle: Text(
                              '${(ev.message).trim().isEmpty ? '-' : ev.message}\n${_orderCodeById[ev.orderId] ?? 'Pesanan #${ev.orderId}'} • ${_fmt(ev.createdAt)}',
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                            ),
                            trailing: ev.isUnread
                                ? Container(
                                    width: 10,
                                    height: 10,
                                    decoration: BoxDecoration(
                                      color: cs.error,
                                      shape: BoxShape.circle,
                                    ),
                                  )
                                : const SizedBox(width: 10),
                            onTap: () {
                              if (ev.status == 'REJECTED') {
                                unawaited(_openPaymentDeepLink(ev));
                                return;
                              }
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) =>
                                      OrderDetailScreen(orderId: ev.orderId),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                  ],
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _ErrorBox extends StatelessWidget {
  final String message;

  const _ErrorBox({required this.message});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cs.error.withAlpha(18),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: cs.error.withAlpha(50)),
      ),
      child: Text(
        message,
        style: TextStyle(
          color: cs.error,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _EventIcon extends StatelessWidget {
  final String status;

  const _EventIcon({required this.status});

  @override
  Widget build(BuildContext context) {
    switch (status) {
      case 'APPROVED':
        return const Icon(Icons.check_circle_rounded);
      case 'REJECTED':
        return const Icon(Icons.error_outline_rounded);
      default:
        return const Icon(Icons.info_outline_rounded);
    }
  }
}

class _NotifBadge extends StatelessWidget {
  final int count;

  const _NotifBadge({required this.count});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final text = count > 99 ? '99+' : count.toString();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: cs.error,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: cs.onError,
          fontSize: 12,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}

class _TabWithBadge extends StatelessWidget {
  final String label;
  final int count;

  const _TabWithBadge({required this.label, required this.count});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Tab(
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
          if (count > 0) ...[
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: cs.error,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                count > 99 ? '99+' : count.toString(),
                style: TextStyle(
                  color: cs.onError,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
