import 'package:flutter/material.dart';

import '../../core/auth/auth_session.dart';
import '../../core/network/api_service.dart';

class OrderCreateScreen extends StatefulWidget {
  /// callback pindah tab (dipakai MainShell)
  final void Function(int index)? onSwitchTab;

  const OrderCreateScreen({super.key, this.onSwitchTab});

  @override
  State<OrderCreateScreen> createState() => _OrderCreateScreenState();
}

class _OrderCreateScreenState extends State<OrderCreateScreen> {
  final _api = ApiService();

  bool _loadingServices = true;
  bool _submitting = false;
  String? _error;

  List<Map<String, dynamic>> _services = [];
  int? _serviceId;

  final _qtyC = TextEditingController(text: '1');
  final _addrC = TextEditingController();
  final _noteC = TextEditingController();
  DateTime? _pickupDate;

  @override
  void initState() {
    super.initState();
    _loadServices();
  }

  @override
  void dispose() {
    _qtyC.dispose();
    _addrC.dispose();
    _noteC.dispose();
    super.dispose();
  }

  Future<void> _loadServices() async {
    setState(() {
      _loadingServices = true;
      _error = null;
    });

    try {
      final res = await _api.get('/services');
      final list = res is List ? res : <dynamic>[];

      final items = <Map<String, dynamic>>[];
      for (final x in list) {
        if (x is Map) items.add(Map<String, dynamic>.from(x));
      }

      if (!mounted) return;
      setState(() {
        _services = items;
        _serviceId =
            items.isNotEmpty ? int.tryParse('${items.first['id']}') : null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loadingServices = false);
    }
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _pickupDate ?? now,
      firstDate: now,
      lastDate: now.add(const Duration(days: 30)),
    );
    if (picked == null) return;
    setState(() => _pickupDate = picked);
  }

  String _fmtDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  double? _tryParseQty() {
    return double.tryParse(_qtyC.text.trim().replaceAll(',', '.'));
  }

  Map<String, dynamic>? _selectedService() {
    final sid = _serviceId;
    if (sid == null) return null;
    for (final s in _services) {
      final id = int.tryParse('${s['id']}');
      if (id == sid) return s;
    }
    return null;
  }

  num? _numFrom(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }

  /// Ambil harga satuan dari object service dengan berbagai kemungkinan key.
  num? _extractUnitPrice(Map<String, dynamic>? service) {
    if (service == null) return null;

    const keys = [
      'price',
      'price_per_kg',
      'price_per_unit',
      'unit_price',
      'rate',
      'base_price',
    ];

    for (final k in keys) {
      final n = _numFrom(service[k]);
      if (n != null && n > 0) return n;
    }
    return null;
  }

  String _fmtRupiah(num value) {
    // Tanpa intl: format ribuan pakai titik.
    final v = value.round();
    final s = v.toString();
    final buf = StringBuffer();
    int count = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      buf.write(s[i]);
      count++;
      if (count % 3 == 0 && i != 0) buf.write('.');
    }
    final formatted = buf.toString().split('').reversed.join();
    return 'Rp $formatted';
  }

  num _calcEstimateTotal({required num unitPrice, required double qty}) {
    // Estimasi total = unitPrice * qty
    // pembulatan ke rupiah terdekat.
    return (unitPrice * qty);
  }

  Future<bool> _showConfirmDialog({
    required Map<String, dynamic> service,
    required double qty,
    required DateTime pickupDate,
    required String address,
    required String? notes,
  }) async {
    final cs = Theme.of(context).colorScheme;

    final serviceName = (service['name'] ?? '-').toString();
    final unitPrice = _extractUnitPrice(service);
    final estimateTotal = unitPrice == null
        ? null
        : _calcEstimateTotal(unitPrice: unitPrice, qty: qty);

    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Konfirmasi Pesanan'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Mohon periksa kembali detail pesanan Anda. '
                  'Setelah dikirim, pesanan akan diproses oleh tim Juragan Kucek.',
                ),
                const SizedBox(height: 14),
                _kv('Layanan', serviceName),
                const SizedBox(height: 8),
                _kv('Estimasi Qty', qty.toString()),
                const SizedBox(height: 8),
                _kv('Tanggal Pickup', _fmtDate(pickupDate)),
                const SizedBox(height: 8),
                _kv('Alamat Pickup', address),
                if ((notes ?? '').trim().isNotEmpty) ...[
                  const SizedBox(height: 8),
                  _kv('Catatan', notes!.trim()),
                ],
                const Divider(height: 22),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Harga Satuan'),
                    Text(
                      unitPrice == null ? '-' : _fmtRupiah(unitPrice),
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Total Estimasi'),
                    Text(
                      estimateTotal == null ? '-' : _fmtRupiah(estimateTotal),
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  '*Harga di atas adalah estimasi. Total akhir dapat menyesuaikan kondisi aktual.',
                  style: TextStyle(
                      fontSize: 12, color: cs.onSurface.withAlpha(160)),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Ubah'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Kirim Pesanan'),
            ),
          ],
        );
      },
    );

    return ok ?? false;
  }

  Widget _kv(String k, String v) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(k, style: const TextStyle(fontSize: 12)),
        const SizedBox(height: 2),
        Text(v, style: const TextStyle(fontWeight: FontWeight.w700)),
      ],
    );
  }

  Future<void> _submit() async {
    if (_submitting) return;

    final token = AuthSession.tokenOrEmpty;
    if (token.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Kamu belum login.')),
      );
      return;
    }

    if (_serviceId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pilih layanan dulu.')),
      );
      return;
    }

    final qty = _tryParseQty();
    if (qty == null || qty <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Estimasi qty tidak valid.')),
      );
      return;
    }

    if (_pickupDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pilih tanggal pickup dulu.')),
      );
      return;
    }

    final addr = _addrC.text.trim();
    if (addr.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Alamat pickup wajib diisi.')),
      );
      return;
    }

    final service = _selectedService();
    if (service == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Data layanan tidak ditemukan. Coba refresh.')),
      );
      return;
    }

    // === Popup konfirmasi (checkpoint) ===
    final ok = await _showConfirmDialog(
      service: service,
      qty: qty,
      pickupDate: _pickupDate!,
      address: addr,
      notes: _noteC.text.trim().isEmpty ? null : _noteC.text.trim(),
    );
    if (!ok) return;

    setState(() {
      _submitting = true;
      _error = null;
    });

    try {
      final res = await _api.post(
        '/orders',
        {
          'service_id': _serviceId,
          'estimated_qty': qty,
          'pickup_date': _fmtDate(_pickupDate!),
          'pickup_address': addr,
          'notes': _noteC.text.trim().isEmpty ? null : _noteC.text.trim(),
        },
        bearer: token,
      );

      if (!mounted) return;

      final map =
          res is Map ? Map<String, dynamic>.from(res) : <String, dynamic>{};
      final code = (map['order_code'] ?? '').toString();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content:
              Text('Pesanan berhasil dibuat ${code.isEmpty ? '' : '($code)'}'),
        ),
      );

      // pindah ke tab Riwayat (index 3)
      widget.onSwitchTab?.call(3);

      // reset form
      setState(() {
        _qtyC.text = '1';
        _addrC.clear();
        _noteC.clear();
        _pickupDate = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    if (_loadingServices) {
      return Center(child: CircularProgressIndicator(color: cs.primary));
    }

    final service = _selectedService();
    final unitPrice = _extractUnitPrice(service);
    final qty = _tryParseQty();
    final estimateTotal = (unitPrice != null && qty != null && qty > 0)
        ? _calcEstimateTotal(unitPrice: unitPrice, qty: qty)
        : null;

    return RefreshIndicator(
      onRefresh: _loadServices,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          Row(
            children: [
              const Text(
                'Buat Pesanan',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
              const Spacer(),
              IconButton(
                onPressed: _loadServices,
                icon: const Icon(Icons.refresh),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_error != null) ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: cs.error.withAlpha(18),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: cs.error.withAlpha(60)),
              ),
              child: Text(
                _error!,
                style: TextStyle(color: cs.error, fontWeight: FontWeight.w700),
              ),
            ),
            const SizedBox(height: 12),
          ],
          DropdownButtonFormField<int>(
            key: ValueKey(_serviceId),
            initialValue: _serviceId,
            items: _services.map((s) {
              final id = int.tryParse('${s['id']}') ?? 0;
              final name = (s['name'] ?? '-').toString();
              return DropdownMenuItem<int>(value: id, child: Text(name));
            }).toList(),
            onChanged: (v) => setState(() => _serviceId = v),
            decoration: InputDecoration(
              labelText: 'Layanan',
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _qtyC,
            onChanged: (_) => setState(() {}),
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
              labelText: 'Estimasi Qty',
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
          const SizedBox(height: 12),
          InkWell(
            onTap: _pickDate,
            borderRadius: BorderRadius.circular(14),
            child: InputDecorator(
              decoration: InputDecoration(
                labelText: 'Tanggal Pickup',
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: Text(_pickupDate == null
                  ? 'Pilih tanggal'
                  : _fmtDate(_pickupDate!)),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _addrC,
            minLines: 2,
            maxLines: 4,
            decoration: InputDecoration(
              labelText: 'Alamat Pickup',
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _noteC,
            minLines: 2,
            maxLines: 4,
            decoration: InputDecoration(
              labelText: 'Catatan (opsional)',
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),

          // === Ringkasan Estimasi (biar user kebayang sebelum popup) ===
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: cs.primary.withAlpha(10),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: cs.primary.withAlpha(35)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Ringkasan Estimasi',
                  style: TextStyle(fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Harga Satuan'),
                    Text(
                      unitPrice == null ? '-' : _fmtRupiah(unitPrice),
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Total Estimasi'),
                    Text(
                      estimateTotal == null ? '-' : _fmtRupiah(estimateTotal),
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  '*Total akhir dapat menyesuaikan kondisi aktual.',
                  style: TextStyle(
                      fontSize: 12, color: cs.onSurface.withAlpha(160)),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),
          SizedBox(
            height: 48,
            child: FilledButton.icon(
              onPressed: _submitting ? null : _submit,
              icon: _submitting
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.add),
              label: Text(_submitting ? 'Mengirim...' : 'Buat Pesanan'),
            ),
          ),
        ],
      ),
    );
  }
}
