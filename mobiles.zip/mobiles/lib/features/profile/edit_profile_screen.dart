import 'package:flutter/material.dart';

import '../../core/auth/auth_session.dart';
import '../../core/auth/customer_profile_session.dart';
import '../../core/network/api_client.dart';
import '../../core/network/api_service.dart';

class EditProfileScreen extends StatefulWidget {
  final String name;
  final String phone;
  final String defaultAddress;

  const EditProfileScreen({
    super.key,
    required this.name,
    required this.phone,
    required this.defaultAddress,
  });

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _api = ApiService();

  late final TextEditingController _name;
  late final TextEditingController _phone;
  late final TextEditingController _addr;

  bool _saving = false;
  Map<String, String> _fieldErrors = {};

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.name);
    _phone = TextEditingController(text: widget.phone);
    _addr = TextEditingController(text: widget.defaultAddress);
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _addr.dispose();
    super.dispose();
  }

  Map<String, String> _extractFieldErrors(ApiHttpException e) {
    final d = e.decodedBody;
    if (e.statusCode != 422) return {};
    if (d is! Map) return {};
    final errs = d['errors'];
    if (errs is! Map) return {};

    final out = <String, String>{};
    for (final entry in errs.entries) {
      final k = entry.key.toString();
      final v = entry.value;
      if (v is List && v.isNotEmpty) {
        out[k] = v.first.toString();
      } else if (v != null) {
        out[k] = v.toString();
      }
    }
    return out;
  }

  Future<void> _submit() async {
    final name = _name.text.trim();
    final phone = _phone.text.trim();
    final addr = _addr.text.trim();

    // validasi ringan di client (biar UX enak), backend tetap sumber kebenaran.
    final localErrors = <String, String>{};
    if (name.isEmpty) localErrors['name'] = 'Nama wajib diisi.';
    if (name.isNotEmpty && name.length < 3) {
      localErrors['name'] = 'Nama minimal 3 karakter.';
    }
    if (phone.isEmpty) localErrors['phone'] = 'No HP wajib diisi.';
    if (addr.isEmpty) {
      localErrors['default_address'] = 'Alamat default wajib diisi.';
    }

    if (localErrors.isNotEmpty) {
      setState(() => _fieldErrors = localErrors);
      return;
    }

    setState(() {
      _saving = true;
      _fieldErrors = {};
    });

    try {
      final token = AuthSession.tokenOrEmpty;
      final res = await _api.put('/me', {
        'name': name,
        'phone': phone,
        'default_address': addr,
      }, bearer: token);

      // update session supaya Home/AppBar langsung ikut berubah
      CustomerProfileSession.instance.setFromResponse(res);

      if (!mounted) return;
      Navigator.of(context).pop(true);
    } on ApiHttpException catch (e) {
      // 401 auto logout lewat ApiService.
      final f = _extractFieldErrors(e);

      if (!mounted) return;
      setState(() {
        _fieldErrors = f;
        _saving = false;
      });

      // fallback snackbar (biar user tau kenapa gagal)
      final msg = f.values.isNotEmpty
          ? f.values.first
          : (e.statusCode == 422
              ? 'Data tidak valid. Periksa input kamu.'
              : e.toString());
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg)),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal update profil: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Edit Profil')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          TextField(
            controller: _name,
            textInputAction: TextInputAction.next,
            decoration: InputDecoration(
              labelText: 'Nama',
              prefixIcon: const Icon(Icons.badge_outlined),
              errorText: _fieldErrors['name'],
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            textInputAction: TextInputAction.next,
            decoration: InputDecoration(
              labelText: 'No HP',
              prefixIcon: const Icon(Icons.phone_outlined),
              errorText: _fieldErrors['phone'],
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _addr,
            maxLines: 3,
            decoration: InputDecoration(
              labelText: 'Alamat Default',
              alignLabelWithHint: true,
              prefixIcon: const Icon(Icons.location_on_outlined),
              errorText: _fieldErrors['default_address'],
            ),
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 48,
            child: ElevatedButton(
              onPressed: _saving ? null : _submit,
              style: ElevatedButton.styleFrom(
                backgroundColor: cs.primary,
                foregroundColor: cs.onPrimary,
              ),
              child: _saving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('Simpan'),
            ),
          ),
        ],
      ),
    );
  }
}
