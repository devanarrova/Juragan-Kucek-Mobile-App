import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../core/auth/auth_session.dart';
import '../../core/auth/customer_profile_session.dart';
import '../../core/network/api_client.dart';
import '../../core/network/api_service.dart';
import 'edit_profile_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _api = ApiService();
  final _picker = ImagePicker();

  bool _loading = true;
  bool _uploadingPhoto = false;
  String? _error;
  Map<String, dynamic>? _customer;

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Map<String, dynamic>? _extractCustomer(dynamic res) {
    if (res is Map) {
      final c = res['customer'];
      if (c is Map) {
        return Map<String, dynamic>.from(c);
      }
      // fallback: kalau backend return langsung object user
      return Map<String, dynamic>.from(res);
    }
    return null;
  }

  Future<void> _fetch() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final token = AuthSession.tokenOrEmpty;
      final res = await _api.get('/me', bearer: token);
      final c = _extractCustomer(res);
      if (c == null) throw Exception('Response /me tidak valid.');

      // update session biar avatar & sapaan ikut berubah
      CustomerProfileSession.instance.setFromResponse(res);

      if (!mounted) return;
      setState(() {
        _customer = c;
        _loading = false;
      });
    } on ApiHttpException catch (e) {
      // 401 akan auto-logout via ApiService.
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<void> _pickAndUploadPhoto() async {
    if (_uploadingPhoto) return;

    try {
      final picked = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 85,
      );

      if (picked == null) return;

      setState(() => _uploadingPhoto = true);

      final token = AuthSession.tokenOrEmpty;
      final res = await _api.postMultipart(
        '/me/photo',
        fields: const <String, String>{},
        files: {
          'photo': File(picked.path),
        },
        bearer: token,
      );

      CustomerProfileSession.instance.setFromResponse(res);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Foto profil berhasil diperbarui')),
      );

      await _fetch();
    } on ApiHttpException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal upload foto: $e')),
      );
    } finally {
      if (mounted) setState(() => _uploadingPhoto = false);
    }
  }

  Future<void> _deletePhoto() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Hapus foto profil?'),
        content: const Text('Foto profil kamu akan dihapus.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    try {
      setState(() => _uploadingPhoto = true);
      final token = AuthSession.tokenOrEmpty;
      final res = await _api.delete('/me/photo', bearer: token);
      CustomerProfileSession.instance.setFromResponse(res);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Foto profil dihapus')),
      );
      await _fetch();
    } on ApiHttpException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal hapus foto: $e')),
      );
    } finally {
      if (mounted) setState(() => _uploadingPhoto = false);
    }
  }

  String _s(dynamic v) => (v ?? '').toString();

  Color _opa(Color c, double opacity) =>
      c.withAlpha((opacity * 255).round().clamp(0, 255));

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    // Penting: screen ini HARUS punya Scaffold sendiri.
    // Kalau tidak, background bisa jadi gelap/aneh (terlihat seperti modal/bottom-sheet)
    // karena halaman baru tidak “ngecat” background.
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil'),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : _fetch,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: _loading
          ? Center(child: CircularProgressIndicator(color: cs.primary))
          : (_error != null)
              ? Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: cs.error.withAlpha(18),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: cs.error.withAlpha(50)),
                        ),
                        child: Text(
                          'Gagal memuat profil:\n$_error',
                          style: TextStyle(
                            color: cs.error,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        height: 44,
                        child: FilledButton.icon(
                          onPressed: _fetch,
                          icon: const Icon(Icons.refresh),
                          label: const Text('Coba Lagi'),
                        ),
                      ),
                    ],
                  ),
                )
              : _buildContent(context, cs),
    );
  }

  Widget _buildContent(BuildContext context, ColorScheme cs) {
    final c = _customer ?? const <String, dynamic>{};
    final name = _s(c['name']);
    final phone = _s(c['phone']);
    final addr = _s(c['default_address']);
    final initial = name.trim().isEmpty ? '?' : name.trim()[0].toUpperCase();
    final photoUrl = _s(c['profile_photo_url']);
    final hasPhoto = photoUrl.trim().isNotEmpty;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        Row(
          children: [
            CircleAvatar(
              radius: 26,
              backgroundColor: _opa(cs.primary, 0.14),
              foregroundImage: hasPhoto ? NetworkImage(photoUrl) : null,
              child: Text(
                initial,
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 20,
                  color: cs.primary,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name.isEmpty ? 'Nama belum diisi' : name,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: cs.onSurface,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    phone.isEmpty ? 'No HP belum diisi' : phone,
                    style: TextStyle(color: _opa(cs.onSurface, 0.70)),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _uploadingPhoto ? null : _pickAndUploadPhoto,
                icon: _uploadingPhoto
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.photo_camera_outlined),
                label: Text(_uploadingPhoto ? 'Memproses...' : 'Unggah Foto'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: (!hasPhoto || _uploadingPhoto) ? null : _deletePhoto,
                icon: const Icon(Icons.delete_outline_rounded),
                label: const Text('Hapus Foto'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Alamat Default',
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    color: cs.onSurface,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  addr.isEmpty ? 'Alamat belum diisi' : addr,
                  style: TextStyle(color: _opa(cs.onSurface, 0.80)),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  height: 46,
                  child: FilledButton.icon(
                    onPressed: () async {
                      final updated = await Navigator.of(context).push<bool>(
                        MaterialPageRoute(
                          builder: (_) => EditProfileScreen(
                            name: name,
                            phone: phone,
                            defaultAddress: addr,
                          ),
                        ),
                      );

                      if (updated == true) {
                        if (!mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Profil berhasil diperbarui'),
                          ),
                        );
                        await _fetch();
                      }
                    },
                    icon: const Icon(Icons.edit_rounded),
                    label: const Text('Edit Profil'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
