import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../core/auth/auth_session.dart';
import '../../core/config/app_config.dart';
import '../../core/network/api_client.dart';

class PaymentScreen extends StatefulWidget {
  final int orderId;
  final String orderCode;
  final int totalAmount;

  /// true kalau pembayaran sebelumnya ditolak dan boleh upload ulang.
  final bool allowReupload;

  const PaymentScreen({
    super.key,
    required this.orderId,
    required this.orderCode,
    required this.totalAmount,
    this.allowReupload = false,
  });

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  final ApiClient _client = const ApiClient(baseUrl: AppConfig.apiBaseUrl);
  final TextEditingController _noteC = TextEditingController();

  bool _loading = true;
  bool _submitting = false;
  String? _error;

  // Backend expects: BANK_TRANSFER | E_WALLET
  String _method = 'BANK_TRANSFER';
  String? _selectedChannelCode;

  List<Map<String, dynamic>> _banks = const [];
  List<Map<String, dynamic>> _ewallets = const [];

  File? _proofFile;

  @override
  void initState() {
    super.initState();
    _loadChannels();
  }

  @override
  void dispose() {
    _noteC.dispose();
    super.dispose();
  }

  String _money(int v) {
    final s = v.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      final idxFromRight = s.length - i;
      buf.write(s[i]);
      if (idxFromRight > 1 && idxFromRight % 3 == 1) buf.write('.');
    }
    return 'Rp $buf';
  }

  Future<void> _loadChannels() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final res = await _client.getJson(
        '/payment-channels',
        bearerToken: AuthSession.tokenOrEmpty,
      );

      final map = (res is Map<String, dynamic>) ? res : <String, dynamic>{};
      final banks = map['banks'];
      final ewallets = map['ewallets'];

      final b = <Map<String, dynamic>>[];
      final e = <Map<String, dynamic>>[];

      if (banks is List) {
        for (final x in banks) {
          if (x is Map) b.add(Map<String, dynamic>.from(x));
        }
      }
      if (ewallets is List) {
        for (final x in ewallets) {
          if (x is Map) e.add(Map<String, dynamic>.from(x));
        }
      }

      if (!mounted) return;
      setState(() {
        _banks = b;
        _ewallets = e;

        // auto select first channel biar gak null
        if (_selectedChannelCode == null) {
          final list = _method == 'BANK_TRANSFER' ? _banks : _ewallets;
          _selectedChannelCode =
              list.isNotEmpty ? (list.first['code']?.toString()) : null;
        }
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _pickProof() async {
    final picker = ImagePicker();
    final img = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );
    if (img == null) return;

    setState(() {
      _proofFile = File(img.path);
    });
  }

  Future<void> _submit() async {
    if (widget.totalAmount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Total tagihan belum tersedia. Hubungi admin.'),
        ),
      );
      return;
    }

    if (_selectedChannelCode == null || _selectedChannelCode!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pilih channel pembayaran dulu.')),
      );
      return;
    }

    if (_proofFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Upload bukti pembayaran dulu.')),
      );
      return;
    }

    setState(() {
      _submitting = true;
      _error = null;
    });

    try {
      final res = await _client.postMultipart(
        '/orders/${widget.orderId}/payment',
        fields: {
          'method': _method,
          'channel_code': _selectedChannelCode!,
          'amount': widget.totalAmount.toString(),
          'customer_note': _noteC.text.trim(),
        },
        files: {
          // backend expects name: proof
          'proof': _proofFile!,
        },
        bearerToken: AuthSession.tokenOrEmpty,
      );

      if (!mounted) return;

      if (res is Map && res['message'] is String) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(res['message'].toString())),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content:
                Text('Bukti pembayaran terkirim. Menunggu verifikasi admin.'),
          ),
        );
      }

      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bg = Theme.of(context).colorScheme.surface;
    final text = Theme.of(context).colorScheme.onSurface;

    final channels = _method == 'BANK_TRANSFER' ? _banks : _ewallets;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Pembayaran'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadChannels,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: bg,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white.withAlpha(18)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Order: ${widget.orderCode}',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                            color: text,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Total: ${_money(widget.totalAmount)}',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 18,
                            color: text,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          widget.allowReupload
                              ? 'Pembayaran sebelumnya ditolak. Silakan upload ulang bukti.'
                              : 'Upload bukti pembayaran untuk diverifikasi admin.',
                          style: TextStyle(color: text.withAlpha(180)),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  if (_error != null) ...[
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.red.withAlpha(20),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.red.withAlpha(60)),
                      ),
                      child: Text(
                        _error!,
                        style: const TextStyle(color: Colors.red),
                      ),
                    ),
                    const SizedBox(height: 14),
                  ],
                  Text(
                    'Metode Pembayaran',
                    style: TextStyle(fontWeight: FontWeight.w700, color: text),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: _SegButton(
                          label: 'Transfer Bank',
                          selected: _method == 'BANK_TRANSFER',
                          onTap: () {
                            setState(() {
                              _method = 'BANK_TRANSFER';
                              final list = _banks;
                              _selectedChannelCode = list.isNotEmpty
                                  ? (list.first['code']?.toString())
                                  : null;
                            });
                          },
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _SegButton(
                          label: 'E-Wallet',
                          selected: _method == 'E_WALLET',
                          onTap: () {
                            setState(() {
                              _method = 'E_WALLET';
                              final list = _ewallets;
                              _selectedChannelCode = list.isNotEmpty
                                  ? (list.first['code']?.toString())
                                  : null;
                            });
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Text(
                    'Pilih Channel',
                    style: TextStyle(fontWeight: FontWeight.w700, color: text),
                  ),
                  const SizedBox(height: 8),
                  if (channels.isEmpty)
                    Text(
                      'Channel belum tersedia. Tarik untuk refresh.',
                      style: TextStyle(color: text.withAlpha(180)),
                    )
                  else
                    Column(
                      children: channels.map((c) {
                        final code = (c['code'] ?? '').toString();
                        final name = (c['name'] ?? '').toString();
                        final accNo = (c['account_number'] ?? '').toString();
                        final accName = (c['account_name'] ?? '').toString();
                        final selected = code == _selectedChannelCode;

                        return Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: selected
                                  ? Theme.of(context).colorScheme.primary
                                  : Colors.white.withAlpha(18),
                            ),
                            color: selected
                                ? Theme.of(context)
                                    .colorScheme
                                    .primary
                                    .withAlpha(18)
                                : bg,
                          ),
                          child: ListTile(
                            onTap: () =>
                                setState(() => _selectedChannelCode = code),
                            title: Text(
                              '$name ($code)',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                color: text,
                              ),
                            ),
                            subtitle: Text(
                              '$accNo a.n $accName',
                              style: TextStyle(color: text.withAlpha(180)),
                            ),
                            trailing: selected
                                ? const Icon(Icons.check_circle)
                                : const Icon(Icons.radio_button_unchecked),
                          ),
                        );
                      }).toList(),
                    ),
                  const SizedBox(height: 14),
                  Text(
                    'Catatan (opsional)',
                    style: TextStyle(fontWeight: FontWeight.w700, color: text),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _noteC,
                    minLines: 2,
                    maxLines: 4,
                    decoration: InputDecoration(
                      hintText: 'Contoh: Sudah transfer dari BCA atas nama ...',
                      filled: true,
                      fillColor: bg,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide:
                            BorderSide(color: Colors.white.withAlpha(18)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide:
                            BorderSide(color: Colors.white.withAlpha(18)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    'Bukti Pembayaran',
                    style: TextStyle(fontWeight: FontWeight.w700, color: text),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: bg,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.white.withAlpha(18)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                _proofFile == null
                                    ? 'Belum ada file dipilih'
                                    : _proofFile!.path
                                        .split(Platform.pathSeparator)
                                        .last,
                                style: TextStyle(color: text.withAlpha(200)),
                              ),
                            ),
                            TextButton.icon(
                              onPressed: _submitting ? null : _pickProof,
                              icon: const Icon(Icons.upload_file),
                              label: Text(
                                widget.allowReupload
                                    ? 'Upload Ulang'
                                    : 'Pilih File',
                              ),
                            ),
                          ],
                        ),
                        if (_proofFile != null) ...[
                          const SizedBox(height: 10),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.file(
                              _proofFile!,
                              height: 160,
                              width: double.infinity,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    height: 48,
                    child: ElevatedButton(
                      onPressed: _submitting ? null : _submit,
                      child: _submitting
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Text('Kirim Bukti Pembayaran'),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

class _SegButton extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _SegButton({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: selected ? c.primary.withAlpha(22) : c.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? c.primary : Colors.white.withAlpha(18),
          ),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: selected ? c.primary : c.onSurface,
            ),
          ),
        ),
      ),
    );
  }
}
