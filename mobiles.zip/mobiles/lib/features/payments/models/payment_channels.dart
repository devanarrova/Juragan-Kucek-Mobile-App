class PaymentChannel {
  final String code;
  final String name;
  final String accountNumber;
  final String accountName;

  const PaymentChannel({
    required this.code,
    required this.name,
    required this.accountNumber,
    required this.accountName,
  });

  factory PaymentChannel.fromJson(Map<String, dynamic> json) {
    return PaymentChannel(
      code: (json['code'] ?? '').toString(),
      name: (json['name'] ?? '').toString(),
      accountNumber: (json['account_number'] ?? '').toString(),
      accountName: (json['account_name'] ?? '').toString(),
    );
  }
}

class PaymentChannelsResponse {
  final List<PaymentChannel> banks;
  final List<PaymentChannel> ewallets;

  const PaymentChannelsResponse({
    required this.banks,
    required this.ewallets,
  });

  factory PaymentChannelsResponse.fromJson(Map<String, dynamic> json) {
    final banksRaw = (json['banks'] as List? ?? const []);
    final ewalletsRaw = (json['ewallets'] as List? ?? const []);

    return PaymentChannelsResponse(
      banks: banksRaw
          .whereType<Map<String, dynamic>>()
          .map(PaymentChannel.fromJson)
          .toList(),
      ewallets: ewalletsRaw
          .whereType<Map<String, dynamic>>()
          .map(PaymentChannel.fromJson)
          .toList(),
    );
  }
}
