import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/network/api_service.dart';

/// Layanan & tarif (Customer).
///
/// Sebelumnya placeholder, ini bikin UX jelek karena tombol "Cek Harga" di Beranda jadi tidak berguna.
/// Screen ini sengaja dibuat ringan: fetch /services lalu render list.
class ServicesScreen extends StatefulWidget {
  const ServicesScreen({super.key});

  @override
  State<ServicesScreen> createState() => _ServicesScreenState();
}

class _ServicesScreenState extends State<ServicesScreen> {
  final ApiService _api = ApiService();

  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _items = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  num? _numFrom(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }

  num? _extractUnitPrice(Map<String, dynamic> s) {
    const keys = [
      'price',
      'price_per_kg',
      'price_per_unit',
      'unit_price',
      'rate',
      'base_price',
    ];
    for (final k in keys) {
      final n = _numFrom(s[k]);
      if (n != null && n > 0) return n;
    }
    return null;
  }

  String _fmtRupiah(num value) {
    final v = value.round();
    final s = v.toString();
    final buf = StringBuffer();
    int count = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      buf.write(s[i]);
      count++;
      if (count % 3 == 0 && i != 0) buf.write('.');
    }
    return 'Rp ${buf.toString().split('').reversed.join()}';
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final res = await _api.get('/services').timeout(const Duration(seconds: 20));
      final list = (res is List) ? res : <dynamic>[];
      final items = <Map<String, dynamic>>[];
      for (final x in list) {
        if (x is Map) items.add(Map<String, dynamic>.from(x));
      }

      // urut id asc biar konsisten
      items.sort((a, b) {
        final aId = int.tryParse('${a['id']}') ?? 0;
        final bId = int.tryParse('${b['id']}') ?? 0;
        return aId.compareTo(bId);
      });

      if (!mounted) return;
      setState(() {
        _items = items;
        _loading = false;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString();
      });
    }
  }

  static Color _opa(Color c, double o) =>
      c.withAlpha((o * 255).round().clamp(0, 255));

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    if (_loading) {
      return Center(child: CircularProgressIndicator(color: cs.primary));
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          Row(
            children: [
              Text(
                'Layanan & Tarif',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  color: cs.onSurface,
                ),
              ),
              const Spacer(),
              IconButton(
                tooltip: 'Refresh',
                onPressed: _load,
                icon: const Icon(Icons.refresh_rounded),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            'Cek harga sebelum buat pesanan. Harga final bisa menyesuaikan qty aktual setelah ditimbang.',
            style: TextStyle(color: _opa(cs.onSurface, 0.70), fontSize: 13),
          ),
          const SizedBox(height: 14),
          if (_error != null) ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: cs.error.withAlpha(18),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: cs.error.withAlpha(60)),
              ),
              child: Text(
                _error!,
                style: TextStyle(color: cs.error, fontWeight: FontWeight.w800),
              ),
            ),
            const SizedBox(height: 12),
          ],
          if (_items.isEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 40),
              child: Column(
                children: [
                  Icon(Icons.local_laundry_service_outlined,
                      size: 42, color: _opa(cs.onSurface, 0.45)),
                  const SizedBox(height: 10),
                  Text(
                    'Belum ada layanan.',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      color: _opa(cs.onSurface, 0.75),
                    ),
                  ),
                ],
              ),
            )
          else
            ..._items.map((s) {
              final name = (s['name'] ?? '-').toString();
              final unitLabel = (s['unit_label'] ?? s['unit'] ?? '').toString();
              final unitPrice = _extractUnitPrice(s);
              final eta = (s['eta_text'] ?? s['duration_text'] ?? '').toString();

              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: [
                        Container(
                          width: 46,
                          height: 46,
                          decoration: BoxDecoration(
                            color: cs.secondary.withAlpha(28),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Icon(Icons.local_laundry_service_rounded,
                              color: cs.secondary),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                name,
                                style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: cs.onSurface,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                unitPrice == null
                                    ? 'Harga belum tersedia'
                                    : '${_fmtRupiah(unitPrice)}${unitLabel.isNotEmpty ? ' / $unitLabel' : ''}',
                                style: TextStyle(
                                  color: _opa(cs.onSurface, 0.75),
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              if (eta.trim().isNotEmpty) ...[
                                const SizedBox(height: 2),
                                Text(
                                  eta,
                                  style: TextStyle(
                                    color: _opa(cs.onSurface, 0.60),
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}
