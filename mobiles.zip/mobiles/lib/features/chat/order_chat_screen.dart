import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/auth/auth_session.dart';
import '../../core/auth/customer_profile_session.dart';
import '../../core/network/api_service.dart';
import '../../core/notifications/customer_notification_session.dart';

class OrderChatScreen extends StatefulWidget {
  final int orderId;
  final String orderCode;

  const OrderChatScreen({
    super.key,
    required this.orderId,
    required this.orderCode,
  });

  @override
  State<OrderChatScreen> createState() => _OrderChatScreenState();
}

class _OrderChatScreenState extends State<OrderChatScreen> {
  final ApiService _api = ApiService();
  final TextEditingController _composer = TextEditingController();
  final ScrollController _scroll = ScrollController();

  bool _loading = true;
  bool _sending = false;
  String? _error;

  List<_Msg> _messages = const [];
  Timer? _poller;

  String? _orderStatus; // contoh: MENUNGGU_KONFIRMASI / ... / SELESAI

  // kalau user sedang scroll ke atas, jangan paksa auto-scroll.
  bool _stickToBottom = true;

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
    _load(initial: true);
    unawaited(_loadOrderStatus());

    // polling cukup untuk demo (real-time murah & aman)
    _poller = Timer.periodic(const Duration(seconds: 4), (_) => _load());
  }

  void _onScroll() {
    if (!_scroll.hasClients) return;
    final max = _scroll.position.maxScrollExtent;
    final cur = _scroll.position.pixels;
    _stickToBottom = (max - cur) < 120; // dekat bawah
  }

  @override
  void dispose() {
    _poller?.cancel();
    _composer.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load({bool initial = false}) async {
    if (initial) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }

    try {
      // best effort: ambil status order, biar bisa lock chat kalau SELESAI
      if (_orderStatus == null) {
        unawaited(_loadOrderStatus());
      }
      final data = await _api.get(
        '/orders/${widget.orderId}/messages',
        bearer: AuthSession.tokenOrEmpty,
      );

      final list = (data is List) ? data : <dynamic>[];
      final msgs = list.map((e) => _Msg.fromJson(e)).toList(growable: false);

      if (!mounted) return;
      setState(() {
        _messages = msgs;
        _loading = false;
        _error = null;
      });

      // best effort: tandai pesan admin sudah dibaca
      unawaited(_api.post(
        '/orders/${widget.orderId}/messages/read',
        {},
        bearer: AuthSession.tokenOrEmpty,
      ));

      // update badge lokal biar langsung turun tanpa nunggu polling
      CustomerNotificationSession.instance.markOrderMessagesRead(widget.orderId);

      _scrollToBottomIfNeeded();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString();
      });
    }
  }

  Future<void> _loadOrderStatus() async {
    try {
      final data = await _api.get(
        '/orders/${widget.orderId}',
        bearer: AuthSession.tokenOrEmpty,
      );
      if (!mounted) return;
      if (data is Map && data['status'] != null) {
        setState(() => _orderStatus = data['status'].toString());
      }
    } catch (_) {
      // abaikan
    }
  }

  void _scrollToBottomIfNeeded() {
    if (!_stickToBottom) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      final max = _scroll.position.maxScrollExtent;
      _scroll.jumpTo(max);
    });
  }

  Future<void> _send() async {
    if (_orderStatus == 'SELESAI') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Chat ditutup karena pesanan sudah SELESAI.')),
      );
      return;
    }
    final text = _composer.text.trim();
    if (text.isEmpty || _sending) return;

    setState(() => _sending = true);
    try {
      await _api.post(
        '/orders/${widget.orderId}/messages',
        {'body': text},
        bearer: AuthSession.tokenOrEmpty,
      );

      if (!mounted) return;
      _composer.clear();
      await _load();
      _scrollToBottomIfNeeded();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  String _fmtTime(DateTime? dt) {
    if (dt == null) return '';
    final x = dt.toLocal();
    final hh = x.hour.toString().padLeft(2, '0');
    final mm = x.minute.toString().padLeft(2, '0');
    return '$hh:$mm';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final myInitial = CustomerProfileSession.instance.profile.value?.initial ?? 'S';
    final chatClosed = (_orderStatus == 'SELESAI');

    return Scaffold(
      appBar: AppBar(
        title: Text('Chat • ${widget.orderCode}'),
        actions: [
          IconButton(
            onPressed: () => _load(initial: true),
            icon: const Icon(Icons.refresh),
          )
        ],
      ),
      body: Column(
        children: [
          if (chatClosed)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              color: cs.errorContainer,
              child: Text(
                'Chat ditutup karena pesanan sudah SELESAI.',
                style: TextStyle(color: cs.onErrorContainer, fontWeight: FontWeight.w600),
              ),
            ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: () => _load(initial: true),
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : (_error != null)
                      ? ListView(
                          children: [
                            const SizedBox(height: 120),
                            Center(
                              child: Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 20),
                                child: Text(
                                  _error!,
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ),
                          ],
                        )
                      : (_messages.isEmpty)
                          ? ListView(
                              children: const [
                                SizedBox(height: 120),
                                Center(child: Text('Belum ada pesan.')),
                              ],
                            )
                          : ListView.builder(
                              controller: _scroll,
                              padding:
                                  const EdgeInsets.fromLTRB(12, 12, 12, 12),
                              itemCount: _messages.length,
                              itemBuilder: (context, i) {
                                final m = _messages[i];
                                final fromAdmin = m.senderRole == 'admin';

                                final align = fromAdmin
                                    ? CrossAxisAlignment.start
                                    : CrossAxisAlignment.end;
                                final rowAlign = fromAdmin
                                    ? MainAxisAlignment.start
                                    : MainAxisAlignment.end;

                                final bg = fromAdmin
                                    ? cs.surface
                                    : cs.primary.withAlpha(28);

                                final time = _fmtTime(m.createdAt);

                                return Column(
                                  crossAxisAlignment: align,
                                  children: [
                                    Row(
                                      mainAxisAlignment: rowAlign,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        if (fromAdmin) ...[
                                          CircleAvatar(
                                            radius: 14,
                                            backgroundColor:
                                                cs.primary.withAlpha(18),
                                            child: Text(
                                              'A',
                                              style: TextStyle(
                                                fontWeight: FontWeight.w700,
                                                color: cs.primary,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 8),
                                        ],
                                        Flexible(
                                          child: Container(
                                            margin: const EdgeInsets.symmetric(
                                                vertical: 6),
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 12, vertical: 10),
                                            decoration: BoxDecoration(
                                              color: bg,
                                              borderRadius:
                                                  BorderRadius.circular(14),
                                              border: Border.all(
                                                color:
                                                    Colors.black.withAlpha(12),
                                              ),
                                            ),
                                            child: Column(
                                              crossAxisAlignment: align,
                                              children: [
                                                Text(
                                                  m.body,
                                                  style: TextStyle(
                                                    color: cs.onSurface,
                                                  ),
                                                ),
                                                if (time.isNotEmpty) ...[
                                                  const SizedBox(height: 6),
                                                  Text(
                                                    time,
                                                    style: TextStyle(
                                                      fontSize: 11,
                                                      color: cs.onSurface
                                                          .withAlpha(140),
                                                    ),
                                                  ),
                                                ],
                                              ],
                                            ),
                                          ),
                                        ),
                                        if (!fromAdmin) ...[
                                          const SizedBox(width: 8),
                                          CircleAvatar(
                                            radius: 14,
                                            backgroundColor:
                                                cs.primary.withAlpha(18),
                                            child: Text(
                                              myInitial,
                                              style: TextStyle(
                                                fontWeight: FontWeight.w700,
                                                color: cs.primary,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ],
                                    ),
                                  ],
                                );
                              },
                            ),
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _composer,
                      enabled: !_sending && !chatClosed,
                      minLines: 1,
                      maxLines: 4,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                      decoration: InputDecoration(
                        hintText: chatClosed ? 'Chat ditutup (pesanan selesai)' : 'Tulis pesan...',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  IconButton(
                    onPressed: (_sending || chatClosed) ? null : _send,
                    icon: _sending
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Msg {
  final int id;
  final String senderRole; // 'admin' / 'customer'
  final String body;
  final DateTime? createdAt;

  const _Msg({
    required this.id,
    required this.senderRole,
    required this.body,
    required this.createdAt,
  });

  factory _Msg.fromJson(dynamic raw) {
    if (raw is Map) {
      final id = (raw['id'] is int)
          ? raw['id'] as int
          : int.tryParse('${raw['id']}') ?? 0;
      final senderRole = (raw['sender_role'] ?? '').toString();
      final body = (raw['body'] ?? '').toString();
      final createdAtStr = raw['created_at']?.toString();
      DateTime? created;
      if (createdAtStr != null && createdAtStr.trim().isNotEmpty) {
        created = DateTime.tryParse(createdAtStr);
      }
      return _Msg(
        id: id,
        senderRole: senderRole,
        body: body,
        createdAt: created,
      );
    }

    return _Msg(
      id: 0,
      senderRole: '',
      body: raw?.toString() ?? '',
      createdAt: null,
    );
  }
}
