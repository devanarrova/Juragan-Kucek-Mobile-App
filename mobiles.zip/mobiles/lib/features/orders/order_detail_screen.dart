import 'dart:async';
import 'package:flutter/material.dart';

import '../../core/auth/auth_session.dart';
import '../../core/network/api_service.dart';
import '../chat/order_chat_screen.dart';
import '../payments/payment_screen.dart';

class OrderDetailScreen extends StatefulWidget {
  final int orderId;
  const OrderDetailScreen({super.key, required this.orderId});

  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  final _api = ApiService();

  bool _loading = false;
  String? _error;
  Map<String, dynamic>? _order;

  Timer? _failsafeTimer;

  Color _opa(Color c, double o) => c.withAlpha((o * 255).round());

  static const List<String> _statusFlow = [
    'MENUNGGU_KONFIRMASI',
    'DIPROSES',
    'SELESAI_MENUNGGU_PEMBAYARAN',
    'MENUNGGU_VERIFIKASI_PEMBAYARAN',
    'LUNAS_SIAP_DIANTAR',
    'DIANTAR',
    'SELESAI',
  ];

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  @override
  void dispose() {
    _failsafeTimer?.cancel();
    super.dispose();
  }

  int _progressIndexFor(String status) {
    // status di luar flow, kita petakan ke step terdekat biar progress gak ngaco
    if (status == 'PEMBAYARAN_DITOLAK') {
      return _statusFlow.indexOf('SELESAI_MENUNGGU_PEMBAYARAN');
    }
    final idx = _statusFlow.indexOf(status);
    return idx < 0 ? 0 : idx;
  }

  String _label(String s) {
    switch (s) {
      case 'MENUNGGU_KONFIRMASI':
        return 'Menunggu Konfirmasi';
      case 'DIPROSES':
        return 'Diproses';
      case 'SELESAI_MENUNGGU_PEMBAYARAN':
        return 'Menunggu Pembayaran';
      case 'MENUNGGU_VERIFIKASI_PEMBAYARAN':
        return 'Menunggu Verifikasi Pembayaran';
      case 'PEMBAYARAN_DITOLAK':
        return 'Pembayaran Ditolak';
      case 'LUNAS_SIAP_DIANTAR':
        return 'Lunas, Siap Diantar';
      case 'DIANTAR':
        return 'Diantar';
      case 'SELESAI':
        return 'Selesai';
      default:
        return s;
    }
  }

  String _money(int v) {
    final s = v.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      final idxFromRight = s.length - i;
      buf.write(s[i]);
      if (idxFromRight > 1 && idxFromRight % 3 == 1) buf.write('.');
    }
    return 'Rp $buf';
  }

  String _fmtDate(dynamic raw) {
    final s = (raw ?? '').toString();
    // kalau sudah yyyy-mm-dd biarkan
    if (RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(s)) return s;
    return s;
  }

  Future<void> _fetch() async {
    _failsafeTimer?.cancel();

    setState(() {
      _loading = true;
      _error = null;
      _order = null;
    });

    // FAILSAFE: kalau masih loading > 25 detik, stop & tampil error
    _failsafeTimer = Timer(const Duration(seconds: 25), () {
      if (!mounted) return;
      if (_loading) {
        setState(() {
          _loading = false;
          _error = 'Timeout memuat detail pesanan (orderId=${widget.orderId}).';
        });
      }
    });

    try {
      final token = AuthSession.tokenOrEmpty;
      if (token.trim().isEmpty) {
        throw Exception('Token kosong. Silakan login ulang.');
      }

      final res = await _api
          .get('/orders/${widget.orderId}', bearer: token)
          // timeout tambahan level screen (jaga-jaga)
          .timeout(const Duration(seconds: 22));

      final order = res is Map ? Map<String, dynamic>.from(res) : null;

      if (!mounted) return;
      setState(() => _order = order);
    } catch (e) {
      if (!mounted) return;

      final msg = e.toString();

      // kalau order sudah kehapus -> langsung balik ke list biar gak nyangkut
      if (msg.contains('(404)') || msg.contains('404')) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
                'Pesanan sudah tidak tersedia (mungkin sudah dibatalkan).'),
          ),
        );
        Navigator.pop(context, true); // true => list refresh
        return;
      }

      setState(() => _error = msg);
    } finally {
      _failsafeTimer?.cancel();
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _openPayment({
    required int orderId,
    required String orderCode,
    required int totalAmount,
    required bool allowReupload,
  }) async {
    final res = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PaymentScreen(
          orderId: orderId,
          orderCode: orderCode,
          totalAmount: totalAmount,
          allowReupload: allowReupload,
        ),
      ),
    );

    if (!mounted) return;

    final submitted = res == true ||
        (res is Map && res['submitted'] == true) ||
        (res != null && res.toString() == 'submitted');

    if (submitted) {
      await _fetch();
    }
  }

  void _openChat(int orderId, String orderCode) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => OrderChatScreen(orderId: orderId, orderCode: orderCode),
      ),
    );
  }

  Future<void> _cancelOrder() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Batalkan pesanan?'),
        content: const Text(
          'Pesanan hanya bisa dibatalkan saat masih Menunggu Konfirmasi.\n'
          'Jika dibatalkan, pesanan akan dihapus permanen.',
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Batal')),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Ya, Batalkan')),
        ],
      ),
    );

    if (ok != true) return;

    setState(() => _loading = true);

    try {
      final res = await _api.delete(
        '/orders/${widget.orderId}',
        bearer: AuthSession.tokenOrEmpty,
      );

      if (!mounted) return;

      final msg = (res is Map && res['message'] != null)
          ? res['message'].toString()
          : 'Pesanan berhasil dibatalkan.';

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

      Navigator.pop(context, true); // true => list refresh
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal membatalkan: $e')),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    if (_loading) {
      return Scaffold(
        appBar: AppBar(title: const Text('Detail Pesanan')),
        body: Center(child: CircularProgressIndicator(color: cs.primary)),
      );
    }

    if (_error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Detail Pesanan')),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _opa(cs.error, 0.08),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _opa(cs.error, 0.25)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Gagal memuat detail (orderId=${widget.orderId}):\n$_error',
                  style:
                      TextStyle(color: cs.error, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  height: 44,
                  child: FilledButton.icon(
                    onPressed: _fetch,
                    icon: const Icon(Icons.refresh),
                    label: const Text('Coba Lagi'),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    }

    if (_order == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Detail Pesanan')),
        body: Center(
          child: Text(
            'Data pesanan tidak ditemukan.',
            style: TextStyle(color: _opa(cs.onSurface, 0.7)),
          ),
        ),
      );
    }

    final order = _order!;
    final orderCode = (order['order_code'] ?? order['code'] ?? '-').toString();
    final status = (order['status'] ?? '').toString();
    final rejectReason = (order['reject_reason'] ?? '').toString();

    // ====== Data service untuk estimasi ======
    final serviceRaw = order['service'];
    final service = (serviceRaw is Map)
        ? Map<String, dynamic>.from(serviceRaw)
        : <String, dynamic>{};

    final serviceName = (service['name'] ?? '').toString().trim();
    final unitLabel = (service['unit_label'] ?? '').toString().trim();

    final estimatedQty =
        double.tryParse('${order['estimated_qty'] ?? ''}') ?? 0.0;
    final basePrice = double.tryParse('${service['base_price'] ?? ''}') ?? 0.0;

    final estimatedTotal = (estimatedQty > 0 && basePrice > 0)
        ? (estimatedQty * basePrice).round()
        : 0;

    final totalAmount =
        (double.tryParse('${order['total_price'] ?? 0}') ?? 0).round();
    final hasFinalTotal = totalAmount > 0;

    final finalQty = double.tryParse('${order['final_qty'] ?? ''}');

    // ====== Rules UI actions ======
    final canPay = status == 'SELESAI_MENUNGGU_PEMBAYARAN' ||
        status == 'PEMBAYARAN_DITOLAK';
    final waitingVerify = status == 'MENUNGGU_VERIFIKASI_PEMBAYARAN';
    final canCancel = status == 'MENUNGGU_KONFIRMASI';

    final safeIndex = _progressIndexFor(status);

    final historiesRaw = order['status_histories'];
    final histories = (historiesRaw is List)
        ? historiesRaw
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList()
        : <Map<String, dynamic>>[];

    final pickupDate = _fmtDate(order['pickup_date']);
    final pickupAddress = (order['pickup_address'] ?? '').toString().trim();

    return Scaffold(
      appBar: AppBar(title: const Text('Detail Pesanan')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          // ===== Header =====
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          orderCode,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w900),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Flexible(
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: _opa(cs.primary, 0.12),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            _label(status),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            softWrap: false,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: cs.primary,
                            ),
                          ),
                        ),
                      ),
                      if (rejectReason.isNotEmpty) ...[
                        const SizedBox(width: 8),
                        Icon(Icons.error_outline, color: cs.error),
                      ],
                    ],
                  ),

                  if (serviceName.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Text(
                      serviceName,
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: _opa(cs.onSurface, 0.85),
                      ),
                    ),
                  ],

                  if (rejectReason.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Text('Alasan ditolak: $rejectReason',
                        style: TextStyle(color: cs.error)),
                  ],

                  const SizedBox(height: 10),

                  // Estimasi biaya (dari estimated_qty x base_price)
                  if (estimatedTotal > 0) ...[
                    Text(
                      'Estimasi: ${_money(estimatedTotal)}'
                      '${unitLabel.isNotEmpty ? ' (± ${estimatedQty.toStringAsFixed(2)} $unitLabel)' : ''}',
                      style: TextStyle(color: _opa(cs.onSurface, 0.75)),
                    ),
                  ] else ...[
                    Text(
                      'Estimasi: -',
                      style: TextStyle(color: _opa(cs.onSurface, 0.65)),
                    ),
                  ],

                  const SizedBox(height: 6),

                  // Tagihan final
                  Text(
                    'Tagihan Final: ${hasFinalTotal ? _money(totalAmount) : '- (menunggu hasil timbang admin)'}',
                    style: TextStyle(
                      color: _opa(cs.onSurface, 0.85),
                      fontWeight: FontWeight.w800,
                    ),
                  ),

                  if (finalQty != null) ...[
                    const SizedBox(height: 4),
                    Text(
                      'Final Qty: ${finalQty.toStringAsFixed(2)}${unitLabel.isNotEmpty ? ' $unitLabel' : ''}',
                      style: TextStyle(color: _opa(cs.onSurface, 0.70)),
                    ),
                  ],

                  if (pickupDate.isNotEmpty || pickupAddress.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    if (pickupDate.isNotEmpty)
                      Text('Pickup: $pickupDate',
                          style: TextStyle(color: _opa(cs.onSurface, 0.70))),
                    if (pickupAddress.isNotEmpty)
                      Text('Alamat: $pickupAddress',
                          style: TextStyle(color: _opa(cs.onSurface, 0.70))),
                  ],
                ],
              ),
            ),
          ),

          const SizedBox(height: 14),

          // ===== Actions =====
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Aksi',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _openChat(widget.orderId, orderCode),
                          icon: const Icon(Icons.chat_bubble_outline),
                          label: const Text('Chat Admin'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: canPay
                              ? () => _openPayment(
                                    orderId: widget.orderId,
                                    orderCode: orderCode,
                                    totalAmount: totalAmount,
                                    allowReupload:
                                        status == 'PEMBAYARAN_DITOLAK',
                                  )
                              : null,
                          icon: const Icon(Icons.payment),
                          label: Text(status == 'PEMBAYARAN_DITOLAK'
                              ? 'Upload Ulang'
                              : 'Bayar'),
                        ),
                      ),
                    ],
                  ),
                  if (canCancel) ...[
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      height: 44,
                      child: OutlinedButton.icon(
                        onPressed: _cancelOrder,
                        icon: const Icon(Icons.cancel_outlined),
                        label: const Text('Batalkan Pesanan'),
                        style:
                            OutlinedButton.styleFrom(foregroundColor: cs.error),
                      ),
                    ),
                  ],
                  const SizedBox(height: 10),
                  if (waitingVerify)
                    Text(
                      'Bukti sudah dikirim. Menunggu verifikasi admin.',
                      style: TextStyle(color: _opa(cs.onSurface, 0.7)),
                    )
                  else if (canCancel)
                    Text(
                      'Kamu bisa membatalkan pesanan selama masih “Menunggu Konfirmasi”.',
                      style: TextStyle(color: _opa(cs.onSurface, 0.7)),
                    )
                  else if (!canPay)
                    Text(
                      'Pembayaran aktif saat status “Menunggu Pembayaran”.',
                      style: TextStyle(color: _opa(cs.onSurface, 0.7)),
                    ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 14),

          // ===== Progress Status =====
          const Text('Progress Status',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: List.generate(_statusFlow.length, (i) {
                  final s = _statusFlow[i];
                  final done = i <= safeIndex;

                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      children: [
                        Container(
                          width: 14,
                          height: 14,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: done ? cs.primary : _opa(Colors.grey, 0.35),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            _label(s),
                            style: TextStyle(
                              fontWeight: FontWeight.w800,
                              color: done
                                  ? cs.onSurface
                                  : _opa(cs.onSurface, 0.55),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }),
              ),
            ),
          ),

          const SizedBox(height: 14),

          // ===== Real Histories =====
          const Text('Riwayat Status (Real)',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: histories.isEmpty
                  ? Text('Belum ada history status.',
                      style: TextStyle(color: _opa(cs.onSurface, 0.7)))
                  : Column(
                      children: histories.map((h) {
                        final st =
                            (h['new_status'] ?? h['status'] ?? '').toString();
                        final note = (h['note'] ?? '').toString();
                        final at = (h['created_at'] ?? '').toString();

                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Icon(Icons.fiber_manual_record,
                                  size: 12, color: cs.primary),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(_label(st),
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w800)),
                                    const SizedBox(height: 2),
                                    Text(at,
                                        style: TextStyle(
                                            fontSize: 12,
                                            color: _opa(cs.onSurface, 0.65))),
                                    if (note.isNotEmpty) ...[
                                      const SizedBox(height: 4),
                                      Text(note,
                                          style: TextStyle(
                                              color: _opa(cs.onSurface, 0.8))),
                                    ],
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
            ),
          ),

          const SizedBox(height: 40),
        ],
      ),
    );
  }
}
