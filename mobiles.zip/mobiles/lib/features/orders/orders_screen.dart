import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../../core/auth/auth_session.dart';
import '../../core/network/api_service.dart';
import '../../core/notifications/customer_notification_session.dart';
import 'order_detail_screen.dart';

class OrdersScreen extends StatefulWidget {
  final ValueListenable<int>? mainTabIndex;

  const OrdersScreen({super.key, this.mainTabIndex});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen>
    with WidgetsBindingObserver {
  final _api = ApiService();

  bool _loading = true; // hanya buat initial load / saat data kosong
  String? _error;

  bool _fetching = false;

  List<Map<String, dynamic>> _orders = [];
  String _q = '';

  Timer? _pollTimer;
  Duration _pollInterval = const Duration(seconds: 15);

  DateTime? _lastToastAt;

  bool _everFetched = false;
  VoidCallback? _tabListener;

  bool get _isActiveTab => widget.mainTabIndex == null || widget.mainTabIndex!.value == 3;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    // Karena MainShell pakai IndexedStack, tab Riwayat tetap hidup walau tidak sedang dibuka.
    // Jadi polling & fetch harus jalan hanya saat tab ini aktif (index == 3).
    if (widget.mainTabIndex != null) {
      _tabListener = _onTabChanged;
      widget.mainTabIndex!.addListener(_tabListener!);
    }

    _syncActiveState(initial: true);
  }

  void _onTabChanged() {
    _syncActiveState();
  }

  void _syncActiveState({bool initial = false}) {
    if (!_isActiveTab) {
      _stopPolling();
      return;
    }

    // pertama kali tab dibuka -> fetch yang blok UI
    if (!_everFetched) {
      _everFetched = true;
      _fetch(userInitiated: false, silent: false);
    } else {
      // tab aktif lagi -> refresh silent
      _fetch(silent: true);
    }

    _startPolling();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    if (widget.mainTabIndex != null && _tabListener != null) {
      widget.mainTabIndex!.removeListener(_tabListener!);
    }
    _stopPolling();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Saat app balik ke foreground -> refresh biar status kebaca tanpa restart.
    if (state == AppLifecycleState.resumed) {
      if (_isActiveTab) {
        _fetch(silent: true);
        _startPolling();
      }
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive ||
        state == AppLifecycleState.detached) {
      _stopPolling();
    }
  }

  Color _opa(Color c, double o) => c.withAlpha((o * 255).round());

  String _label(String s) {
    switch (s) {
      case 'MENUNGGU_KONFIRMASI':
        return 'Menunggu Konfirmasi';
      case 'DIPROSES':
        return 'Diproses';
      case 'SELESAI_MENUNGGU_PEMBAYARAN':
        return 'Menunggu Pembayaran';
      case 'MENUNGGU_VERIFIKASI_PEMBAYARAN':
        return 'Menunggu Verifikasi Pembayaran';
      case 'PEMBAYARAN_DITOLAK':
        return 'Pembayaran Ditolak';
      case 'LUNAS_SIAP_DIANTAR':
        return 'Lunas, Siap Diantar';
      case 'DIANTAR':
        return 'Diantar';
      case 'SELESAI':
        return 'Selesai';
      default:
        return s;
    }
  }

  void _toast(String msg) {
    if (!mounted) return;

    // throttle biar polling error tidak spam
    final now = DateTime.now();
    if (_lastToastAt != null && now.difference(_lastToastAt!).inSeconds < 20) {
      return;
    }
    _lastToastAt = now;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg)),
    );
  }

  String _friendlyError(Object e) {
    if (e is TimeoutException) return 'Koneksi lambat (timeout). Coba lagi.';
    if (e is SocketException) return 'Tidak ada koneksi internet.';
    final s = e.toString();
    if (s.contains('401')) return 'Sesi kamu habis. Silakan login ulang.';
    return s;
  }

  Duration _desiredPollInterval() {
    // Kalau masih ada pesanan yang belum selesai -> polling cepat
    final hasActive =
        _orders.any((o) => (o['status'] ?? '').toString() != 'SELESAI');
    return hasActive ? const Duration(seconds: 15) : const Duration(minutes: 1);
  }

  void _startPolling() {
    final desired = _desiredPollInterval();
    if (_pollTimer != null && _pollInterval == desired) return;

    _stopPolling();
    _pollInterval = desired;

    _pollTimer = Timer.periodic(_pollInterval, (_) {
      // silent fetch -> tidak bikin layar kedip
      _fetch(silent: true);
    });
  }

  void _stopPolling() {
    _pollTimer?.cancel();
    _pollTimer = null;
  }

  Future<void> _fetch({bool silent = false, bool userInitiated = false}) async {
    if (_fetching) return;
    _fetching = true;

    final shouldBlockUI = !silent && _orders.isEmpty;

    if (shouldBlockUI && mounted) {
      setState(() {
        _loading = true;
        _error = null;
      });
    } else if (userInitiated && mounted) {
      // refresh manual, jangan bikin layar spinner full
      setState(() => _error = null);
    }

    try {
      final token = AuthSession.tokenOrEmpty;
      if (token.trim().isEmpty) {
        throw Exception('Token kosong. Silakan login ulang.');
      }

      // Timeout supaya tidak loading tanpa ujung
      final res = await _api
          .get('/orders', bearer: token)
          .timeout(const Duration(seconds: 20));

      final list = res is List ? res : <dynamic>[];
      final items = <Map<String, dynamic>>[];

      for (final x in list) {
        if (x is Map) items.add(Map<String, dynamic>.from(x));
      }

      // urut terbaru (PAKAI numeric, jangan string compare)
      items.sort((a, b) {
        final aId = int.tryParse('${a['id']}') ?? 0;
        final bId = int.tryParse('${b['id']}') ?? 0;
        return bId.compareTo(aId);
      });

      if (!mounted) return;
      setState(() {
        _orders = items;
        _error = null;
        _loading = false;
      });

      // setelah data berubah, atur polling interval (aktif vs semua selesai)
      _startPolling();
    } catch (e) {
      if (!mounted) return;
      final msg = _friendlyError(e);

      // Kalau belum ada data sama sekali -> tampilkan error screen
      if (_orders.isEmpty) {
        setState(() {
          _error = msg;
          _loading = false;
        });
      } else {
        // Kalau sudah ada data -> jangan lempar ke error screen (biar UI tetap usable)
        if (userInitiated) _toast(msg);
      }
    } finally {
      _fetching = false;
      if (mounted && shouldBlockUI) {
        setState(() => _loading = false);
      }
    }
  }

  List<Map<String, dynamic>> _filtered(int tabIndex) {
    // search dulu
    final q = _q.trim().toLowerCase();
    List<Map<String, dynamic>> list = _orders;

    if (q.isNotEmpty) {
      list = list.where((o) {
        final code = (o['order_code'] ?? '').toString().toLowerCase();
        final service = (o['service'] is Map)
            ? Map<String, dynamic>.from(o['service'])
            : <String, dynamic>{};
        final serviceName = (service['name'] ?? '').toString().toLowerCase();
        return code.contains(q) || serviceName.contains(q);
      }).toList();
    }

    // status filter berdasarkan tab
    if (tabIndex == 0) {
      // "Semua (kecuali SELESAI)"
      return list
          .where((o) => (o['status'] ?? '').toString() != 'SELESAI')
          .toList();
    }

    if (tabIndex == 1) {
      // "Berjalan" = bukan selesai dan bukan menunggu konfirmasi
      return list.where((o) {
        final st = (o['status'] ?? '').toString();
        return st != 'SELESAI' && st != 'MENUNGGU_KONFIRMASI';
      }).toList();
    }

    // tabIndex == 2 -> selesai
    return list
        .where((o) => (o['status'] ?? '').toString() == 'SELESAI')
        .toList();
  }

  Future<void> _openDetail(int orderId) async {
    final res = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => OrderDetailScreen(orderId: orderId)),
    );

    // true => ada perubahan (contoh: dibatalkan, bayar submit)
    if (!mounted) return;
    if (res == true) {
      await _fetch(userInitiated: true);
    }
  }

  Widget _buildList(int tabIndex) {
    final cs = Theme.of(context).colorScheme;
    final items = _filtered(tabIndex);

    if (items.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          const SizedBox(height: 40),
          Center(
            child: Text(
              'Tidak ada pesanan.',
              style: TextStyle(color: _opa(cs.onSurface, 0.7)),
            ),
          ),
        ],
      );
    }

    return ListView.builder(
      physics: const AlwaysScrollableScrollPhysics(),
      itemCount: items.length,
      itemBuilder: (_, i) {
        final o = items[i];
        final id = int.tryParse('${o['id']}') ?? 0;
        final code = (o['order_code'] ?? '-').toString();
        final status = (o['status'] ?? '').toString();

        final service = (o['service'] is Map)
            ? Map<String, dynamic>.from(o['service'])
            : <String, dynamic>{};
        final serviceName = (service['name'] ?? '').toString();

        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          child: ListTile(
            onTap: () => _openDetail(id),
            title: Text(
              code,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w900),
            ),
            subtitle: Text(
              serviceName.isEmpty ? '-' : serviceName,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            trailing: ValueListenableBuilder<Map<int, int>>(
              valueListenable: CustomerNotificationSession.instance.unreadByOrder,
              builder: (_, map, __) {
                final unread = map[id] ?? 0;
                return Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (unread > 0)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: cs.error,
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          unread > 99 ? '99+' : unread.toString(),
                          style: TextStyle(
                            color: cs.onError,
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    if (unread > 0) const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: cs.primary.withAlpha(18),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        _label(status),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: cs.primary,
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    // initial loading (data kosong)
    if (_loading && _orders.isEmpty) {
      return Center(child: CircularProgressIndicator(color: cs.primary));
    }

    // error screen cuma kalau data kosong
    if (_error != null && _orders.isEmpty) {
      return Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: cs.error.withAlpha(18),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: cs.error.withAlpha(50)),
              ),
              child: Text(
                'Gagal memuat orders:\n$_error',
                style: TextStyle(color: cs.error, fontWeight: FontWeight.w800),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 44,
              child: FilledButton.icon(
                onPressed: () => _fetch(userInitiated: true),
                icon: const Icon(Icons.refresh),
                label: const Text('Coba Lagi'),
              ),
            ),
          ],
        ),
      );
    }

    // hitung badge count
    final cAll = _filtered(0).length;
    final cRunning = _filtered(1).length;
    final cDone = _filtered(2).length;

    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
            child: TextField(
              onChanged: (v) => setState(() => _q = v),
              decoration: InputDecoration(
                hintText: 'Cari kode / layanan',
                prefixIcon: const Icon(Icons.search),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                isDense: true,
              ),
            ),
          ),
          TabBar(
            labelColor: cs.primary,
            unselectedLabelColor: _opa(cs.onSurface, 0.65),
            indicatorColor: cs.primary,
            tabs: [
              Tab(text: 'Semua ($cAll)'),
              Tab(text: 'Berjalan ($cRunning)'),
              Tab(text: 'Selesai ($cDone)'),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                RefreshIndicator(
                  onRefresh: () => _fetch(userInitiated: true),
                  child: _buildList(0),
                ),
                RefreshIndicator(
                  onRefresh: () => _fetch(userInitiated: true),
                  child: _buildList(1),
                ),
                RefreshIndicator(
                  onRefresh: () => _fetch(userInitiated: true),
                  child: _buildList(2),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
