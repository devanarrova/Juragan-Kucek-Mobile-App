import 'package:flutter/foundation.dart';

class OrdersRefreshBus {
  OrdersRefreshBus._();
  static final ValueNotifier<int> tick = ValueNotifier<int>(0);
  static void ping() => tick.value++;
}
